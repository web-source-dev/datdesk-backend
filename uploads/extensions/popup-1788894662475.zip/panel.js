'use strict';

const em = {
  status: null,
  recipient: '',
  tab: 'inbox',
  session: null,
  oauthWaiting: false,
  connectPanelOpen: false,
  inboxFolder: 'received',
  inboxAccountId: '',
  inboxItems: [],
  inboxSelected: null,
  inboxThreadMessages: [],
  inboxReplyContext: null
};
const $ = (id) => document.getElementById(id);
let oauthWaitSeq = 0;
const ICO_EYE =
  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>';
const ICO_EYE_OFF =
  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19M1 1l22 22M14.12 14.12a3 3 0 1 1-4.24-4.24"/></svg>';
const APP_PROGRESS_STEPS = [
  'Checking app password…',
  'Verifying mailbox access…',
  'Saving account…',
  'Syncing inbox…'
];
let appProgressTimer = null;

function paintPasswordToggles() {
  document.querySelectorAll('[data-pw-toggle]').forEach((btn) => {
    if (!btn.innerHTML.trim()) btn.innerHTML = ICO_EYE;
  });
}

function togglePasswordVisibility(btn) {
  const input = $(btn.getAttribute('data-pw-toggle'));
  if (!input) return;
  const show = input.type === 'password';
  input.type = show ? 'text' : 'password';
  btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
  btn.setAttribute('aria-pressed', show ? 'true' : 'false');
  btn.innerHTML = show ? ICO_EYE_OFF : ICO_EYE;
}

function setAppProgress(on, text) {
  const box = $('app-progress');
  const label = $('app-progress-text');
  if (label && text) label.textContent = text;
  if (box) box.hidden = !on;
}

function startAppProgress() {
  let i = 0;
  setAppProgress(true, APP_PROGRESS_STEPS[0]);
  clearInterval(appProgressTimer);
  appProgressTimer = setInterval(() => {
    i = Math.min(i + 1, APP_PROGRESS_STEPS.length - 1);
    setAppProgress(true, APP_PROGRESS_STEPS[i]);
    if (i >= APP_PROGRESS_STEPS.length - 1) {
      clearInterval(appProgressTimer);
      appProgressTimer = null;
    }
  }, 1600);
}

function stopAppProgress() {
  clearInterval(appProgressTimer);
  appProgressTimer = null;
  setAppProgress(false);
}

function sanitizeMailHtml(html) {
  const tpl = document.createElement('template');
  tpl.innerHTML = String(html || '');
  tpl.content
    .querySelectorAll('script,style,iframe,object,embed,link,meta,form')
    .forEach((el) => el.remove());
  tpl.content.querySelectorAll('*').forEach((el) => {
    [...el.attributes].forEach((attr) => {
      const name = attr.name.toLowerCase();
      if (/^on/.test(name) || name === 'srcdoc') el.removeAttribute(attr.name);
      if (name === 'href' && /^javascript:/i.test(attr.value)) el.removeAttribute(attr.name);
    });
  });
  return tpl.innerHTML;
}

function hideBackendUrls(text, fallback) {
  let s = String(text || '')
    .replace(/https?:\/\/[^\s"'<>)\]]+/gi, '')
    .replace(/\b(?:localhost|127\.0\.0\.1)(?::\d+)?\b/gi, '')
    .replace(/\b[\w.-]*apexskillzone\.com\b/gi, '')
    .replace(/\bGOOGLE_[A-Z0-9_]+\b/g, '')
    .replace(/\b(?:ECONNREFUSED|ENOTFOUND|ECONNRESET|ETIMEDOUT)\b/gi, '')
    .replace(/\(\s*\d{3}\s*\)/g, '')
    .replace(/\s{2,}/g, ' ')
    .replace(/\s+([.,;:!])/g, '$1')
    .trim();
  if (!s || /token mismatch|cloud API|local backend|JWT|7020|5174/i.test(s)) {
    return fallback == null ? s : fallback;
  }
  return s;
}

function toast(message, ok = true) {
  const el = $('toast');
  el.textContent = hideBackendUrls(message, ok ? '' : 'Something went wrong. Please try again.');
  el.className = 'toast show ' + (ok ? 'ok' : 'err');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('show'), 3200);
}

function send(type, extra = {}) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type, ...extra }, (res) => {
      if (chrome.runtime.lastError) {
        resolve({ success: false, message: chrome.runtime.lastError.message });
        return;
      }
      resolve(res || { success: false, message: 'No response' });
    });
  });
}

function setEmTab(tab) {
  em.tab = tab;
  document.querySelectorAll('.em-tab').forEach((el) => {
    el.classList.toggle('active', el.dataset.tab === tab);
  });
  $('view-inbox').classList.toggle('hidden', tab !== 'inbox');
  $('view-compose').classList.toggle('hidden', tab !== 'compose');
  $('view-templates').classList.toggle('hidden', tab !== 'templates');
  $('view-account').classList.toggle('hidden', tab !== 'account');
  if (tab === 'inbox') {
    fillPanelInboxAccounts();
    loadPanelInbox();
  }
}

function fmtPanelDate(dt) {
  if (!dt) return '—';
  try {
    return new Date(dt).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  } catch {
    return String(dt);
  }
}

function fillPanelInboxAccounts() {
  const select = $('panel-inbox-account');
  if (!select) return;
  const list = panelAccounts();
  select.innerHTML = '';
  list.forEach((a) => {
    const opt = document.createElement('option');
    opt.value = a.id;
    opt.textContent = a.email + (a.isDefault ? ' (default)' : '');
    select.appendChild(opt);
  });
  if (!em.inboxAccountId || !list.some((a) => String(a.id) === String(em.inboxAccountId))) {
    em.inboxAccountId = list.find((a) => a.isDefault)?.id || list[0]?.id || '';
  }
  if (em.inboxAccountId) select.value = em.inboxAccountId;
}

async function loadPanelInbox() {
  fillPanelInboxAccounts();
  const list = panelAccounts();
  const wrap = $('panel-inbox-list');
  const empty = $('panel-inbox-empty');
  if (!wrap) return;
  wrap.innerHTML = '';
  if (!list.length) {
    empty.hidden = false;
    empty.textContent = 'Connect an email account on the Account tab.';
    return;
  }
  if (!em.inboxAccountId) {
    empty.hidden = false;
    return;
  }
  const query = {
    accountId: em.inboxAccountId,
    page: 1,
    limit: 30,
    search: ($('panel-inbox-search')?.value || '').trim() || undefined
  };
  try {
    const res = await send('EMAIL_CONVERSATIONS_LIST', { query });
    if (!res?.success) throw new Error(res?.message || 'Failed to load conversations');
    const rows = (res.data?.conversations || []).map((row) => ({
      ...row,
      kind: 'conversation',
      id: row.conversationKey
    }));
    em.inboxItems = rows;
    empty.hidden = rows.length > 0;
    rows.forEach((row) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'template-item';
      const who = row.to || '—';
      const replyBadge =
        Number(row.inboundCount) > 0 ? ` · ${row.inboundCount} repl${row.inboundCount === 1 ? 'y' : 'ies'}` : '';
      btn.innerHTML =
        `<strong>${row.subject || row.rootSubject || '(No subject)'}</strong>` +
        `<span>${who} · ${fmtPanelDate(row.lastDate || row.lastSentAt)}${replyBadge}</span>`;
      btn.addEventListener('click', () => openPanelInboxMessage(row));
      wrap.appendChild(btn);
    });
  } catch (err) {
    empty.hidden = false;
    empty.textContent = err.message || 'Could not load conversations';
  }
}

async function openPanelInboxMessage(row) {
  em.inboxSelected = row;
  em.inboxThreadMessages = [];
  try {
    const res = await send('EMAIL_CONVERSATION_MESSAGES', {
      conversationKey: row.conversationKey,
      query: { accountId: em.inboxAccountId }
    });
    if (res?.success) {
      const data = res.data || {};
      em.inboxSelected = { ...row, ...data, kind: 'conversation' };
      em.inboxThreadMessages = data.messages || [];
    }
  } catch {
    // keep list row
  }
  $('panel-inbox-detail').classList.remove('hidden');
  $('panel-inbox-subject').textContent =
    em.inboxSelected.subject || em.inboxSelected.rootSubject || '(No subject)';
  $('panel-inbox-meta').textContent = `With: ${em.inboxSelected.to || '—'} · ${(em.inboxThreadMessages || []).length} message(s)`;
  $('panel-inbox-body').innerHTML = '';
  if (!em.inboxThreadMessages.length) {
    $('panel-inbox-body').textContent = 'No messages synced yet. Tap Sync to check for replies.';
  } else {
    em.inboxThreadMessages.forEach((msg) => {
      const block = document.createElement('div');
      block.className = 'inbox-thread-msg';
      const head = document.createElement('div');
      head.className = 'hint';
      const who =
        msg.direction === 'inbound'
          ? msg.from || msg.to || 'Unknown sender'
          : `You → ${msg.to || '—'}`;
      head.textContent = `${who} · ${fmtPanelDate(msg.internalDate || msg.createdAt)}`;
      block.appendChild(head);
      const body = document.createElement('div');
      body.className = 'inbox-body';
      const html = String(msg.bodyHtml || '').trim();
      if (html) body.innerHTML = sanitizeMailHtml(html);
      else body.textContent = msg.body || msg.snippet || '';
      block.appendChild(body);
      $('panel-inbox-body').appendChild(block);
    });
  }
  $('panel-inbox-reply').classList.remove('hidden');
}

function closePanelInboxMessage() {
  em.inboxSelected = null;
  em.inboxThreadMessages = [];
  $('panel-inbox-detail').classList.add('hidden');
}

function applyTemplateToForm(templateId) {
  const templates = em.status?.templates || [];
  const tpl = templates.find((t) => t.id === templateId);
  if (!tpl) return;
  $('subject').value = tpl.subject || '';
  $('body-text').value = tpl.body || '';
}

function fillTemplateSelect() {
  const select = $('template');
  const templates = em.status?.templates || [];
  const current = select.value === '__add_template__' ? '' : select.value;
  select.innerHTML = '<option value="__add_template__">+ Add new template</option>';
  const sep = document.createElement('option');
  sep.disabled = true;
  sep.textContent = '────────';
  select.appendChild(sep);
  const none = document.createElement('option');
  none.value = '';
  none.textContent = '— No template / custom —';
  select.appendChild(none);
  templates.forEach((t) => {
    const opt = document.createElement('option');
    opt.value = t.id;
    opt.textContent = t.name + (t.isDefault ? ' (default)' : '');
    select.appendChild(opt);
  });
  const preferred =
    (current && templates.some((t) => t.id === current) && current) ||
    templates.find((t) => t.isDefault)?.id ||
    '';
  select.value = preferred;
  if (preferred) applyTemplateToForm(preferred);
}

function switchMarkup(checked, locked) {
  return (
    '<label class="sw-wrap' +
    (locked ? ' is-locked' : '') +
    '"' +
    (locked ? ' title="Ask an admin to enable this email"' : '') +
    '>' +
    '<span class="sw-text">Use default</span>' +
    '<span class="sw"><input class="def-sw" type="checkbox"' +
    (checked ? ' checked' : '') +
    (locked ? ' disabled' : '') +
    ' /><span class="track"></span></span></label>'
  );
}

function bindSwitch(root, onToggle) {
  const input = root.querySelector('.def-sw');
  if (!input) return;
  input.addEventListener('change', async () => {
    const next = input.checked;
    input.disabled = true;
    try {
      const ok = await onToggle(next);
      if (!ok) input.checked = !next;
    } catch (err) {
      input.checked = !next;
      toast(err.message || 'Could not update default', false);
    } finally {
      input.disabled = false;
    }
  });
}

function methodLabel(a) {
  if (a.method === 'smtp') return 'Custom SMTP';
  if (a.method === 'oauth') return 'Google';
  return 'App password';
}

function panelAccounts() {
  const list = em.status?.accounts;
  if (Array.isArray(list) && list.length) return list;
  if (em.status?.account) return [em.status.account];
  return [];
}

function emailLimits() {
  const l = em.status?.limits || {};
  return {
    maxAccounts: Number(l.maxEmailAccounts) || 0,
    maxTemplates: Number(l.maxTemplates) || 0,
    accountsUsed: Number(l.emailAccountsUsed != null ? l.emailAccountsUsed : panelAccounts().length) || 0,
    templatesUsed:
      Number(l.templatesUsed != null ? l.templatesUsed : (em.status?.templates || []).length) || 0
  };
}

function atAccountLimit() {
  const l = emailLimits();
  return l.maxAccounts > 0 && l.accountsUsed >= l.maxAccounts;
}

function atTemplateLimit() {
  const l = emailLimits();
  return l.maxTemplates > 0 && l.templatesUsed >= l.maxTemplates;
}

function isAccountUsable(a) {
  if (!a) return false;
  if (typeof a.usable === 'boolean') return a.usable;
  if (typeof a.allowed === 'boolean') return a.allowed;
  return false;
}

function accountLimitMessage() {
  const l = emailLimits();
  const extra = Math.max(0, l.accountsUsed - l.maxAccounts);
  if (extra > 0) {
    return (
      l.maxAccounts +
      ' of ' +
      l.accountsUsed +
      ' emails can send. Ask an admin to enable which inboxes you can use.'
    );
  }
  if (l.maxAccounts === 1) {
    return 'Your account allows 1 connected email. Ask an admin to remove one before adding another.';
  }
  return 'Your account allows ' + l.maxAccounts + ' connected emails. Ask an admin to remove one before adding another.';
}

function templateLimitMessage() {
  const l = emailLimits();
  if (l.maxTemplates === 1) {
    return 'Your account allows 1 template. Delete one to create another.';
  }
  return 'Your account allows ' + l.maxTemplates + ' templates. Delete one to create another.';
}

function renderAccountsList() {
  const wrap = $('accounts-list');
  if (!wrap) return;
  const list = panelAccounts();
  wrap.innerHTML = '';
  list.forEach((a) => {
    const el = document.createElement('div');
    el.className =
      'account-item' +
      (a.isDefault ? ' is-default' : '') +
      (isAccountUsable(a) ? '' : ' is-over-limit');
    el.innerHTML =
      '<div class="name"></div><div class="meta"></div><div class="template-actions">' +
      switchMarkup(!!a.isDefault, !isAccountUsable(a)) +
      '</div>';
    el.querySelector('.name').textContent = a.email;
    el.querySelector('.meta').textContent = isAccountUsable(a)
      ? methodLabel(a) + (a.isDefault ? ' · Used to send' : '')
      : methodLabel(a) + ' · Disabled · ask admin to enable';
    bindSwitch(el, async (next) => {
      if (!isAccountUsable(a)) {
        toast('This email is disabled. Ask an admin to enable it.', false);
        return false;
      }
      if (!next) {
        toast('Turn on another account to change the default', false);
        return false;
      }
      if (a.isDefault) return true;
      const res = await send('EMAIL_SET_DEFAULT', { payload: { accountId: a.id } });
      if (!res?.success) {
        toast(res?.message || 'Could not set default account', false);
        return false;
      }
      toast('Default account: ' + a.email);
      await loadStatus();
      return true;
    });
    wrap.appendChild(el);
  });
}

function renderTemplatesList() {
  const list = $('template-list');
  const templates = em.status?.templates || [];
  if (!templates.length) {
    list.innerHTML = '<div class="empty">No templates yet. Create one above.</div>';
    return;
  }
  list.innerHTML = '';
  templates.forEach((t) => {
    const el = document.createElement('div');
    el.className = 'template-item' + (t.isDefault ? ' is-default' : '');
    el.innerHTML =
      '<div class="name"></div><div class="meta"></div><div class="template-actions">' +
      switchMarkup(!!t.isDefault) +
      '<button class="btn btn-secondary use" type="button">Use</button>' +
      '<button class="btn btn-secondary edit" type="button">Edit</button>' +
      '<button class="btn btn-danger del" type="button">Delete</button></div>';
    el.querySelector('.name').textContent = t.name + (t.isDefault ? ' · Default' : '');
    el.querySelector('.meta').textContent = t.subject;
    bindSwitch(el, async (next) => {
      if (!!t.isDefault === next) return true;
      const res = await send('EMAIL_UPDATE_TEMPLATE', {
        id: t.id,
        payload: { isDefault: next }
      });
      if (!res?.success) {
        toast(res?.message || 'Could not update default template', false);
        return false;
      }
      toast(next ? 'Default template: ' + t.name : t.name + ' is no longer the default');
      await loadStatus();
      return true;
    });
    el.querySelector('.use').addEventListener('click', () => {
      setEmTab('compose');
      $('template').value = t.id;
      applyTemplateToForm(t.id);
    });
    el.querySelector('.edit').addEventListener('click', () => {
      $('tpl-id').value = t.id;
      $('tpl-name').value = t.name;
      $('tpl-subject').value = t.subject;
      $('tpl-body').value = t.body;
      $('tpl-default').checked = !!t.isDefault;
      $('template-form-title').textContent = 'Edit template';
      if ($('tpl-ai-prompt')) $('tpl-ai-prompt').value = '';
      setTplAiStatus('');
    });
    el.querySelector('.del').addEventListener('click', async () => {
      if (!confirm('Delete this template?')) return;
      const res = await send('EMAIL_DELETE_TEMPLATE', { id: t.id });
      if (!res?.success) return toast(res?.message || 'Delete failed', false);
      toast('Template deleted');
      await loadStatus();
    });
    list.appendChild(el);
  });
}

function renderAccountShell() {
  const signedIn = Boolean(em.session?.signedIn);
  $('desk-login').classList.toggle('hidden', signedIn);
}

function renderEmail() {
  renderAccountShell();
  const signedIn = Boolean(em.session?.signedIn);
  const list = panelAccounts();
  const hasAccounts = list.length > 0;
  const canSend = list.some(isAccountUsable);
  const account =
    list.find((a) => a.isDefault && isAccountUsable(a)) ||
    list.find(isAccountUsable) ||
    null;
  const oauthAvailable = Boolean(em.status?.oauthAvailable);
  const showConnect = signedIn && em.connectPanelOpen && !em.oauthWaiting;
  const showEmpty = signedIn && !hasAccounts && !showConnect && !em.oauthWaiting;

  $('compose-blocked').classList.toggle('hidden', canSend);
  $('compose-form').classList.toggle('hidden', !canSend);
  $('account-connected').classList.toggle('hidden', !(signedIn && hasAccounts && !showConnect && !em.oauthWaiting));
  $('account-empty')?.classList.toggle('hidden', !showEmpty);
  $('account-connect').classList.toggle('hidden', !showConnect);
  $('oauth-wait')?.classList.toggle('hidden', !em.oauthWaiting);
  $('choice-oauth').style.display = oauthAvailable && !em.oauthWaiting ? '' : 'none';
  document.querySelector('.connect-choice')?.classList.toggle('hidden', em.oauthWaiting);

  if (canSend && account) {
    $('from-pill').textContent = account.email;
  }

  if (em.recipient && !$('to').value) $('to').value = em.recipient;
  fillTemplateSelect();
  renderTemplatesList();
  renderAccountsList();

  const addBtn = $('btn-add-account');
  if (addBtn) addBtn.classList.toggle('hidden', atAccountLimit());
  const lim = emailLimits();
  const accHint = $('account-connected')?.querySelector('.hint');
  if (accHint) {
    accHint.textContent = atAccountLimit()
      ? accountLimitMessage()
      : lim.maxAccounts
        ? 'Turn on Use default among enabled emails. Extra inboxes stay off until an admin enables them. ' +
          lim.accountsUsed +
          ' of ' +
          lim.maxAccounts +
          ' emails connected.'
        : 'Turn on Use default for the account used when sending.';
  }
  const tplHint = $('tpl-list-hint');
  if (tplHint) {
    tplHint.textContent = atTemplateLimit()
      ? templateLimitMessage()
      : 'Turn on Use default for the template used when sending.';
  }
}

async function loadSession() {
  const res = await send('GET_SESSION');
  em.session = res?.success ? res.data : { signedIn: false, apiBase: '' };
}

async function loadStatus() {
  await loadSession();
  if (!em.session?.signedIn) {
    em.status = null;
    renderEmail();
    setEmTab('account');
    return;
  }
  const res = await send('EMAIL_STATUS');
  if (!res?.success) {
    toast(res?.message || 'Failed to load email status', false);
    em.status = null;
    renderEmail();
    return;
  }
  em.status = res.data;
  renderEmail();
}

function resetTemplateForm() {
  $('tpl-id').value = '';
  $('tpl-name').value = '';
  $('tpl-subject').value = '';
  $('tpl-body').value = '';
  $('tpl-default').checked = false;
  $('template-form-title').textContent = 'New template';
  if ($('tpl-ai-prompt')) $('tpl-ai-prompt').value = '';
  setTplAiStatus('');
}

function setTplAiStatus(text, isErr) {
  const el = $('tpl-ai-status');
  if (!el) return;
  const msg = String(text || '').trim();
  el.textContent = msg;
  el.classList.toggle('is-err', Boolean(isErr));
  el.classList.toggle('is-ok', Boolean(msg) && !isErr && /filled/i.test(msg));
  el.hidden = !msg;
}

function setTplAiBusy(busy) {
  const wrap = $('tpl-ai');
  const btn = $('btn-tpl-ai');
  const input = $('tpl-ai-prompt');
  wrap?.classList.toggle('is-busy', busy);
  wrap?.setAttribute('aria-busy', busy ? 'true' : 'false');
  if (input) input.disabled = busy;
  wrap?.querySelectorAll('.ai-suggest button').forEach((chip) => {
    chip.disabled = busy;
  });
  if (!btn) return;
  btn.disabled = busy;
  btn.setAttribute('aria-label', busy ? 'Writing draft' : 'Write draft with AI');
  btn.innerHTML = busy
    ? '<span class="ai-spin" aria-hidden="true"></span>'
    : 'Write';
}

let tplAiSeq = 0;

async function generateTplWithAi() {
  const prompt = ($('tpl-ai-prompt')?.value || '').trim();
  const payload = {
    prompt,
    name: ($('tpl-name')?.value || '').trim(),
    subject: ($('tpl-subject')?.value || '').trim(),
    body: $('tpl-body')?.value || '',
    mode: ($('tpl-id')?.value || '').trim() ? 'edit' : 'create'
  };
  if (!payload.prompt && !payload.subject && !String(payload.body).trim()) {
    setTplAiStatus('Describe the email, or pick a suggestion.', true);
    return;
  }
  const seq = ++tplAiSeq;
  setTplAiBusy(true);
  setTplAiStatus('Writing…');
  try {
    const res = await send('EMAIL_AI_TEMPLATE', { payload });
    if (seq !== tplAiSeq) return;
    if (!res?.success) throw new Error(res?.message || 'Could not write that template');
    const draft = res.data?.template;
    if (!draft?.subject || !draft?.body) throw new Error('AI returned an empty draft');
    if (draft.name) $('tpl-name').value = draft.name;
    $('tpl-subject').value = draft.subject;
    $('tpl-body').value = draft.body;
    setTplAiStatus('Draft filled — review and save.');
    toast('AI draft ready — review before saving');
  } catch (err) {
    if (seq !== tplAiSeq) return;
    setTplAiStatus(err.message || 'Could not write that template', true);
    toast(err.message || 'Could not write that template', false);
  } finally {
    if (seq === tplAiSeq) setTplAiBusy(false);
  }
}

function applyRecipient(email) {
  const value = String(email || '').trim();
  if (!value) return;
  em.recipient = value;
  $('to').value = value;
}

document.querySelectorAll('.em-tab').forEach((btn) => {
  btn.addEventListener('click', () => setEmTab(btn.dataset.tab));
});
$('panel-inbox-account')?.addEventListener('change', () => {
  em.inboxAccountId = $('panel-inbox-account').value;
  loadPanelInbox();
});
document.querySelectorAll('#panel-inbox-folders .inbox-folder').forEach((btn) => {
  btn.addEventListener('click', () => {
    em.inboxFolder = btn.dataset.folder === 'sent' ? 'sent' : 'received';
    document.querySelectorAll('#panel-inbox-folders .inbox-folder').forEach((el) => {
      el.classList.toggle('active', el === btn);
    });
    loadPanelInbox();
  });
});
$('panel-inbox-search')?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') loadPanelInbox();
});
$('panel-inbox-sync')?.addEventListener('click', async () => {
  if (!em.inboxAccountId) return toast('Select an account first', false);
  try {
    const res = await send('EMAIL_MAILBOX_SYNC', {
      payload: { accountId: em.inboxAccountId, limit: 30 }
    });
    if (!res?.success) throw new Error(res?.message || 'Sync failed');
    toast(res.data?.message || 'Inbox synced');
    await loadPanelInbox();
  } catch (err) {
    toast(err.message || 'Could not sync inbox', false);
  }
});
$('panel-inbox-compose')?.addEventListener('click', () => setEmTab('compose'));
$('panel-inbox-back')?.addEventListener('click', () => closePanelInboxMessage());
$('panel-inbox-reply')?.addEventListener('click', () => {
  const conv = em.inboxSelected;
  if (!conv) return;
  const root = conv.rootSubject || conv.subject || '';
  em.inboxReplyContext = {
    replyToEmailSentId: conv.emailSentId,
    conversationKey: conv.conversationKey
  };
  setEmTab('compose');
  $('to').value = conv.to || '';
  $('subject').value = /^re:/i.test(String(conv.subject || '').trim()) ? conv.subject : `Re: ${root}`;
  $('body-text').value = '';
});
$('goto-account').addEventListener('click', () => setEmTab('account'));
$('btn-close').addEventListener('click', () => {
  window.parent.postMessage({ type: 'DAT_EMAIL_CLOSE' }, '*');
});
$('btn-refresh').addEventListener('click', () => loadStatus());
$('template').addEventListener('change', () => {
  if ($('template').value === '__add_template__') {
    $('template').value = '';
    setEmTab('templates');
    return;
  }
  if ($('template').value) applyTemplateToForm($('template').value);
});
$('choice-app-password').addEventListener('click', () => {
  $('choice-oauth').classList.add('hidden');
  $('choice-app-password').classList.add('hidden');
  $('app-form').classList.remove('hidden');
});

let oauthLaunchLock = false;

async function startGoogleOAuth() {
  if (em.oauthWaiting || oauthLaunchLock) return;
  oauthLaunchLock = true;
  try {
    const res = await send('EMAIL_OAUTH_URL');
    if (!res?.success) return toast(res?.message || 'Google sign-in is not available right now.', false);
    const url = res.data?.url;
    if (!url) return toast('Could not start Google sign-in. Please try again.', false);

    const previous = (em.status?.accounts || (em.status?.account ? [em.status.account] : [])).map((a) => ({
      email: a.email,
      connectedAt: a.connectedAt
    }));
    const seq = ++oauthWaitSeq;
    em.connectPanelOpen = false;
    em.oauthWaiting = true;
    renderEmail();
    toast('Finish Google sign-in in the popup window');

    const findNew = (list) => {
      const prev = new Set(previous.map((a) => String(a.email || '').toLowerCase()));
      const prevTimes = new Map(
        previous.map((a) => [String(a.email || '').toLowerCase(), Date.parse(a.connectedAt || 0) || 0])
      );
      return (list || []).find((a) => {
        const email = String(a.email || '').toLowerCase();
        if (!prev.has(email)) return true;
        return (Date.parse(a.connectedAt || 0) || 0) > (prevTimes.get(email) || 0);
      }) || null;
    };

    const opened = await send('OPEN_GOOGLE_OAUTH', { url });
    if (!opened?.success || opened.via !== 'host') {
      const w = 520;
      const h = 720;
      const left = Math.max(0, Math.round((window.screen.width - w) / 2));
      const top = Math.max(0, Math.round((window.screen.height - h) / 2));
      window.open(
        url,
        'dat-gmail-oauth',
        `popup=yes,width=${w},height=${h},left=${left},top=${top},resizable=yes,scrollbars=yes`
      );
    }

    const deadline = Date.now() + 3 * 60 * 1000;
    while (em.oauthWaiting && seq === oauthWaitSeq && Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 1200));
      if (!em.oauthWaiting || seq !== oauthWaitSeq) return;
      const statusRes = await send('EMAIL_STATUS');
      if (statusRes?.success) em.status = statusRes.data;
      const list = em.status?.accounts || (em.status?.account ? [em.status.account] : []);
      const found = findNew(list);
      if (found) {
        em.oauthWaiting = false;
        em.connectPanelOpen = false;
        toast('Email connected');
        await loadStatus();
        if (found.id) em.inboxAccountId = String(found.id);
        setEmTab('inbox');
        if (found.id) {
          await send('EMAIL_MAILBOX_SYNC', { payload: { accountId: found.id, limit: 30 } });
          await loadPanelInbox();
        }
        return;
      }
      const oauthRes = await send('EMAIL_OAUTH_RESULT');
      if (oauthRes?.data?.status === 'error') {
        em.oauthWaiting = false;
        em.connectPanelOpen = false;
        await loadStatus();
        toast(oauthRes.data.message || 'Google sign-in cancelled', false);
        return;
      }
    }

    if (seq === oauthWaitSeq && em.oauthWaiting) {
      toast('Finish sign-in in the Google window, or press Cancel', false);
    }
  } finally {
    oauthLaunchLock = false;
  }
}

$('choice-oauth').addEventListener('click', () => startGoogleOAuth());
$('btn-connect-gmail-empty')?.addEventListener('click', () => startGoogleOAuth());
$('btn-add-account-empty')?.addEventListener('click', () => {
  if (atAccountLimit()) return toast(accountLimitMessage(), false);
  em.connectPanelOpen = true;
  renderEmail();
});
$('btn-add-account')?.addEventListener('click', () => {
  if (atAccountLimit()) return toast(accountLimitMessage(), false);
  em.connectPanelOpen = true;
  renderEmail();
});
$('oauth-wait-cancel')?.addEventListener('click', () => {
  oauthWaitSeq += 1;
  em.oauthWaiting = false;
  em.connectPanelOpen = false;
  renderEmail();
  toast('Google connect cancelled', false);
});
$('btn-connect-app').addEventListener('click', async () => {
  const email = ($('app-email').value || '').trim();
  const appPassword = ($('app-pass').value || '').replace(/\s+/g, '');
  if (!email || !appPassword) return toast('Email and app password are required', false);
  $('btn-connect-app').disabled = true;
  $('btn-connect-app').textContent = 'Connecting…';
  startAppProgress();
  try {
    const res = await send('EMAIL_CONNECT_APP', {
      payload: { email, appPassword }
    });
    if (!res?.success) throw new Error(res?.message || 'Connect failed');
    toast('Email connected');
    $('app-pass').value = '';
    em.connectPanelOpen = false;
    await loadStatus();
    const connected =
      res.data?.account ||
      panelAccounts().find((a) => String(a.email || '').toLowerCase() === email.toLowerCase());
    if (connected?.id) {
      em.inboxAccountId = String(connected.id);
      await send('EMAIL_MAILBOX_SYNC', { payload: { accountId: connected.id, limit: 30 } });
    }
    setEmTab('inbox');
  } catch (err) {
    toast(err.message || 'Connect failed', false);
  } finally {
    stopAppProgress();
    $('btn-connect-app').disabled = false;
    $('btn-connect-app').textContent = 'Connect & sync inbox';
  }
});
$('btn-tpl-reset').addEventListener('click', resetTemplateForm);
$('btn-tpl-ai')?.addEventListener('click', () => generateTplWithAi());
$('tpl-ai-prompt')?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    generateTplWithAi();
  }
});
$('tpl-ai-suggest')?.addEventListener('click', (e) => {
  const chip = e.target.closest('[data-ai-suggest]');
  if (!chip || chip.disabled) return;
  const input = $('tpl-ai-prompt');
  if (input) input.value = chip.getAttribute('data-ai-suggest') || '';
  generateTplWithAi();
});
$('btn-tpl-save').addEventListener('click', async () => {
  const payload = {
    name: $('tpl-name').value.trim(),
    subject: $('tpl-subject').value.trim(),
    body: $('tpl-body').value,
    isDefault: $('tpl-default').checked
  };
  if (!payload.name || !payload.subject || !payload.body.trim()) {
    return toast('Name, subject, and body are required', false);
  }
  const id = $('tpl-id').value;
  if (!id && atTemplateLimit()) return toast(templateLimitMessage(), false);
  const res = id
    ? await send('EMAIL_UPDATE_TEMPLATE', { id, payload })
    : await send('EMAIL_CREATE_TEMPLATE', { payload });
  if (!res?.success) return toast(res?.message || 'Save failed', false);
  toast(id ? 'Template updated' : 'Template created');
  resetTemplateForm();
  await loadStatus();
});
$('btn-send').addEventListener('click', async () => {
  const to = $('to').value.trim();
  const subject = $('subject').value.trim();
  const body = $('body-text').value;
  const templateId = $('template').value || undefined;
  if (!to) return toast('Recipient is required', false);
  if (!subject || !body.trim()) return toast('Subject and body are required', false);
  $('btn-send').disabled = true;
  try {
    const replyCtx = em.inboxReplyContext || {};
    const res = await send('EMAIL_SEND', { payload: { to, subject, body, templateId, ...replyCtx } });
    if (!res?.success) throw new Error(res?.message || 'Send failed');
    em.inboxReplyContext = null;
    toast('Email sent');
    if (em.tab === 'inbox') loadPanelInbox();
  } catch (err) {
    toast(err.message || 'Send failed', false);
  } finally {
    $('btn-send').disabled = false;
  }
});
$('btn-login').addEventListener('click', async () => {
  const email = $('login-email').value.trim();
  const password = $('login-pass').value;
  if (!email || !password) {
    return toast('Email and password are required', false);
  }
  $('btn-login').disabled = true;
  try {
    const res = await send('LOGIN', {
      payload: { apiBase: em.session?.apiBase || '', email, password }
    });
    if (!res?.success) throw new Error(res?.message || 'Login failed');
    $('login-pass').value = '';
    toast('Signed in');
    await loadStatus();
    if (em.status?.connected) setEmTab('compose');
  } catch (err) {
    toast(err.message || 'Login failed', false);
  } finally {
    $('btn-login').disabled = false;
  }
});

window.addEventListener('message', (event) => {
  const data = event.data;
  if (!data || typeof data !== 'object') return;
  if (data.type === 'DAT_EMAIL_OPEN') {
    applyRecipient(data.recipient || '');
    loadStatus().then(() => {
      if (em.status?.connected) setEmTab('compose');
      else setEmTab('account');
    });
  }
  if (data.type === 'DAT_EMAIL_SET_RECIPIENT') {
    applyRecipient(data.recipient || '');
  }
});

document.addEventListener('click', (e) => {
  const btn = e.target && e.target.closest && e.target.closest('[data-pw-toggle]');
  if (!btn) return;
  e.preventDefault();
  togglePasswordVisibility(btn);
});
paintPasswordToggles();

loadStatus().then(() => {
  if (em.status?.connected) setEmTab('inbox');
  else setEmTab('account');
});
