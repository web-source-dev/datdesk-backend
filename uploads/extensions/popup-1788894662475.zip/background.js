'use strict';

/**
 * Signal — background service worker.
 * Handles auth + /email/* API. Content scripts own the UI.
 *
 * Local dev: both APIs point at http://localhost:7022 (see LOCAL_API below).
 * Production builds: switch LOCAL_API off or set USE_LOCAL_API = false.
 */

const USE_LOCAL_API = true;
const LOCAL_API = 'http://localhost:7022';
const PRODUCTION_PUBLIC_API = 'https://api.datdesk.apexskillzone.com';
const PRODUCTION_SMTP_API = 'https://datdesk.apexskillzone.com';
const STATUS_CACHE_TTL_MS = 45_000;
const SESSION_MEM_TTL_MS = 8_000;

/** @type {{ at: number, value: any }} */
let sessionMem = { at: 0, value: null };
/** @type {{ at: number, data: any }} */
let statusMem = { at: 0, data: null };
let statusInflight = null;

function normalizeApiBase(value) {
  const s = String(value || '')
    .trim()
    .replace(/\/+$/, '');
  if (s) return s;
  return USE_LOCAL_API ? LOCAL_API : PRODUCTION_PUBLIC_API;
}

function publicApiBase() {
  return USE_LOCAL_API ? LOCAL_API : PRODUCTION_PUBLIC_API;
}

function smtpApiBase() {
  return USE_LOCAL_API ? LOCAL_API : PRODUCTION_SMTP_API;
}

function looksLikeEmail(value) {
  const s = String(value || '').trim();
  return Boolean(s && s.includes('@') && !/^https?:\/\//i.test(s) && s.length < 160);
}

function decodeJwtEmail(token) {
  try {
    const raw = String(token || '')
      .replace(/^Bearer\s+/i, '')
      .trim();
    const part = raw.split('.')[1];
    if (!part) return null;
    const padded = part.replace(/-/g, '+').replace(/_/g, '/');
    const json = atob(padded + '='.repeat((4 - (padded.length % 4)) % 4));
    const payload = JSON.parse(json);
    const email = payload.email || payload.userEmail || '';
    return looksLikeEmail(email) ? String(email).trim() : null;
  } catch {
    return null;
  }
}

async function readInjectedSession() {
  try {
    const res = await fetch(chrome.runtime.getURL('desk_session.json'), { cache: 'no-store' });
    if (!res.ok) return null;
    const data = await res.json();
    const token = String(data?.token || '').trim();
    if (!token) return null;
    const userEmail = looksLikeEmail(data?.userEmail)
      ? String(data.userEmail).trim()
      : decodeJwtEmail(token);
    return {
      apiBase: normalizeApiBase(data.apiBase),
      token,
      source: 'desk',
      userEmail: userEmail || null
    };
  } catch {
    return null;
  }
}

async function getSession() {
  if (sessionMem.value && Date.now() - sessionMem.at < SESSION_MEM_TTL_MS) {
    return sessionMem.value;
  }

  const flags = await chrome.storage.local.get(['loggedOut', 'apiBase', 'token', 'source', 'userEmail']);
  if (flags.loggedOut) {
    const value = {
      apiBase: normalizeApiBase(flags.apiBase),
      token: '',
      source: 'none',
      userEmail: null
    };
    sessionMem = { at: Date.now(), value };
    return value;
  }

  const injected = await readInjectedSession();
  if (injected) {
    const userEmail = injected.userEmail || (looksLikeEmail(flags.userEmail) ? flags.userEmail : null);
    await chrome.storage.local.set({
      apiBase: injected.apiBase,
      token: injected.token,
      source: 'desk',
      userEmail: userEmail || ''
    });
    const value = { ...injected, userEmail };
    sessionMem = { at: Date.now(), value };
    return value;
  }

  if (flags.token) {
    const userEmail =
      (looksLikeEmail(flags.userEmail) ? String(flags.userEmail).trim() : null) ||
      decodeJwtEmail(flags.token);
    const value = {
      apiBase: normalizeApiBase(flags.apiBase),
      token: String(flags.token),
      source: flags.source || 'manual',
      userEmail
    };
    sessionMem = { at: Date.now(), value };
    return value;
  }
  const value = { apiBase: publicApiBase(), token: '', source: 'none', userEmail: null };
  sessionMem = { at: Date.now(), value };
  return value;
}

function persistStatusCache(data, at) {
  if (!data) return;
  const ts = Number(at) || Date.now();
  if (statusMem.at && ts < statusMem.at) return;
  statusMem = { at: ts, data };
  try {
    chrome.storage.local.set({ emailStatusCache: statusMem });
  } catch {
    // ignore
  }
}

function clearStatusCache() {
  statusMem = { at: 0, data: null };
  try {
    chrome.storage.local.remove('emailStatusCache');
  } catch {
    // ignore
  }
}

function invalidateSessionMem() {
  sessionMem = { at: 0, value: null };
}

async function fetchEmailStatus(force) {
  const now = Date.now();
  if (!force && statusMem.data && now - statusMem.at < STATUS_CACHE_TTL_MS) {
    if (now - statusMem.at > 8_000 && !statusInflight) {
      fetchEmailStatus(true).catch(() => {});
    }
    return statusMem.data;
  }
  if (statusInflight) return statusInflight;

  const run = (async () => {
    const started = Date.now();
    const data = await apiRequest('GET', '/email/status');
    persistStatusCache(data, started);
    return statusMem.data || data;
  })();

  statusInflight = run;
  try {
    return await run;
  } finally {
    if (statusInflight === run) statusInflight = null;
  }
}

function prefetchEmailStatus() {
  fetchEmailStatus(false).catch(() => {});
}

function stripInternalDetails(text) {
  return String(text || '')
    .replace(/https?:\/\/[^\s"'<>)\]]+/gi, '')
    .replace(/\b(?:localhost|127\.0\.0\.1)(?::\d+)?\b/gi, '')
    .replace(/\b[\w.-]*apexskillzone\.com\b/gi, '')
    .replace(/\bGOOGLE_[A-Z0-9_]+\b/g, '')
    .replace(/\b(?:ECONNREFUSED|ENOTFOUND|ECONNRESET|ETIMEDOUT)\b/gi, '')
    .replace(/\(\s*\d{3}\s*\)/g, '')
    .replace(/\s{2,}/g, ' ')
    .replace(/\s+([.,;:!])/g, '$1')
    .trim();
}

function friendlyUiError(err, fallback) {
  const code = err && err.code;
  if (code === 'NO_TOKEN') return 'Sign in on the Account tab first.';
  if (code === 'LOCAL_AUTH_REQUIRED') return 'Please sign in again, then try connecting your email.';
  if (code === 'SMTP_EGRESS_BLOCKED') {
    return 'Could not reach the mail server. Check the SMTP host and try again.';
  }
  if (code === 'SMTP_NEEDS_LOCAL' || code === 'SMTP_BLOCKED' || code === 'SMTP_TIMEOUT') {
    return String((err && err.message) || 'SMTP connection timed out. Check host, port, and SSL.');
  }
  if (code === 'GMAIL_USE_OAUTH') {
    return 'Gmail SMTP failed. Try Connect Gmail, or start the Signal backend on this PC.';
  }
  if (code === 'OAUTH_NEEDS_LOCAL' || code === 'OAUTH_NOT_CONFIGURED') {
    return 'Google sign-in is not available right now. You can connect with an app password instead.';
  }
  if (code === 'EMAIL_ACCOUNT_LIMIT' || code === 'EMAIL_TEMPLATE_LIMIT') {
    return String((err && err.message) || 'That limit has been reached.');
  }
  if (code === 'EMAIL_ACCOUNT_UNUSABLE') {
    return String((err && err.message) || 'This email is over your limit and cannot send. Ask an admin to enable it.');
  }
  if (code === 'NETWORK') return 'Cannot reach the server. Check your connection and try again.';
  if (code === 'AI_NOT_CONFIGURED' || code === 'AI_NETWORK' || code === 'AI_PROVIDER_ERROR') {
    return String((err && err.message) || 'AI helper is not available right now. Try again.');
  }
  if (code === 'AI_TIMEOUT') return 'AI took too long. Try a shorter request.';
  if (code === 'AI_PROMPT_REQUIRED') {
    return 'Describe the email you want, or keep a draft in the form.';
  }

  const raw = String((err && err.message) || err || '');
  if (/missing GOOGLE_|OAUTH_NOT_CONFIGURED|not configured on this API/i.test(raw)) {
    return 'Google sign-in is not available right now. You can connect with an app password instead.';
  }
  if (/local backend|cloud API|SMTP is blocked|token mismatch|JWT/i.test(raw)) {
    return 'Could not complete that request. Please sign in again and try once more.';
  }
  const cleaned = stripInternalDetails(raw);
  if (!cleaned || cleaned.length < 3) {
    return fallback || 'Something went wrong. Please try again.';
  }
  return cleaned;
}

function smtpClientLog(...args) {
  console.log('[Signal SMTP]', ...args);
}

async function rawApiRequest(apiBase, token, method, path, body) {
  if (!token) {
    const err = new Error('Sign in on the Account tab first.');
    err.code = 'NO_TOKEN';
    throw err;
  }

  const url = `${String(apiBase).replace(/\/+$/, '')}${path.startsWith('/') ? path : `/${path}`}`;
  const headers = {
    Authorization: token,
    Accept: 'application/json'
  };
  if (body != null) headers['Content-Type'] = 'application/json';

  const smtpish = /\/email\/(connect\/smtp|connect\/app-password|send)/.test(path);
  smtpClientLog(method, path, '→', String(apiBase).replace(/\/+$/, ''));

  let res;
  try {
    res = await fetch(url, {
      method,
      headers,
      body: body == null ? undefined : JSON.stringify(body)
    });
  } catch (networkErr) {
    smtpClientLog('network error', path, networkErr?.message || networkErr);
    const err = new Error('Cannot reach the server. Check your connection and try again.');
    err.code = 'NETWORK';
    throw err;
  }

  let data = null;
  try {
    data = await res.json();
  } catch {
    data = null;
  }

  if (!res.ok) {
    smtpClientLog('http', res.status, path, data?.code || '', data?.message || '');
    const err = new Error(
      smtpish
        ? String(data?.message || 'SMTP request failed')
        : friendlyUiError(
            { message: data?.message, code: data?.code },
            'Request failed. Please try again.'
          )
    );
    err.status = res.status;
    err.code = data?.code;
    err.data = data;
    throw err;
  }
  smtpClientLog('ok', res.status, path);
  return data;
}

async function apiRequest(method, path, body) {
  const session = await getSession();
  return rawApiRequest(session.apiBase, session.token, method, path, body);
}

function buildQuery(params) {
  const q = new URLSearchParams();
  Object.entries(params || {}).forEach(([key, value]) => {
    if (value == null || value === '') return;
    q.set(key, String(value));
  });
  const s = q.toString();
  return s ? `?${s}` : '';
}

async function apiRequestSmtp(method, path, body) {
  const session = await getSession();
  if (!session.token) {
    const err = new Error('Sign in on the Account tab first.');
    err.code = 'NO_TOKEN';
    throw err;
  }
  smtpClientLog('attempt', method, path, smtpApiBase());
  return rawApiRequest(smtpApiBase(), session.token, method, path, body);
}

async function syncSmtpAccountToPublicApi(payload) {
  try {
    const session = await getSession();
    await rawApiRequest(publicApiBase(), session.token, 'POST', '/email/connect/smtp', {
      ...payload,
      skipVerify: true,
      clientVerified: true
    });
    smtpClientLog('synced mailbox to main API');
  } catch (err) {
    smtpClientLog('main API sync skipped', err.code || '', err.message || '');
  }
}

function accountMethodFromStatus(accountId, status) {
  const accounts = Array.isArray(status?.accounts) ? status.accounts : [];
  const match = accounts.find((a) => String(a.id) === String(accountId || ''));
  return String(match?.method || status?.account?.method || '');
}

async function resolveMailboxMethod(accountId) {
  let method = accountMethodFromStatus(accountId, statusMem.data);
  if (method) return method;
  try {
    const status = await fetchEmailStatus(true);
    return accountMethodFromStatus(accountId, status);
  } catch {
    return '';
  }
}

function sanitizeSmtpPayload(payload) {
  const p = payload && typeof payload === 'object' ? { ...payload } : {};
  if (typeof p.password === 'string') p.password = p.password.replace(/\s+/g, '');
  if (typeof p.appPassword === 'string') p.appPassword = p.appPassword.replace(/\s+/g, '');
  const port = Number(p.smtpPort) || 0;
  const host = String(p.smtpHost || '').toLowerCase();
  if (port === 465) p.smtpSecure = true;
  else if (port === 587) p.smtpSecure = false;
  if ((host === 'smtp.gmail.com' || host === 'smtp.googlemail.com') && !port) {
    p.smtpPort = 587;
    p.smtpSecure = false;
  }
  return p;
}

function isGoogleOAuthUrl(raw) {
  try {
    const u = new URL(String(raw || ''));
    if (u.protocol !== 'https:') return false;
    const host = u.hostname.toLowerCase();
    const pathName = u.pathname || '';
    if (host !== 'accounts.google.com') return false;
    return (
      pathName.startsWith('/o/oauth2/') ||
      pathName.startsWith('/signin/oauth') ||
      (pathName.toLowerCase().includes('oauth') && u.searchParams.has('client_id'))
    );
  } catch {
    return false;
  }
}

async function collectDatTabIds(preferredTabId) {
  const ids = [];
  const add = (id) => {
    const n = Number(id);
    if (Number.isInteger(n) && n > 0 && !ids.includes(n)) ids.push(n);
  };
  add(preferredTabId);
  try {
    const tabs = await chrome.tabs.query({ url: ['*://one.dat.com/*', '*://*.dat.com/*'] });
    for (const tab of tabs) add(tab?.id);
  } catch {
    // ignore
  }
  return ids;
}

async function hostSmtpCall(method, config, sender) {
  const tabIds = await collectDatTabIds(sender?.tab?.id);
  smtpClientLog('host smtp', method, 'tabs', tabIds.length);
  for (const tabId of tabIds) {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        func: async (fn, cfg) => {
          try {
            const api = window.electron;
            if (!api || typeof api[fn] !== 'function') return { ok: false, via: 'none' };
            const res = await api[fn](cfg);
            if (res && res.ok) return { ok: true, via: 'host', ...res };
            return { ok: false, via: 'host', message: res?.message || 'SMTP failed', code: res?.code || '' };
          } catch (err) {
            return { ok: false, via: 'fail', message: err?.message || 'SMTP failed' };
          }
        },
        args: [method, config]
      });
      const result = results?.[0]?.result;
      if (!result || result.via === 'none') continue;
      smtpClientLog('host smtp result', method, result.ok, result.message || '');
      return result;
    } catch (err) {
      smtpClientLog('host smtp inject fail', err?.message || err);
    }
  }
  return { ok: false, via: 'none' };
}

/**
 * Ask Dat Desk (Electron preload on the DAT page) to open a real Chrome/Edge
 * Google sign-in popup. Embedded Chromium is blocked by Google.
 */
async function openGoogleOAuth(rawUrl, sender) {
  const url = String(rawUrl || '');
  if (!isGoogleOAuthUrl(url)) {
    return { success: false, message: 'Invalid Google OAuth URL' };
  }

  const tabIds = await collectDatTabIds(sender?.tab?.id);
  for (const tabId of tabIds) {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        func: async (oauthUrl) => {
          try {
            if (window.electron?.openGoogleOAuth) {
              await window.electron.openGoogleOAuth(oauthUrl);
              return 'host';
            }
          } catch {
            return 'fail';
          }
          return 'none';
        },
        args: [url]
      });
      if (results?.[0]?.result === 'host') {
        return { success: true, via: 'host' };
      }
    } catch {
      // try next DAT tab
    }
  }

  return { success: true, via: 'popup' };
}

async function openExternalUrl(rawUrl, sender) {
  const url = String(rawUrl || '');
  if (!/^https:\/\//i.test(url)) {
    return { success: false, message: 'Invalid URL' };
  }

  const tabIds = await collectDatTabIds(sender?.tab?.id);
  for (const tabId of tabIds) {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        func: async (targetUrl) => {
          try {
            if (window.electron?.openExternalUrl) {
              await window.electron.openExternalUrl(targetUrl);
              return 'host';
            }
            if (window.electron?.shell?.openExternal) {
              await window.electron.shell.openExternal(targetUrl);
              return 'host';
            }
          } catch {
            return 'fail';
          }
          return 'none';
        },
        args: [url]
      });
      if (results?.[0]?.result === 'host') {
        return { success: true, via: 'host' };
      }
    } catch {
      // try next DAT tab
    }
  }

  try {
    await chrome.tabs.create({ url, active: true });
    return { success: true, via: 'tab' };
  } catch {
    return { success: false, message: 'Could not open that page' };
  }
}

async function login({ email, password }) {
  const base = publicApiBase();
  if (!base) throw new Error('Sign in is not available right now. Please try again.');
  if (!email || !password) throw new Error('Email and password are required');

  let res;
  try {
    res = await fetch(`${base}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ email, password, client: 'extension' })
    });
  } catch {
    throw new Error('Cannot reach the server. Check your connection and try again.');
  }

  let data = null;
  try {
    data = await res.json();
  } catch {
    data = null;
  }
  if (!res.ok) throw new Error(friendlyUiError({ message: data?.message }, 'Login failed. Please try again.'));
  if (!data?.token) throw new Error('Login failed. Please try again.');

  await chrome.storage.local.set({
    apiBase: base,
    token: data.token,
    source: 'manual',
    userEmail: looksLikeEmail(data.email) ? String(data.email).trim() : email,
    loggedOut: false
  });
  return { success: true, email: looksLikeEmail(data.email) ? String(data.email).trim() : email };
}

async function logout() {
  await chrome.storage.local.set({ loggedOut: true });
  await chrome.storage.local.remove(['token', 'source', 'userEmail']);
  return { success: true };
}

async function ensureContentScript(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['templateVars.js', 'content.js', 'rowActions.js']
    });
  } catch (err) {
    return { success: false, message: err.message || 'Inject failed' };
  }
  return { success: true };
}

function isDatUrl(url) {
  try {
    const u = new URL(String(url || ''));
    return u.hostname === 'one.dat.com' || u.hostname.endsWith('.dat.com');
  } catch {
    return false;
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    try {
      switch (message?.type) {
        case 'PING':
          return { success: true, pong: true };

        case 'EMAIL_CACHE_STATUS': {
          if (message.data) persistStatusCache(message.data, message.at);
          return { success: true };
        }

        case 'GET_SESSION': {
          const session = await getSession();
          if (session.token) prefetchEmailStatus();
          return {
            success: true,
            data: {
              apiBase: session.apiBase,
              signedIn: Boolean(session.token),
              source: session.source,
              userEmail: session.userEmail || null
            }
          };
        }

        case 'LOGIN': {
          invalidateSessionMem();
          clearStatusCache();
          const result = await login(message.payload || {});
          prefetchEmailStatus();
          return result;
        }

        case 'LOGOUT':
          invalidateSessionMem();
          clearStatusCache();
          return await logout();

        case 'EMAIL_STATUS': {
          const data = await fetchEmailStatus(Boolean(message.force));
          return { success: true, data, cached: !message.force && Date.now() - statusMem.at < STATUS_CACHE_TTL_MS };
        }

        case 'EMAIL_CONNECT_APP': {
          clearStatusCache();
          const payload = sanitizeSmtpPayload(message.payload);
          const data = await apiRequestSmtp('POST', '/email/connect/app-password', payload);
          await syncSmtpAccountToPublicApi({
            email: payload.email,
            password: payload.password || payload.appPassword,
            smtpUser: payload.smtpUser || payload.email,
            smtpHost: payload.smtpHost || 'smtp.gmail.com',
            smtpPort: payload.smtpPort || 587,
            smtpSecure: false,
            displayName: payload.displayName || ''
          });
          return { success: true, data };
        }

        case 'EMAIL_CONNECT_SMTP': {
          clearStatusCache();
          const payload = sanitizeSmtpPayload(message.payload);
          const data = await apiRequestSmtp('POST', '/email/connect/smtp', payload);
          await syncSmtpAccountToPublicApi(payload);
          return { success: true, data };
        }

        case 'EMAIL_SET_DEFAULT': {
          const data = await apiRequest('POST', '/email/accounts/default', message.payload);
          if (Array.isArray(data?.accounts) && statusMem.data) {
            persistStatusCache({
              ...statusMem.data,
              accounts: data.accounts,
              account: data.account || data.accounts.find((a) => a.isDefault) || data.accounts[0] || null,
              connected: data.accounts.length > 0
            });
          }
          return { success: true, data };
        }

        case 'EMAIL_OAUTH_URL':
          return { success: true, data: await apiRequest('GET', '/email/oauth/url') };

        case 'EMAIL_OAUTH_RESULT':
          return { success: true, data: await apiRequest('GET', '/email/oauth/result') };

        case 'OPEN_GOOGLE_OAUTH':
          return await openGoogleOAuth(message.url, sender);

        case 'EMAIL_AI_TEMPLATE': {
          const data = await apiRequest('POST', '/email/templates/ai', message.payload);
          return { success: true, data };
        }

        case 'EMAIL_CREATE_TEMPLATE': {
          const data = await apiRequest('POST', '/email/templates', message.payload);
          if (data?.template && statusMem.data) {
            const incoming = data.template;
            const templates = (Array.isArray(statusMem.data.templates) ? statusMem.data.templates : [])
              .filter((t) => String(t.id) !== String(incoming.id) && !String(t.id).startsWith('__tmp_'))
              .map((t) => (incoming.isDefault ? { ...t, isDefault: false } : t));
            templates.unshift(incoming);
            persistStatusCache({ ...statusMem.data, templates });
          }
          return { success: true, data };
        }

        case 'EMAIL_UPDATE_TEMPLATE': {
          const data = await apiRequest('PUT', `/email/templates/${message.id}`, message.payload);
          if (data?.template && statusMem.data) {
            const templates = Array.isArray(statusMem.data.templates)
              ? statusMem.data.templates.map((t) => {
                  if (String(t.id) === String(data.template.id)) return { ...t, ...data.template };
                  if (data.template.isDefault) return { ...t, isDefault: false };
                  return t;
                })
              : [data.template];
            persistStatusCache({ ...statusMem.data, templates });
          }
          return { success: true, data };
        }

        case 'EMAIL_DELETE_TEMPLATE': {
          const data = await apiRequest('DELETE', `/email/templates/${message.id}`);
          if (statusMem.data && Array.isArray(statusMem.data.templates)) {
            persistStatusCache({
              ...statusMem.data,
              templates: statusMem.data.templates.filter((t) => String(t.id) !== String(message.id))
            });
          }
          return { success: true, data };
        }

        case 'EMAIL_SEND': {
          // Keep send + inbox on the same API (public) so conversations stay in sync.
          smtpClientLog('send via main api');
          const data = await apiRequest('POST', '/email/send', message.payload);
          if (data?.via === 'client-smtp' && data.clientSmtp) {
            smtpClientLog('API asked desktop to send');
            const sent = await hostSmtpCall('sendSmtp', data.clientSmtp, sender);
            await apiRequest('POST', '/email/send/ack', {
              id: data.id,
              ok: Boolean(sent?.ok),
              message: sent?.message || '',
              messageId: sent?.messageId || ''
            }).catch(() => {});
            if (!sent?.ok) {
              const err = new Error(sent?.message || 'Could not send from this PC');
              err.code = sent?.code || 'SMTP_SEND_FAILED';
              throw err;
            }
            if (message.payload?.accountId) {
              apiRequest('POST', '/email/mailbox/sync', {
                accountId: message.payload.accountId,
                limit: 20
              }).catch(() => {});
            }
            return { success: true, data: { ...data, via: 'desktop' } };
          }
          if (message.payload?.accountId) {
            setTimeout(() => {
              apiRequest('POST', '/email/mailbox/sync', {
                accountId: message.payload.accountId,
                limit: 20
              }).catch(() => {});
            }, 1500);
          }
          return { success: true, data };
        }

        case 'EMAIL_MAILBOX_LIST': {
          const q = buildQuery(message.query || message.payload || {});
          const data = await apiRequest('GET', `/email/mailbox${q}`);
          return { success: true, data };
        }

        case 'EMAIL_MAILBOX_GET': {
          const data = await apiRequest('GET', `/email/mailbox/${message.id}`);
          return { success: true, data };
        }

        case 'EMAIL_MAILBOX_SYNC': {
          const data = await apiRequest('POST', '/email/mailbox/sync', message.payload || {});
          return { success: true, data };
        }

        case 'EMAIL_CONVERSATIONS_LIST': {
          const q = buildQuery(message.query || message.payload || {});
          const data = await apiRequest('GET', `/email/conversations${q}`);
          return { success: true, data };
        }

        case 'EMAIL_CONVERSATION_MESSAGES': {
          const conversationKey = encodeURIComponent(String(message.conversationKey || ''));
          const q = buildQuery(message.query || message.payload || {});
          const data = await apiRequest(
            'GET',
            `/email/conversations/${conversationKey}/messages${q}`
          );
          return { success: true, data };
        }

        case 'EMAIL_SENT_LIST': {
          const q = buildQuery(message.query || message.payload || {});
          const data = await apiRequest('GET', `/email/sent${q}`);
          return { success: true, data };
        }

        case 'EMAIL_SENT_GET': {
          const data = await apiRequest('GET', `/email/sent/${message.id}`);
          return { success: true, data };
        }

        case 'OPEN_EXTERNAL': {
          const url = String(message.url || '');
          if (isGoogleOAuthUrl(url)) {
            return await openGoogleOAuth(url, sender);
          }
          return await openExternalUrl(url, sender);
        }

        case 'ENSURE_INJECT': {
          const tabId = message.tabId || sender.tab?.id;
          if (!tabId) return { success: false, message: 'No tab' };
          return await ensureContentScript(tabId);
        }

        default:
          return { success: false, message: `Unknown message: ${message?.type}` };
      }
    } catch (err) {
      return {
        success: false,
        message: friendlyUiError(err, 'Something went wrong. Please try again.'),
        code: err.code
      };
    }
  })()
    .then(sendResponse)
    .catch((err) =>
      sendResponse({
        success: false,
        message: friendlyUiError(err, 'Something went wrong. Please try again.')
      })
    );
  return true;
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete') return;
  if (!isDatUrl(tab?.url)) return;
  ensureContentScript(tabId).catch(() => {});
});

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id) return;
  if (!isDatUrl(tab.url)) return;
  await ensureContentScript(tab.id);
  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'DAT_EMAIL_OPEN' });
  } catch {
    // ignore
  }
});

chrome.runtime.onInstalled.addListener(() => {
  console.log('[Signal] installed');
});

chrome.storage.local.get(['emailStatusCache', 'token'], (stored) => {
  const cache = stored?.emailStatusCache;
  if (cache?.data && cache.at) {
    statusMem = { at: Number(cache.at) || 0, data: cache.data };
  }
  if (stored?.token) prefetchEmailStatus();
});
