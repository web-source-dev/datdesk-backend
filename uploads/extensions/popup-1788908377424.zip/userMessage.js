'use strict';

/** Turn API/Error/object values into safe user-facing text (never "[object Object]"). */
function toUserMessage(value, fallback) {
  const fb = fallback || 'Something went wrong. Please try again.';
  if (value == null || value === '') return fb;
  if (typeof value === 'string') {
    const s = value.trim();
    if (!s || s === '[object Object]') return fb;
    return s;
  }
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  if (value instanceof Error) return toUserMessage(value.message, fb);

  if (Array.isArray(value)) {
    for (let i = 0; i < value.length; i += 1) {
      const part = toUserMessage(value[i], '');
      if (part) return part;
    }
    return fb;
  }

  if (typeof value === 'object') {
    const fromAxios =
      toUserMessage(value.response?.data?.message, '') ||
      toUserMessage(value.response?.data, '') ||
      toUserMessage(value.data?.message, '') ||
      toUserMessage(value.data, '');
    if (fromAxios) return fromAxios;

    if (typeof value.message === 'string') return toUserMessage(value.message, fb);
    if (value.message && typeof value.message === 'object') {
      const nested = toUserMessage(value.message, '');
      if (nested) return nested;
    }
    if (typeof value.friendlyMessage === 'string') return toUserMessage(value.friendlyMessage, fb);
    if (typeof value.error === 'string') return toUserMessage(value.error, fb);
    if (typeof value.msg === 'string') return toUserMessage(value.msg, fb);
    if (typeof value.description === 'string') return toUserMessage(value.description, fb);
  }

  return fb;
}
