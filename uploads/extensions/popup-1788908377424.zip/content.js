'use strict';

/**
 * Signal — Shadow DOM UI (aligned with the desktop app).
 * FAB → sidebar (Templates / Account). Row mail → compose modal.
 */
(function () {
  const HOST_ID = 'dat-email-host';
  if (document.getElementById(HOST_ID)) return;
  window.__datEmailMounted = true;

  const state = {
    sidebarOpen: false,
    popupOpen: false,
    tab: 'account',
    accountView: 'list',
    tplView: 'list',
    tplPreviewOpen: false,
    session: null,
    status: null,
    recipient: '',
    loadVars: null,
    busy: false,
    connectMode: null,
    connectForm: 'gmail',
    tplInsertTarget: 'body',
    oauthWaiting: false,
    forceSignedOut: false,
    statusLoaded: false
  };

  const Tpl = () => window.DatEmailTemplates || null;

  const host = document.createElement('div');
  host.id = HOST_ID;
  host.style.all = 'initial';
  host.style.position = 'fixed';
  host.style.inset = '0';
  host.style.zIndex = '2147483646';
  host.style.pointerEvents = 'none';
  host.style.fontFamily = '"Segoe UI", system-ui, sans-serif';
  const shadow = host.attachShadow({ mode: 'open' });
  const BRAND_MARK = (typeof chrome !== 'undefined' && chrome.runtime?.getURL)
    ? chrome.runtime.getURL('icons/icon48.png')
    : 'icons/icon48.png';

  shadow.innerHTML = `<style>
:host, * {
  box-sizing: border-box;
  font-family: "Segoe UI", system-ui, sans-serif;
}
button, input, select, textarea {
  font-family: "Segoe UI", system-ui, sans-serif;
  font-size: inherit;
  line-height: inherit;
}
button { cursor: pointer; }
[hidden] { display: none !important; }

:host {
  --accent-brand: #1565C0;
  --accent-hover: #0D47A1;
  --accent-press: #0A3A84;
  --cyan: #1565C0;
  --ink: #0B1220;
  --ink-2: #334155;
  --ink-3: #5B6B7C;
  --line: #D7E0EA;
  --line-strong: #C5D0DC;
  --surface: transparent;
  --surface-2: transparent;
  --canvas: #ffffff;
  --success: #2E7D32;
  --danger: #C62828;
  --r: 10px;
  --r-sm: 9px;
  --shadow: 0 10px 30px rgba(13, 71, 161, 0.12);
  --shadow-sm: none;
  --navy: #04101f;
  --arc-a: url("data:image/svg+xml,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%20240%2080'%20preserveAspectRatio%3D'xMidYMid%20slice'%3E%3Cpath%20d%3D'M%2032%20-12%20C%2010%2022%2C%2058%2048%2C%2026%2092'%20fill%3D'none'%20stroke%3D'%2342A5F5'%20stroke-width%3D'7'%20stroke-linecap%3D'round'%20stroke-linejoin%3D'round'%20opacity%3D'0.22'%2F%3E%3Cpath%20d%3D'M%2032%20-12%20C%2010%2022%2C%2058%2048%2C%2026%2092'%20fill%3D'none'%20stroke%3D'%238ED0FF'%20stroke-width%3D'1.35'%20stroke-linecap%3D'round'%20stroke-linejoin%3D'round'%2F%3E%3Cpath%20d%3D'M%20208%20-12%20C%20232%2024%2C%20178%2052%2C%20216%2092'%20fill%3D'none'%20stroke%3D'%2342A5F5'%20stroke-width%3D'7'%20stroke-linecap%3D'round'%20stroke-linejoin%3D'round'%20opacity%3D'0.22'%2F%3E%3Cpath%20d%3D'M%20208%20-12%20C%20232%2024%2C%20178%2052%2C%20216%2092'%20fill%3D'none'%20stroke%3D'%238ED0FF'%20stroke-width%3D'1.35'%20stroke-linecap%3D'round'%20stroke-linejoin%3D'round'%2F%3E%3Ccircle%20cx%3D'32'%20cy%3D'40'%20r%3D'4.4'%20fill%3D'%2342A5F5'%20opacity%3D'0.22'%2F%3E%3Ccircle%20cx%3D'32'%20cy%3D'40'%20r%3D'2.2'%20fill%3D'%238ED0FF'%2F%3E%3Ccircle%20cx%3D'208'%20cy%3D'42'%20r%3D'4.4'%20fill%3D'%2342A5F5'%20opacity%3D'0.22'%2F%3E%3Ccircle%20cx%3D'208'%20cy%3D'42'%20r%3D'2.2'%20fill%3D'%238ED0FF'%2F%3E%3C%2Fsvg%3E");
  --arc-b: url("data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%20240%2080%27%20preserveAspectRatio%3D%27xMidYMid%20slice%27%3E%3Cpath%20d%3D%27M%2036%20-12%20C%208%2022%2C%2062%2048%2C%2030%2092%27%20fill%3D%27none%27%20stroke%3D%27%2342A5F5%27%20stroke-width%3D%277%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%20opacity%3D%270.22%27%2F%3E%3Cpath%20d%3D%27M%2036%20-12%20C%208%2022%2C%2062%2048%2C%2030%2092%27%20fill%3D%27none%27%20stroke%3D%27%238ED0FF%27%20stroke-width%3D%271.35%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%2F%3E%3Ccircle%20cx%3D%2734%27%20cy%3D%2740%27%20r%3D%274.5%27%20fill%3D%27%2342A5F5%27%20opacity%3D%27.22%27%2F%3E%3Ccircle%20cx%3D%2734%27%20cy%3D%2740%27%20r%3D%272.3%27%20fill%3D%27%238ED0FF%27%2F%3E%3C%2Fsvg%3E");
  --arc-c: url("data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%20240%2080%27%20preserveAspectRatio%3D%27xMidYMid%20slice%27%3E%3Cpath%20d%3D%27M%20206%20-12%20C%20236%2024%2C%20176%2050%2C%20214%2092%27%20fill%3D%27none%27%20stroke%3D%27%2342A5F5%27%20stroke-width%3D%277%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%20opacity%3D%270.22%27%2F%3E%3Cpath%20d%3D%27M%20206%20-12%20C%20236%2024%2C%20176%2050%2C%20214%2092%27%20fill%3D%27none%27%20stroke%3D%27%238ED0FF%27%20stroke-width%3D%271.35%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%2F%3E%3Ccircle%20cx%3D%27208%27%20cy%3D%2742%27%20r%3D%274.5%27%20fill%3D%27%2342A5F5%27%20opacity%3D%27.22%27%2F%3E%3Ccircle%20cx%3D%27208%27%20cy%3D%2742%27%20r%3D%272.3%27%20fill%3D%27%238ED0FF%27%2F%3E%3C%2Fsvg%3E");
  --arc-d: url("data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%20240%2080%27%20preserveAspectRatio%3D%27xMidYMid%20slice%27%3E%3Cpath%20d%3D%27M%20-18%20-8%20C%2070%208%2C%20150%2052%2C%20258%2088%27%20fill%3D%27none%27%20stroke%3D%27%2342A5F5%27%20stroke-width%3D%277%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%20opacity%3D%270.22%27%2F%3E%3Cpath%20d%3D%27M%20-18%20-8%20C%2070%208%2C%20150%2052%2C%20258%2088%27%20fill%3D%27none%27%20stroke%3D%27%238ED0FF%27%20stroke-width%3D%271.35%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%2F%3E%3Ccircle%20cx%3D%27120%27%20cy%3D%2740%27%20r%3D%274.4%27%20fill%3D%27%2342A5F5%27%20opacity%3D%27.22%27%2F%3E%3Ccircle%20cx%3D%27120%27%20cy%3D%2740%27%20r%3D%272.2%27%20fill%3D%27%238ED0FF%27%2F%3E%3C%2Fsvg%3E");
  --arc-e: url("data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%20240%2080%27%20preserveAspectRatio%3D%27xMidYMid%20slice%27%3E%3Cpath%20d%3D%27M%20258%20-8%20C%20160%2010%2C%2080%2054%2C%20-18%2088%27%20fill%3D%27none%27%20stroke%3D%27%2342A5F5%27%20stroke-width%3D%277%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%20opacity%3D%270.22%27%2F%3E%3Cpath%20d%3D%27M%20258%20-8%20C%20160%2010%2C%2080%2054%2C%20-18%2088%27%20fill%3D%27none%27%20stroke%3D%27%238ED0FF%27%20stroke-width%3D%271.35%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%2F%3E%3Ccircle%20cx%3D%27122%27%20cy%3D%2740%27%20r%3D%274.4%27%20fill%3D%27%2342A5F5%27%20opacity%3D%27.22%27%2F%3E%3Ccircle%20cx%3D%27122%27%20cy%3D%2740%27%20r%3D%272.2%27%20fill%3D%27%238ED0FF%27%2F%3E%3C%2Fsvg%3E");
  --arc-f: url("data:image/svg+xml,%3Csvg%20xmlns%3D%27http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%27%20viewBox%3D%270%200%20240%2080%27%20preserveAspectRatio%3D%27xMidYMid%20slice%27%3E%3Cpath%20d%3D%27M%2028%20-10%20C%206%2028%2C%2052%2050%2C%2024%2092%27%20fill%3D%27none%27%20stroke%3D%27%2342A5F5%27%20stroke-width%3D%277%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%20opacity%3D%270.22%27%2F%3E%3Cpath%20d%3D%27M%2028%20-10%20C%206%2028%2C%2052%2050%2C%2024%2092%27%20fill%3D%27none%27%20stroke%3D%27%238ED0FF%27%20stroke-width%3D%271.35%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%2F%3E%3Cpath%20d%3D%27M%20212%20-10%20C%20236%2026%2C%20188%2054%2C%20218%2092%27%20fill%3D%27none%27%20stroke%3D%27%2342A5F5%27%20stroke-width%3D%277%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%20opacity%3D%270.22%27%2F%3E%3Cpath%20d%3D%27M%20212%20-10%20C%20236%2026%2C%20188%2054%2C%20218%2092%27%20fill%3D%27none%27%20stroke%3D%27%238ED0FF%27%20stroke-width%3D%271.35%27%20stroke-linecap%3D%27round%27%20stroke-linejoin%3D%27round%27%2F%3E%3C%2Fsvg%3E");
  --arc-g: url("data:image/svg+xml,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%20240%2080'%20preserveAspectRatio%3D'xMidYMid%20slice'%3E%3Cpath%20d%3D'M%2070%20-12%20C%2048%2030%2C%2092%2050%2C%2064%2092'%20fill%3D'none'%20stroke%3D'%2342A5F5'%20stroke-width%3D'7'%20stroke-linecap%3D'round'%20stroke-linejoin%3D'round'%20opacity%3D'0.22'%20stroke-dasharray%3D'8%207'%2F%3E%3Cpath%20d%3D'M%2070%20-12%20C%2048%2030%2C%2092%2050%2C%2064%2092'%20fill%3D'none'%20stroke%3D'%238ED0FF'%20stroke-width%3D'1.35'%20stroke-linecap%3D'round'%20stroke-linejoin%3D'round'%20stroke-dasharray%3D'8%207'%2F%3E%3Cpath%20d%3D'M%20196%208%20C%20220%2034%2C%20184%2058%2C%20210%2088'%20fill%3D'none'%20stroke%3D'%2342A5F5'%20stroke-width%3D'7'%20stroke-linecap%3D'round'%20stroke-linejoin%3D'round'%20opacity%3D'0.22'%2F%3E%3Cpath%20d%3D'M%20196%208%20C%20220%2034%2C%20184%2058%2C%20210%2088'%20fill%3D'none'%20stroke%3D'%238ED0FF'%20stroke-width%3D'1.35'%20stroke-linecap%3D'round'%20stroke-linejoin%3D'round'%2F%3E%3Ccircle%20cx%3D'70'%20cy%3D'40'%20r%3D'4.4'%20fill%3D'%2342A5F5'%20opacity%3D'0.22'%2F%3E%3Ccircle%20cx%3D'70'%20cy%3D'40'%20r%3D'2.2'%20fill%3D'%238ED0FF'%2F%3E%3C%2Fsvg%3E");
  --arc-h: url("data:image/svg+xml,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%20240%2080'%20preserveAspectRatio%3D'xMidYMid%20slice'%3E%3Cpath%20d%3D'M%20214%20-10%20C%20238%2026%2C%20180%2054%2C%20218%2092'%20fill%3D'none'%20stroke%3D'%2342A5F5'%20stroke-width%3D'7'%20stroke-linecap%3D'round'%20stroke-linejoin%3D'round'%20opacity%3D'0.22'%2F%3E%3Cpath%20d%3D'M%20214%20-10%20C%20238%2026%2C%20180%2054%2C%20218%2092'%20fill%3D'none'%20stroke%3D'%238ED0FF'%20stroke-width%3D'1.35'%20stroke-linecap%3D'round'%20stroke-linejoin%3D'round'%2F%3E%3Ccircle%20cx%3D'214'%20cy%3D'42'%20r%3D'4.5'%20fill%3D'%2342A5F5'%20opacity%3D'0.22'%2F%3E%3Ccircle%20cx%3D'214'%20cy%3D'42'%20r%3D'2.3'%20fill%3D'%238ED0FF'%2F%3E%3C%2Fsvg%3E");
  --font: "Segoe UI", system-ui, sans-serif;
  --font-mono: ui-monospace, "Cascadia Mono", "Segoe UI Mono", Consolas, monospace;
  font-family: "Segoe UI", system-ui, sans-serif !important;
  font-size: 13px;
  line-height: 1.45;
  color: var(--ink);
  -webkit-font-smoothing: antialiased;
}

.panel-backdrop {
  pointer-events: auto;
  position: fixed; inset: 0; z-index: 4;
  background: rgba(11, 18, 32, 0.28);
  opacity: 0; visibility: hidden;
  transition: opacity 0.15s, visibility 0.15s;
}
.panel-backdrop.open { opacity: 1; visibility: visible; }

.panel {
  pointer-events: auto;
  position: fixed; top: 0; right: 0; z-index: 5;
  width: min(400px, 100vw);
  height: 100vh;
  display: flex; flex-direction: column;
  overflow: hidden;
  background:
    radial-gradient(ellipse 90% 70% at 50% -10%, rgba(66, 165, 245, 0.16), transparent 58%),
    #ffffff;
  box-shadow: var(--shadow);
  transform: translateX(100%);
  transition: transform 0.18s ease;
}
.panel::before {
  content: '';
  position: absolute;
  inset: 0;
  pointer-events: none;
  z-index: 0;
  background-image:
    linear-gradient(rgba(21, 101, 192, 0.06) 1px, transparent 1px),
    linear-gradient(90deg, rgba(21, 101, 192, 0.06) 1px, transparent 1px);
  background-size: 44px 44px;
  mask-image: radial-gradient(ellipse 90% 80% at 50% 40%, black 25%, transparent 90%);
  -webkit-mask-image: radial-gradient(ellipse 90% 80% at 50% 40%, black 25%, transparent 90%);
}
.panel > * { position: relative; z-index: 1; }
.panel > .horizon-arcs { z-index: 0; pointer-events: none; }
.panel.open { transform: translateX(0); }

.horizon-arcs {
  position: absolute; inset: 0; width: 100%; height: 100%;
  pointer-events: none; z-index: 0;
}

.panel-head {
  display: flex; align-items: flex-start; justify-content: space-between;
  gap: 10px; padding: 22px 18px 16px;
  width: 100%;
  margin: 0;
  background: transparent;
  flex-shrink: 0;
  position: relative;
  overflow: hidden;
  min-height: 88px;
}
.panel-head.sub { gap: 8px; align-items: center; min-height: 64px; padding: 14px 18px; }
.head-arcs {
  position: absolute; inset: 0; width: 100%; height: 140%;
  pointer-events: none; z-index: 0;
}
.panel-head > *:not(.head-arcs) { position: relative; z-index: 1; }

.brand {
  display: flex; align-items: center; gap: 12px; min-width: 0;
}
.brand-copy { min-width: 0; }
.brand-copy.grow { flex: 1; min-width: 0; }
.brand-bar {
  width: 28px; height: 3px; border-radius: 999px;
  background: repeating-linear-gradient(90deg, #1565C0 0 6px, transparent 6px 11px);
  flex: 0 0 auto;
}
.brand-mark {
  width: 40px; height: 40px; border-radius: 10px;
  object-fit: cover; display: block; flex: 0 0 auto;
  background: transparent; padding: 0;
}
.brand-name {
  font-size: 16px; font-weight: 600; letter-spacing: -0.02em;
  color: var(--ink);
}
.brand-kicker {
  margin-top: 3px;
  font-size: 12px;
  color: var(--ink-3);
  font-weight: 500;
}
.brand-sub { display: none; }

.head-actions {
  display: flex; align-items: center; gap: 10px; flex: 0 0 auto;
}

.back-btn, .icon-btn {
  width: 32px; height: 32px; padding: 0;
  border-radius: var(--r-sm);
  border: 0;
  background: transparent;
  color: var(--ink-3);
  display: grid; place-items: center;
  flex: 0 0 auto;
}
.back-btn:hover, .icon-btn:hover {
  background: rgba(21, 101, 192, 0.08);
  color: var(--ink);
}
.back-btn svg, .icon-btn svg { width: 16px; height: 16px; display: block; }

.tabs {
  display: flex; gap: 0;
  margin: 0;
  padding: 0 8px;
  border: 0;
  border-bottom: 1px solid var(--line);
  background: transparent;
  box-shadow: none;
  flex-shrink: 0;
}
.tab {
  flex: 1;
  height: 40px; padding: 0 12px;
  border: 0;
  border-bottom: 2px solid transparent;
  border-radius: 0;
  background: transparent;
  color: var(--ink-3);
  font-weight: 600; font-size: 13px;
  margin-bottom: -1px;
}
.tab:hover { color: var(--ink); background: transparent; }
.tab.active {
  color: var(--accent-brand);
  background: transparent;
  border-bottom-color: var(--accent-brand);
  box-shadow: none;
}

.panel-body {
  flex: 1; overflow: auto; padding: 0;
  background: transparent;
  scrollbar-width: thin;
  scrollbar-color: #C5D0DC transparent;
}

.section-bar {
  display: flex; align-items: center; justify-content: space-between;
  gap: 8px; padding: 18px 18px 0;
  background: transparent;
}
.section-bar .label {
  font-size: 15px; font-weight: 600; letter-spacing: -0.02em;
  color: var(--ink);
}
.section-hint {
  margin: 6px 18px 0;
  padding: 0;
  font-size: 13px;
  line-height: 1.45;
  color: var(--ink-3);
}
.section-hint strong { color: var(--accent-brand); font-weight: 650; }

.pad { padding: 18px; }

.card-desc { font-size: 14px; color: var(--ink-3); margin: 0 0 24px; line-height: 1.5; }

.login-card {
  background: transparent;
  border: 0;
  border-radius: 0;
  box-shadow: none;
  padding: 8px 0 4px;
}
.login-title {
  font-size: 28px;
  font-weight: 600;
  color: var(--ink);
  letter-spacing: -0.03em;
  margin: 0;
}
.road-line {
  width: 72px;
  height: 3px;
  margin: 12px 0 14px;
  border-radius: 99px;
  background: repeating-linear-gradient(90deg, #1565C0 0 8px, transparent 8px 14px);
}
.login-card .divider-or { margin: 18px 0; }
.login-card .card-desc { margin-bottom: 28px; }
.login-card .field { margin-bottom: 22px; gap: 4px; }
.login-card .field label {
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.22em;
  text-transform: uppercase;
  color: var(--ink-3);
}
.login-card .input {
  border: 0;
  border-bottom: 1px solid var(--accent-brand);
  border-radius: 0;
  background: transparent;
  padding: 10px 0;
  font-size: 15px;
  color: var(--ink);
}
.login-card .pw-field .input { padding-right: 40px; }
.login-card .pw-toggle { right: 0; }
.login-card .btn-primary { margin-top: 6px; }

.auth-links {
  display: flex; align-items: center; justify-content: space-between;
  gap: 10px; margin-top: 14px;
}
.auth-links a {
  font-size: 12px; color: var(--ink-3); text-decoration: none; font-weight: 500;
}
.auth-links a:hover { color: var(--accent-brand); }

.field { display: flex; flex-direction: column; gap: 6px; margin-bottom: 14px; }
.field:last-child { margin-bottom: 0; }
.row > .field,
.grid-2 > .field,
.login-card .row > .field {
  margin-bottom: 0;
}
.field-port {
  flex: 0 0 96px;
  width: 96px;
  max-width: 96px;
}
.field label {
  font-size: 11px; font-weight: 600; letter-spacing: 0.22em;
  text-transform: uppercase; color: var(--ink-3);
}
.hint { font-size: 12px; color: var(--ink-3); line-height: 1.4; }

.pw-field { position: relative; }
.pw-field .input { padding-right: 42px; }
.pw-toggle {
  position: absolute; right: 0; top: 50%; transform: translateY(-50%);
  width: 32px; height: 32px; padding: 0; border: 0; border-radius: 6px;
  background: transparent; color: var(--ink-3); cursor: pointer;
  display: grid; place-items: center;
}
.pw-toggle:hover { color: var(--ink); background: rgba(21, 101, 192, 0.08); }
.pw-toggle svg { width: 18px; height: 18px; display: block; }

.smtp-progress {
  margin: 0 0 12px;
  padding: 10px 0;
  border: 0;
  border-bottom: 1px solid var(--line);
  background: transparent;
}
.smtp-progress-bar {
  height: 4px; border-radius: 99px; background: #E3F2FD; overflow: hidden; margin-bottom: 8px;
}
.smtp-progress-bar span {
  display: block; height: 100%; width: 40%;
  background: var(--accent-brand); border-radius: 99px;
  animation: smtp-progress-slide 1.1s ease-in-out infinite;
}
@keyframes smtp-progress-slide {
  0% { transform: translateX(-120%); }
  100% { transform: translateX(280%); }
}
.smtp-progress-text {
  font-size: 12px; font-weight: 650; color: var(--accent-brand); line-height: 1.35;
}

.input, .select, .textarea {
  width: 100%;
  border: 0;
  border-bottom: 1px solid var(--accent-brand);
  border-radius: 0;
  background: transparent;
  color: var(--ink);
  padding: 10px 0;
  outline: none;
  font-size: 15px;
  box-shadow: none;
  transition: border-color 0.15s ease, border-bottom-width 0.15s ease;
}
.input:hover, .select:hover, .textarea:hover {
  background: transparent;
  box-shadow: none;
  border-bottom-width: 2px;
  border-bottom-color: #42A5F5;
}
.input:focus, .select:focus, .textarea:focus {
  border-color: #42A5F5;
  border-bottom-width: 2px;
  background: transparent;
  box-shadow: none;
}
.input::placeholder, .textarea::placeholder { color: #94A3B8; }
.select option { background: #fff; color: var(--ink); }
.textarea { min-height: 110px; resize: vertical; line-height: 1.5; }
.input.mono { font-family: var(--font-mono); font-size: 13px; }

.row { display: flex; gap: 16px; align-items: flex-start; }
.row.wrap { flex-wrap: wrap; }
.grow { flex: 1; min-width: 0; }
.grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }

.btn {
  --btn-arc: var(--arc-a);
  position: relative;
  overflow: hidden;
  isolation: isolate;
  display: inline-flex; align-items: center; justify-content: center; gap: 8px;
  height: 40px; padding: 0 16px; border-radius: var(--r-sm);
  border: 0; font-weight: 600; font-size: 13px;
  background: var(--navy); color: #fff;
  text-shadow: 0 1px 2px rgba(4, 16, 31, 0.9), 0 0 10px rgba(4, 16, 31, 0.75);
  box-shadow: 0 8px 22px rgba(4, 16, 31, 0.22);
  transition: background 0.18s ease, box-shadow 0.18s ease;
}
.btn::before {
  content: '';
  position: absolute; inset: 0; z-index: -1;
  pointer-events: none;
  background: var(--btn-arc) var(--btn-arc-pos, left) center / 240px 100% no-repeat;
  opacity: 0.75;
  transition: filter 0.18s ease, opacity 0.18s ease;
}
.btn > * { position: relative; z-index: 1; }
.btn:disabled { cursor: not-allowed; opacity: 0.5; box-shadow: none; }
.btn:hover:not(:disabled) {
  background: #0C3A66;
  color: #fff;
  box-shadow: 0 10px 28px rgba(4, 16, 31, 0.28);
}
.btn:hover:not(:disabled)::before {
  opacity: 0.95;
  filter: brightness(1.28) saturate(1.15);
}
.btn:active:not(:disabled) { background: #082844; }
.btn-primary { --btn-arc: var(--arc-a); }
.btn-primary:not(.btn-sm) { height: 44px; font-size: 15px; padding: 0 20px; }
.btn-secondary { --btn-arc: var(--arc-b); }
.btn-google { --btn-arc: var(--arc-c); --btn-arc-pos: right; }
.btn-linkish { --btn-arc: var(--arc-f); }
.btn-danger { --btn-arc: var(--arc-h); --btn-arc-pos: right; color: #fff; }
.btn-ghost {
  --btn-arc: none;
  background: transparent; color: var(--ink-2); height: 28px; padding: 0 8px;
  box-shadow: none; overflow: visible; isolation: auto;
}
.btn-ghost::before { display: none; }
.btn-ghost:hover:not(:disabled) { color: var(--ink); background: rgba(21, 101, 192, 0.08); }
.btn-sm { height: 32px; padding: 0 12px; font-size: 12px; box-shadow: 0 4px 14px rgba(4, 16, 31, 0.18); }
.btn-block { width: 100%; }
.btn-google .g-ico { width: 18px; height: 18px; flex: 0 0 auto; }
#btn-login { --btn-arc: var(--arc-a); }
#btn-add-account { --btn-arc: var(--arc-b); }
#btn-connect-gmail-empty, #choice-oauth { --btn-arc: var(--arc-c); --btn-arc-pos: right; }
#btn-add-account-empty { --btn-arc: var(--arc-d); }
#choice-smtp { --btn-arc: var(--arc-e); }
#btn-connect-smtp { --btn-arc: var(--arc-g); }
#oauth-wait-cancel { --btn-arc: var(--arc-h); --btn-arc-pos: right; }
#btn-new-tpl { --btn-arc: var(--arc-f); }
#btn-new-tpl-empty { --btn-arc: var(--arc-a); }
#btn-tpl-preview { --btn-arc: var(--arc-b); }
#btn-save-tpl { --btn-arc: var(--arc-a); }
#btn-reset-tpl { --btn-arc: var(--arc-e); }
#btn-delete-tpl { --btn-arc: var(--arc-h); --btn-arc-pos: right; }
#btn-tpl-preview-back { --btn-arc: var(--arc-d); }
#popup-send { --btn-arc: var(--arc-a); }
#popup-save-tpl { --btn-arc: var(--arc-f); }

.session-box {
  display: flex; align-items: center; justify-content: space-between; gap: 10px;
  padding: 12px 0;
  background: transparent;
  border: 0;
  border-bottom: 1px solid var(--line);
}
.session-box .meta { font-size: 11px; color: var(--ink-3); margin-bottom: 2px; }
.session-box .email {
  font-size: 13px; font-weight: 650; color: var(--ink);
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}

.list { display: flex; flex-direction: column; gap: 0; padding-bottom: 12px; }
.list-card {
  display: flex; align-items: center; gap: 10px;
  min-height: 52px;
  padding: 12px 0;
  overflow: visible;
  border: 0;
  border-bottom: 1px solid var(--line);
  border-radius: 0;
  background: transparent;
  box-shadow: none;
}
.list-card:hover { border-color: var(--line-strong); }
.list-card .ico {
  width: 18px; height: 28px;
  background: transparent; color: var(--ink-3);
  display: grid; place-items: center; flex: 0 0 auto;
}
.list-card .ico svg { width: 15px; height: 14px; }
.list-card .body { flex: 1; min-width: 0; }
.list-card .title {
  font-size: 13px; font-weight: 600; color: var(--ink);
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.list-card .sub {
  font-size: 11px; color: var(--ink-3); margin-top: 2px;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.list-card .actions {
  display: flex; gap: 8px; flex: 0 0 auto; align-items: center;
  overflow: visible;
}
.list-card .actions .icon-btn {
  width: 28px; height: 28px; color: var(--ink-3);
}
.list-card .actions .icon-btn:hover {
  color: var(--ink); background: rgba(21, 101, 192, 0.08);
}
.list-card .actions .del { color: var(--danger); }
.list-card .actions .del:hover,
.list-card .actions .rem:hover { color: var(--danger); background: #FDECEC; }
.list-card .actions .rem { color: var(--ink-3); }
.list-card.is-over-limit { opacity: 0.72; }
.list-card.is-over-limit .title { color: var(--ink-3); }
.sw-wrap.is-locked { opacity: 0.45; cursor: not-allowed; pointer-events: none; }

.sw-wrap {
  display: flex; flex-direction: column; align-items: flex-end; gap: 3px;
  cursor: pointer; user-select: none; flex: 0 0 auto;
}
.sw-wrap .sw-text {
  font-size: 9px; font-weight: 700; letter-spacing: 0.04em;
  text-transform: uppercase; color: var(--ink-3); white-space: nowrap; line-height: 1;
}
.sw-wrap:has(input:checked) .sw-text { color: var(--accent-brand); }
.sw {
  position: relative; width: 36px; height: 20px; flex-shrink: 0; display: block;
}
.sw input {
  position: absolute; inset: 0; opacity: 0; margin: 0; cursor: pointer; z-index: 1;
}
.sw .track {
  display: block; width: 36px; height: 20px; border-radius: 999px;
  background: #CBD5E1; transition: background 0.08s ease;
  pointer-events: none;
}
.sw input:checked + .track { background: var(--accent-brand); }
.sw .track::after {
  content: ''; position: absolute; top: 2px; left: 2px;
  width: 16px; height: 16px; border-radius: 50%;
  background: #fff; box-shadow: 0 1px 2px rgba(0,0,0,0.18);
  transition: transform 0.08s ease;
}
.sw input:checked + .track::after { transform: translateX(16px); }
.sw input:disabled + .track { opacity: 0.55; }

.status-ok {
  display: inline-flex; align-items: center; gap: 5px;
  font-size: 12px; font-weight: 650; color: var(--success);
  white-space: nowrap;
}
.status-ok svg { width: 14px; height: 14px; }

.empty {
  text-align: left;
  padding: 28px 0 12px;
  color: var(--ink-2);
  border: 0;
  background: transparent;
  box-shadow: none;
}
.empty strong {
  display: block; color: var(--ink); font-size: 16px; font-weight: 600; margin-bottom: 6px;
}
.empty p { margin: 0 0 16px; font-size: 13px; line-height: 1.5; color: var(--ink-3); }
.empty-actions {
  display: flex; flex-direction: column; gap: 8px;
}

.divider-or {
  display: flex; align-items: center; gap: 10px;
  margin: 16px 0;
  color: var(--ink-3); font-size: 11px; font-weight: 650;
  letter-spacing: 0.05em; text-transform: uppercase;
}
.divider-or::before, .divider-or::after {
  content: ''; flex: 1; height: 1px; background: var(--line);
}

.oauth-wait {
  text-align: center;
  padding: 8px 0 16px;
  border: 0;
  background: transparent;
  margin-bottom: 0;
}
.oauth-wait strong {
  display: block;
  font-size: 15px;
  color: var(--ink);
  margin: 10px 0 6px;
}
.oauth-wait p {
  margin: 0 auto 14px;
  max-width: 280px;
  font-size: 13px;
  line-height: 1.45;
  color: var(--ink-3);
}
.oauth-spin {
  width: 28px;
  height: 28px;
  margin: 0 auto;
  border: 2px solid var(--line);
  border-top-color: var(--accent-brand);
  border-radius: 50%;
  animation: dat-oauth-spin 0.7s linear infinite;
}
@keyframes dat-oauth-spin {
  to { transform: rotate(360deg); }
}

.manual-block {
  border: 0;
  border-radius: 0;
  overflow: visible;
  margin-bottom: 12px;
  background: transparent;
}
.manual-block .block-title {
  font-size: 13px; font-weight: 650; color: var(--ink); margin: 0 0 12px;
}
.manual-block .body { padding: 0; }

.chip-note {
  font-size: 11px; color: var(--ink-3); margin: 6px 0 0; line-height: 1.4;
}
.smtp-guide-label {
  margin: 16px 0 6px;
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.22em;
  text-transform: uppercase;
  color: var(--ink-3);
}
.smtp-guide {
  margin: 0;
  border: 0;
  border-top: 1px solid var(--line);
  border-radius: 0;
  background: transparent;
  padding: 0;
}
.smtp-guide > summary {
  cursor: pointer;
  list-style: none;
  padding: 10px 0;
  font-size: 12px;
  font-weight: 650;
  color: var(--ink);
}
.smtp-guide > summary::-webkit-details-marker { display: none; }
.smtp-guide > summary::after {
  content: 'Show';
  float: right;
  font-weight: 600;
  color: var(--accent-brand);
}
.smtp-guide[open] > summary::after { content: 'Hide'; }
.smtp-guide-body { padding: 0 0 12px; }
.smtp-guide-title {
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--ink-3);
  margin: 10px 0 6px;
}
.smtp-guide-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 11px;
  line-height: 1.35;
}
.smtp-guide-table th,
.smtp-guide-table td {
  text-align: left;
  padding: 6px 6px 6px 0;
  border-bottom: 1px solid var(--line);
  vertical-align: top;
  color: var(--ink);
}
.smtp-guide-table th { color: var(--ink-3); font-weight: 650; }
.smtp-guide-table code {
  font-family: var(--font-mono);
  font-size: 10px;
  background: transparent;
  border: 0;
  color: var(--accent-brand);
  padding: 0;
}
.smtp-guide ol {
  margin: 0;
  padding-left: 18px;
  font-size: 12px;
  line-height: 1.45;
  color: var(--ink-2);
}
.smtp-guide li { margin: 0 0 4px; }
.smtp-guide p {
  margin: 0;
  font-size: 12px;
  line-height: 1.45;
  color: var(--ink-2);
}
.smtp-guide a, .smtp-guide button.link {
  color: var(--accent-brand);
  background: none;
  border: 0;
  padding: 0;
  font: inherit;
  font-weight: 650;
  cursor: pointer;
  text-decoration: underline;
}
.chip-row {
  display: flex; align-items: center; justify-content: space-between;
  gap: 8px; margin-bottom: 8px;
}
.insert-target {
  display: inline-flex; gap: 4px;
  border: 0;
  background: transparent;
}
.insert-target button {
  height: 26px; padding: 0 10px; border: 0; background: transparent;
  color: var(--ink-3); font-size: 11px; font-weight: 650;
  border-bottom: 2px solid transparent;
  border-radius: 0;
}
.insert-target button.active {
  background: transparent; color: var(--accent-brand);
  border-bottom-color: var(--accent-brand);
}

.chips { display: flex; flex-wrap: wrap; gap: 6px; margin: 0 0 10px; }
.chip {
  height: 26px; padding: 0 10px; border-radius: 99px;
  border: 1px solid var(--line-strong); background: transparent;
  color: var(--ink); font-size: 11px; font-weight: 600;
}
.chip:hover {
  border-color: var(--accent-brand);
  background: #E3F2FD;
  color: var(--accent-brand);
}
.chip .chip-key { display: none; }

.preview-label {
  font-size: 11px; font-weight: 650; letter-spacing: 0.04em;
  text-transform: uppercase; color: var(--ink-3); margin: 4px 0 6px;
}
.preview-box {
  border: 0;
  border-top: 1px solid var(--line);
  border-radius: 0;
  background: transparent;
  padding: 12px 0;
  font-size: 12px; color: var(--ink);
  white-space: pre-wrap; word-break: break-word;
  max-height: 160px; overflow: auto;
  line-height: 1.5;
}
.preview-box .pv-subject {
  display: block; font-weight: 700; margin-bottom: 6px; color: var(--ink);
}
.preview-box .pv-body {
  display: block; color: var(--ink-2); white-space: pre-wrap;
}
#tpl-preview-view .preview-box {
  max-height: none;
  min-height: 180px;
}

.ai-assist {
  margin: 0 0 16px;
  padding: 0 0 14px;
  border: 0;
  border-bottom: 1px solid var(--line);
  background: transparent;
}
.ai-assist-label {
  display: block;
  font-size: 11px;
  font-weight: 650;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--ink-3);
  margin: 0 0 8px;
}
.ai-composer {
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 40px;
  padding: 4px 4px 4px 12px;
  border: 1px solid var(--line-strong);
  border-radius: 8px;
  background: #fff;
}
.ai-composer:focus-within {
  border-color: var(--accent-brand);
  box-shadow: 0 0 0 2px rgba(11, 107, 203, 0.16);
}
.ai-composer-input,
.ai-composer-input.textarea,
.ai-composer-input.input,
.login-card .input.ai-composer-input {
  flex: 1;
  min-width: 0;
  height: 32px !important;
  min-height: 32px !important;
  max-height: 32px !important;
  margin: 0 !important;
  padding: 0 !important;
  border: 0 !important;
  border-radius: 0 !important;
  background: transparent !important;
  box-shadow: none !important;
  font-size: 13px;
  line-height: 32px;
  resize: none;
}
.ai-composer-go {
  flex: 0 0 auto;
  width: auto;
  min-width: 68px;
  height: 32px !important;
  min-height: 32px !important;
  padding: 0 14px;
  border: 0;
  border-radius: 6px;
  background: var(--accent-brand);
  color: #fff;
  font-size: 13px;
  font-weight: 650;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
}
.ai-composer-go:hover:not(:disabled) { background: var(--accent-hover); border-color: var(--accent-hover); }
.ai-composer-go:disabled { opacity: 0.6; cursor: not-allowed; }
.ai-suggest {
  margin: 8px 0 0;
}
.ai-suggest .chip:disabled { opacity: 0.5; cursor: not-allowed; }
.ai-assist-status {
  margin: 6px 0 0;
  font-size: 12px;
  font-weight: 600;
  color: var(--ink-3);
  line-height: 1.35;
}
.ai-assist-status[hidden] { display: none !important; }
.ai-assist-status.is-err { color: var(--danger); }
.ai-assist-status.is-ok { color: #059669; }
.ai-spin {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  border: 2px solid rgba(255,255,255,0.35);
  border-top-color: #fff;
  animation: dat-oauth-spin 0.7s linear infinite;
  flex: 0 0 auto;
}
.ai-assist.is-busy .ai-composer-input { opacity: 0.7; }

.status-strip { display: none !important; }

.toast {
  pointer-events: auto;
  position: fixed; left: 50%; bottom: 20px; z-index: 40;
  width: min(320px, calc(100vw - 24px));
  transform: translateX(-50%) translateY(8px);
  display: flex; align-items: flex-start; gap: 10px;
  padding: 14px 16px 14px 14px;
  background: #ffffff;
  border: 1px solid var(--line);
  border-radius: 12px;
  box-shadow: var(--shadow);
  color: var(--ink);
  opacity: 0; visibility: hidden;
  transition: opacity 0.15s, transform 0.15s, visibility 0.15s;
}
.toast.show { opacity: 1; visibility: visible; transform: translateX(-50%) translateY(0); }
.toast.ok { background: #ffffff; border-color: #B7E0C6; color: #1B5E3B; }
.toast.err { background: #ffffff; border-color: #F5C2C2; color: #8B1E1E; }
.toast .toast-ico {
  width: 24px; height: 24px; flex: 0 0 auto; margin-top: 1px;
  border-radius: 50%;
  display: grid; place-items: center;
  background: var(--accent-brand); color: #fff;
}
.toast.ok .toast-ico { background: #2E7D32; color: #fff; }
.toast.err .toast-ico { background: #C62828; color: #fff; }
.toast .toast-ico svg { width: 13px; height: 13px; }
.toast .toast-body { flex: 1; min-width: 0; }
.toast .toast-title { font-size: 13px; font-weight: 600; color: inherit; }
.toast .toast-desc { font-size: 12px; color: inherit; opacity: 0.85; margin-top: 2px; }
.toast .toast-x {
  width: 28px; height: 28px; border: 0; background: transparent;
  color: var(--ink-3); padding: 0; flex: 0 0 auto;
  display: grid; place-items: center; border-radius: 50%;
  pointer-events: auto; cursor: pointer; position: absolute; top: -10px; left: -10px; z-index: 2;
}
.toast.ok .toast-x, .toast.err .toast-x { color: inherit; }
.toast .toast-x svg { pointer-events: none; width: 14px; height: 14px; }
.toast .toast-x:hover { background: rgba(21, 101, 192, 0.08); color: var(--ink); }
.toast-desc:empty { display: none; }

.modal-backdrop {
  pointer-events: auto;
  position: fixed; inset: 0; z-index: 10;
  display: grid; place-items: center; padding: 16px;
  background: rgba(11, 18, 32, 0.4);
  opacity: 0; visibility: hidden;
  transition: opacity 0.15s, visibility 0.15s;
}
.modal-backdrop.open { opacity: 1; visibility: visible; }

.modal {
  width: min(780px, 100%);
  max-height: min(860px, calc(100vh - 32px));
  overflow: auto;
  background:
    radial-gradient(ellipse 90% 70% at 50% -10%, rgba(66, 165, 245, 0.14), transparent 58%),
    #ffffff;
  border: 0;
  border-radius: 16px;
  box-shadow: var(--shadow);
  transform: translateY(8px);
  transition: transform 0.15s ease;
  position: relative;
  isolation: isolate;
}
.modal::before {
  content: '';
  position: absolute;
  inset: 0;
  pointer-events: none;
  z-index: 0;
  background-image:
    linear-gradient(rgba(21, 101, 192, 0.05) 1px, transparent 1px),
    linear-gradient(90deg, rgba(21, 101, 192, 0.05) 1px, transparent 1px);
  background-size: 44px 44px;
  mask-image: radial-gradient(ellipse 90% 80% at 50% 20%, black 20%, transparent 85%);
  -webkit-mask-image: radial-gradient(ellipse 90% 80% at 50% 20%, black 20%, transparent 85%);
}
.modal > * { position: relative; z-index: 1; }
.modal-backdrop.open .modal { transform: translateY(0); }

.modal-head {
  display: flex; align-items: center; justify-content: space-between; gap: 10px;
  padding: 18px 18px 14px;
  height: auto;
  background: transparent;
  border-bottom: 1px solid var(--line);
  position: sticky; top: 0; z-index: 1;
}
.modal-title-wrap {
  display: flex; align-items: center; gap: 10px; min-width: 0;
}
.modal-title {
  font-size: 18px; font-weight: 600; margin: 0;
  letter-spacing: -0.02em; color: var(--ink);
}
.modal-sub {
  margin: 3px 0 0;
  font-size: 12px;
  color: var(--ink-3);
}
.modal-head .icon-btn { color: var(--ink-3); }
.modal-head .icon-btn:hover { background: rgba(21, 101, 192, 0.08); color: var(--ink); }

.modal-body { padding: 18px; background: transparent; }
.modal .field label { color: var(--ink-3); }
.modal .input, .modal .select, .modal .textarea { background: transparent; color: var(--ink); }

.compose-grid {
  display: grid; grid-template-columns: 1.4fr 0.9fr; gap: 28px;
}
@media (max-width: 700px) {
  .compose-grid { grid-template-columns: 1fr; gap: 20px; }
}
.compose-main { padding-right: 0; }
.compose-side { padding: 0; }

.compose-side .box {
  border: 0; border-radius: 0; padding: 0; background: transparent;
}
.compose-side .box + .box {
  margin-top: 22px;
  padding-top: 18px;
  border-top: 1px solid var(--line);
}
.box-title {
  font-size: 11px; font-weight: 650; letter-spacing: 0.22em;
  text-transform: uppercase; color: var(--ink-3); margin: 0 0 10px;
}

.load-kv {
  display: grid; grid-template-columns: 92px 1fr; gap: 8px 10px;
  font-size: 12px;
}
.load-kv dt { color: var(--ink-3); font-weight: 600; }
.load-kv dd { margin: 0; color: var(--ink); font-weight: 550; word-break: break-word; }
.load-kv dd.mono, #kv-rate, #kv-miles, #kv-ref {
  font-family: var(--font-mono); font-size: 12px; color: var(--accent-brand);
}

#account-form-view .pad,
#tpl-form-view .pad {
  background: transparent;
  min-height: 100%;
}

.pad .card-desc:last-child { margin-bottom: 0; }
.panel-body .icon-btn { color: var(--ink-3); }
.panel-body .icon-btn:hover {
  color: var(--ink); background: rgba(21, 101, 192, 0.08);
}

/* Signal UI — restore solid header / bordered fields; hide Smart Dat arcs. */
:host {
  --accent-brand: #0b6bcb;
  --accent-hover: #084f96;
  --accent-press: #063e78;
  --header: #0b6bcb;
  --ink: #0f172a;
  --ink-2: #334155;
  --ink-3: #64748b;
  --line: #e2e8f0;
  --line-strong: #cbd5e1;
  --surface: #ffffff;
  --surface-2: #f4f7fb;
  --canvas: #f4f7fb;
  --r: 8px;
  --r-sm: 8px;
  --shadow: -8px 0 28px rgba(15, 23, 42, 0.14);
}
.horizon-arcs, .head-arcs, .road-line, .brand-bar, .brand-kicker { display: none !important; }
.panel::before, .modal::before, .btn::before { display: none !important; }
.panel {
  background: var(--canvas);
  box-shadow: var(--shadow);
  overflow: hidden;
}
.panel > * { z-index: auto; }
.panel-head {
  align-items: center;
  min-height: 48px;
  height: 48px;
  padding: 0 12px 0 14px;
  background: var(--header);
  overflow: visible;
}
.panel-head.sub { min-height: 48px; height: 48px; padding: 0 12px 0 10px; }
.brand { gap: 8px; }
.brand-mark {
  width: 28px; height: 28px; border-radius: 6px;
  background: #fff;
}
.brand-name {
  font-size: 13px; font-weight: 700; letter-spacing: 0.08em;
  text-transform: uppercase; color: #fff;
}
.head-actions .icon-btn, .back-btn {
  color: #dbeafe;
  background: transparent;
}
.head-actions .icon-btn:hover, .back-btn:hover {
  background: rgba(255,255,255,0.12);
  color: #fff;
}
.tabs {
  padding: 8px 10px 0;
  background: var(--canvas);
  border-bottom: 1px solid var(--line);
}
.tab {
  height: 36px;
  border: 1px solid transparent;
  border-radius: 8px 8px 0 0;
  font-size: 12px;
  letter-spacing: 0;
  text-transform: none;
}
.tab.active {
  background: #fff;
  border-color: var(--line);
  border-bottom-color: #fff;
  color: var(--accent-brand);
}
.panel-body { background: #fff; }
.section-bar { padding: 12px 14px 0; }
.section-bar .label {
  font-size: 11px; letter-spacing: 0.04em; text-transform: uppercase; color: var(--ink-3);
}
.section-hint { margin: 6px 14px 0; font-size: 12px; }
.pad { padding: 14px; }
.login-card { padding: 0; }
.login-title { font-size: 18px; letter-spacing: 0; }
.login-card .field label, .field label {
  letter-spacing: 0.04em;
}
.login-card .input, .input, .select, .textarea,
.login-card .input:hover, .input:hover, .select:hover, .textarea:hover,
.login-card .input:focus, .input:focus, .select:focus, .textarea:focus {
  border: 1px solid var(--line-strong);
  border-radius: 8px;
  background: #fff;
  padding: 9px 10px;
  font-size: 13px;
  box-shadow: none;
}
.input:focus, .select:focus, .textarea:focus,
.login-card .input:focus {
  border-color: var(--accent-brand);
  box-shadow: 0 0 0 2px rgba(11, 107, 203, 0.16);
}
.btn, .btn-primary, .btn-secondary, .btn-google, .btn-danger, .btn-linkish, .btn-ghost {
  isolation: auto;
  overflow: visible;
  background: var(--accent-brand);
  color: #fff;
  border: 1px solid var(--accent-brand);
  box-shadow: none;
  text-shadow: none;
  height: 36px;
  font-size: 13px;
}
.btn:hover:not(:disabled), .btn-primary:hover:not(:disabled) {
  background: var(--accent-hover);
  border-color: var(--accent-hover);
  box-shadow: none;
  color: #fff;
}
.btn-secondary, .btn-linkish, .choice {
  background: #fff;
  color: var(--ink);
  border: 1px solid var(--line-strong);
  box-shadow: none;
  text-shadow: none;
}
.btn-secondary:hover:not(:disabled), .choice:hover {
  background: var(--surface-2);
  color: var(--ink);
  box-shadow: none;
}
.btn-ghost {
  background: transparent;
  color: var(--ink-2);
  border-color: transparent;
  height: 28px;
}
.btn-danger { background: #fee2e2; color: #dc2626; border-color: #fecaca; }
.btn-sm { height: 28px; box-shadow: none; }
.list-card, .session-box, .oauth-wait, .manual-block, .empty, .preview-box {
  background: #fff;
  border: 1px solid var(--line);
  border-radius: 8px;
}
.ai-assist {
  margin: 0 0 14px;
  padding: 0 0 14px;
  border: 0;
  border-bottom: 1px solid var(--line);
  background: transparent;
  border-radius: 0;
}
.ai-composer {
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 40px;
  padding: 4px 4px 4px 12px;
  border: 1px solid var(--line-strong);
  border-radius: 8px;
  background: #fff;
  box-shadow: none;
}
.ai-composer:focus-within {
  border-color: var(--accent-brand);
  box-shadow: 0 0 0 2px rgba(11, 107, 203, 0.16);
}
.ai-composer-input {
  height: 32px !important;
  min-height: 32px !important;
  max-height: 32px !important;
  margin: 0 !important;
  padding: 0 !important;
  border: 0 !important;
  box-shadow: none !important;
  background: transparent !important;
  font-size: 13px;
}
.ai-composer-go {
  height: 32px !important;
  min-height: 32px !important;
  width: auto;
  min-width: 68px;
  padding: 0 14px;
  background: var(--accent-brand);
  color: #fff;
  border: 0;
  box-shadow: none;
  border-radius: 6px;
}
.list-card, .session-box { padding: 10px 12px; margin-bottom: 8px; }
.list { gap: 8px; }
.smtp-progress, .smtp-guide { border: 1px solid var(--line); border-radius: 8px; padding: 10px 12px; }
.modal {
  background: #fff;
  border: 1px solid var(--line);
  border-radius: 10px;
}
.modal-head {
  background: var(--header);
  height: 48px;
  padding: 0 14px;
}
.modal-title { color: #fff; font-size: 13px; letter-spacing: 0.06em; text-transform: uppercase; }
.modal-sub { color: #dbeafe; }
.modal-body { background: #fff; }
.modal .input, .modal .select, .modal .textarea { background: #fff; }
.compose-side .box { background: var(--surface-2); border: 1px solid var(--line); border-radius: 8px; padding: 12px; }
.compose-side .box + .box { border-top: 1px solid var(--line); }
#account-form-view .pad, #tpl-form-view .pad { background: var(--canvas); }
.toast { border-radius: 8px; }
</style>

<div class="panel-backdrop" id="panel-backdrop"></div>
<aside class="panel" id="panel" role="dialog" aria-label="Signal">
  <div class="panel-head" id="panel-head-main">
    <div class="brand">
      <img class="brand-mark" src="${BRAND_MARK}" alt="" width="28" height="28" />
      <div>
        <div class="brand-name">Signal</div>
      </div>
    </div>
    <div class="head-actions">
      <button class="icon-btn" id="panel-close" type="button" aria-label="Close">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>
      </button>
    </div>
  </div>

  <div class="panel-head sub" id="panel-head-sub" hidden>
    <button class="back-btn" id="btn-back" type="button" aria-label="Back">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
    </button>
    <div class="brand-copy grow">
      <div class="brand-name" id="sub-title">BACK</div>
      <div class="brand-sub" id="sub-desc"></div>
    </div>
    <div class="head-actions">
      <button class="icon-btn" id="panel-close-sub" type="button" aria-label="Close">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>
      </button>
    </div>
  </div>

  <div class="tabs" id="main-tabs" role="tablist">
    <button class="tab" id="tab-templates" type="button" role="tab" data-tab="templates">Templates</button>
    <button class="tab active" id="tab-account" type="button" role="tab" data-tab="account">Account</button>
  </div>

  <div class="panel-body">
    <div id="view-account">
      <div id="oauth-wait" hidden>
        <div class="pad">
          <div class="oauth-wait">
            <div class="oauth-spin" aria-hidden="true"></div>
            <strong>Finish Google sign-in</strong>
            <p>A Google account window opened outside DAT. Choose an account, allow access, and this screen will update on its own.</p>
            <button class="btn btn-secondary btn-block" id="oauth-wait-cancel" type="button">Cancel</button>
          </div>
        </div>
      </div>

      <div id="account-list-view">
        <div class="pad" id="auth-card">
          <div id="auth-signed-out" class="login-card">
            <div class="login-title">Sign in</div>
            <div class="road-line" aria-hidden="true"></div>
            <p class="card-desc">Access your DAT workspace.</p>
            <div class="field">
              <label for="login-email">Email</label>
              <input class="input" id="login-email" type="email" autocomplete="username" placeholder="you@company.com" />
            </div>
            <div class="field">
              <label for="login-pass">Password</label>
              <div class="pw-field">
                <input class="input" id="login-pass" type="password" autocomplete="current-password" placeholder="••••••••" />
                <button class="pw-toggle" type="button" data-pw-toggle="login-pass" aria-label="Show password"></button>
              </div>
            </div>
            <button class="btn btn-primary btn-block" id="btn-login" type="button">Sign in</button>
          </div>
        </div>

        <div id="accounts-card" hidden>
          <div class="section-bar" id="accounts-bar">
            <span class="label">Connected accounts</span>
            <button class="btn btn-primary btn-sm" id="btn-add-account" type="button">Add account</button>
          </div>
          <p class="section-hint" id="accounts-hint">Turn on <strong>Use default</strong> for the enabled account used when sending from a load row. Extra emails stay connected until an admin enables them.</p>
          <div class="pad" style="padding-top:10px">
            <div id="accounts-list" class="list"></div>
            <div class="empty" id="accounts-empty" hidden>
              <strong>No email connected</strong>
              <p>Connect an email account to email brokers directly from a load row.</p>
              <div class="empty-actions">
                <button class="btn btn-google" id="btn-connect-gmail-empty" type="button">
                  <svg class="g-ico" viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
                  Connect Gmail
                </button>
                <button class="btn btn-secondary" id="btn-add-account-empty" type="button">Add account</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div id="account-form-view" hidden>
        <div class="pad" id="connect-card">
          <div class="login-card" id="connect-choice">
            <div class="login-title">Choose how to send</div>
            <p class="card-desc">Use Google to connect Gmail in one click, or enter your own SMTP server.</p>
            <button class="btn btn-google btn-block" id="choice-oauth" type="button">
              <svg class="g-ico" viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
              Connect Gmail
            </button>
            <div class="divider-or" id="oauth-or">Or</div>
            <button class="btn btn-secondary btn-block" id="choice-smtp" type="button">Connect using SMTP</button>
          </div>

          <div class="login-card" id="connect-smtp" hidden>
            <div class="login-title">SMTP server</div>
            <p class="card-desc">Enter the mailbox and server your company uses to send mail. For Gmail, use an app password with smtp.gmail.com (587 or 465).</p>
            <div class="field">
              <label for="smtp-email">From address</label>
              <input class="input" id="smtp-email" type="email" placeholder="dispatch@company.com" />
            </div>
            <input type="hidden" id="smtp-name" value="" />
            <div class="row">
              <div class="field grow">
                <label for="smtp-host">Host</label>
                <input class="input mono" id="smtp-host" placeholder="smtp.company.com" />
              </div>
              <div class="field field-port">
                <label for="smtp-port">Port</label>
                <input class="input mono" id="smtp-port" value="587" placeholder="587" />
              </div>
            </div>
            <div class="field">
              <label for="smtp-user">Username</label>
              <input class="input" id="smtp-user" type="text" placeholder="dispatch@company.com" autocomplete="username" />
            </div>
            <div class="field">
              <label for="smtp-pass">Password</label>
              <div class="pw-field">
                <input class="input" id="smtp-pass" type="password" autocomplete="current-password" />
                <button class="pw-toggle" type="button" data-pw-toggle="smtp-pass" aria-label="Show password"></button>
              </div>
              <p class="hint">Gmail and Outlook need an app password — see the guide below.</p>
            </div>
            <label class="row" style="gap:8px;margin-bottom:12px;font-size:12px;font-weight:600;color:var(--ink-2)">
              <input type="checkbox" id="smtp-secure" />
              SSL (port 465)
            </label>
            <div class="smtp-progress" id="smtp-progress" hidden>
              <div class="smtp-progress-bar" aria-hidden="true"><span></span></div>
              <div class="smtp-progress-text" id="smtp-progress-text">Connecting…</div>
            </div>
            <button class="btn btn-primary btn-block" id="btn-connect-smtp" type="button">Connect SMTP</button>
            <div class="smtp-guide-label">Need Help</div>
            <details class="smtp-guide" id="smtp-guide">
              <summary>Host, port &amp; app passwords</summary>
              <div class="smtp-guide-body">
                <div class="smtp-guide-title">Which host and port</div>
                <table class="smtp-guide-table">
                  <thead>
                    <tr><th>Email</th><th>Host</th><th>Port</th><th>SSL</th></tr>
                  </thead>
                  <tbody>
                    <tr><td>Gmail</td><td><code>smtp.gmail.com</code></td><td>465</td><td>On</td></tr>
                    <tr><td>Outlook, Hotmail, Live</td><td><code>smtp.office365.com</code></td><td>587</td><td>Off</td></tr>
                    <tr><td>Yahoo</td><td><code>smtp.mail.yahoo.com</code></td><td>465</td><td>On</td></tr>
                    <tr><td>Work / other</td><td>Ask IT, or smtp.yourdomain.com</td><td>587 or 465</td><td>Off on 587, on on 465</td></tr>
                  </tbody>
                </table>
                <p style="margin-top:8px">Username is usually your full email. Do not use your normal login password for Gmail or Outlook — use an app password.</p>

                <div class="smtp-guide-title">Gmail app password</div>
                <ol>
                  <li>Turn on 2-Step Verification in your Google Account.</li>
                  <li>Open <button class="link" type="button" id="smtp-help-gmail">Google App passwords</button>.</li>
                  <li>Create an app password named Signal, then paste the 16-character code in Password.</li>
                </ol>

                <div class="smtp-guide-title">Outlook app password</div>
                <ol>
                  <li>Turn on two-step verification on your Microsoft account.</li>
                  <li>Open <button class="link" type="button" id="smtp-help-outlook">Microsoft security</button> → Advanced security options → App passwords.</li>
                  <li>Create one and paste it in Password (not your Outlook password).</li>
                </ol>

                <div class="smtp-guide-title">Other providers</div>
                <p>Look up “SMTP settings” plus your provider name. Use the host and port they list. If they offer an app password or “mail client password,” use that. Otherwise use the mailbox password your IT team gave you.</p>
              </div>
            </details>
          </div>
        </div>
      </div>
    </div>

    <div id="view-templates" hidden>
      <div id="tpl-list-view">
        <div class="section-bar">
          <span class="label" id="tpl-section-label">Templates</span>
          <button class="btn btn-primary btn-sm" id="btn-new-tpl" type="button">+ New</button>
        </div>
        <p class="section-hint" id="tpl-hint">Create templates, then pick one from the email icon on a load row.</p>
        <div class="pad" style="padding-top:10px">
          <div id="tpl-list" class="list"></div>
          <div class="empty" id="tpl-empty" hidden>
            <strong>No templates yet</strong>
            <p>Create a reusable message with load fields so every broker email takes one click. A Load inquiry template is added for you when you start.</p>
            <button class="btn btn-primary btn-block" id="btn-new-tpl-empty" type="button">New template</button>
          </div>
        </div>
      </div>

      <div id="tpl-form-view" hidden>
        <div class="pad" id="tpl-editor">
          <span id="tpl-editor-title" hidden>New template</span>
          <input type="hidden" id="tpl-id" value="" />

          <div id="tpl-editor-fields">
            <div class="ai-assist" id="tpl-ai">
              <label class="ai-assist-label" for="tpl-ai-prompt">AI draft</label>
              <div class="ai-composer">
                <input class="ai-composer-input" id="tpl-ai-prompt" type="text" maxlength="500" placeholder="Short load inquiry for this lane" autocomplete="off" />
                <button class="ai-composer-go" id="btn-tpl-ai" type="button" aria-label="Write draft with AI">Write</button>
              </div>
              <div class="chips ai-suggest" id="tpl-ai-suggest">
                <button type="button" class="chip" data-ai-suggest="Short load inquiry asking if {{origin}} to {{destination}} is still available.">Load inquiry</button>
                <button type="button" class="chip" data-ai-suggest="Polite follow-up if we have not heard back on this load.">Follow-up</button>
                <button type="button" class="chip" data-ai-suggest="Ask the broker for their best rate on {{origin}} to {{destination}}.">Rate check</button>
              </div>
              <p class="ai-assist-status" id="tpl-ai-status" hidden></p>
            </div>
            <div class="field">
              <label for="tpl-name">Name</label>
              <input class="input" id="tpl-name" />
            </div>
            <div class="field">
              <label for="tpl-subject">Subject</label>
              <input class="input" id="tpl-subject" />
            </div>

            <div class="chip-row">
              <span class="preview-label" style="margin:0">Load fields</span>
              <div class="insert-target" role="group" aria-label="Insert into">
                <button type="button" id="tpl-focus-subject">Subject</button>
                <button type="button" id="tpl-focus-body" class="active">Body</button>
              </div>
            </div>
            <div class="chips" id="tpl-chips"></div>
            <p class="chip-note">Click a field to insert it at the cursor. Values fill in from the load row.</p>

            <div class="field" style="margin-top:12px">
              <label for="tpl-body">Body</label>
              <textarea class="textarea" id="tpl-body" style="min-height:140px"></textarea>
            </div>

            <button class="btn btn-secondary btn-block" id="btn-tpl-preview" type="button" style="margin-top:12px">Preview</button>

            <div class="row wrap" style="margin-top:14px">
              <button class="btn btn-primary grow" id="btn-save-tpl" type="button">Save template</button>
              <button class="btn btn-secondary" id="btn-reset-tpl" type="button">Clear</button>
              <button class="btn btn-danger" id="btn-delete-tpl" type="button" hidden>Delete</button>
            </div>
          </div>

          <div id="tpl-preview-view" hidden>
            <p class="card-desc">Placeholders are filled with the current load when one is open.</p>
            <div class="preview-box" id="tpl-preview"></div>
            <button class="btn btn-secondary btn-block" id="btn-tpl-preview-back" type="button" style="margin-top:14px">Back to editor</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</aside>

<div class="modal-backdrop" id="popup-backdrop">
  <div class="modal" id="popup" role="dialog" aria-label="Email broker">
    <div class="modal-head">
      <div class="modal-title-wrap">
        <span class="brand-bar" aria-hidden="true"></span>
        <div>
          <h2 class="modal-title">Email broker</h2>
          <p class="modal-sub" id="popup-sub"></p>
        </div>
      </div>
      <button class="icon-btn" id="popup-close" type="button" aria-label="Close compose">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>
      </button>
    </div>
    <div class="modal-body">
      <div class="compose-grid">
        <div class="compose-main">
          <div class="field">
            <label for="popup-to">To</label>
            <input class="input" id="popup-to" type="email" />
          </div>
          <div class="grid-2">
            <div class="field">
              <label for="popup-from">From account</label>
              <select class="select" id="popup-from"></select>
            </div>
            <div class="field">
              <label for="popup-template">Template</label>
              <select class="select" id="popup-template"></select>
            </div>
          </div>
          <div class="field">
            <label for="popup-subject">Subject</label>
            <input class="input" id="popup-subject" />
          </div>
          <div class="chips" id="popup-chips"></div>
          <div class="field">
            <label for="popup-body">Message</label>
            <textarea class="textarea" id="popup-body" style="min-height:170px"></textarea>
          </div>
          <div class="row wrap" style="margin-top:4px">
            <button class="btn btn-primary" id="popup-send" type="button">Send email</button>
            <button class="btn btn-linkish" id="popup-save-tpl" type="button">Save as template</button>
          </div>
        </div>
        <div class="compose-side">
          <div class="box">
            <p class="box-title">Load context</p>
            <dl class="load-kv" id="popup-load-kv">
              <dt>Origin</dt><dd id="kv-origin">—</dd>
              <dt>Destination</dt><dd id="kv-destination">—</dd>
              <dt>Rate</dt><dd id="kv-rate">—</dd>
              <dt>Miles</dt><dd id="kv-miles">—</dd>
              <dt>Broker</dt><dd id="kv-broker">—</dd>
              <dt>Ref</dt><dd id="kv-ref">—</dd>
            </dl>
          </div>
          <div class="box">
            <p class="box-title">Preview</p>
            <div class="preview-box" id="popup-preview" style="max-height:260px"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="toast" id="toast" role="status">
  <div class="toast-ico" aria-hidden="true"></div>
  <div class="toast-body">
    <div class="toast-title"></div>
    <div class="toast-desc"></div>
  </div>
  <button class="toast-x" type="button" aria-label="Dismiss" data-toast-dismiss="toast">
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 6l12 12M18 6 6 18"/></svg>
  </button>
</div>
<div class="toast" id="popup-toast" role="status">
  <div class="toast-ico" aria-hidden="true"></div>
  <div class="toast-body">
    <div class="toast-title"></div>
    <div class="toast-desc"></div>
  </div>
  <button class="toast-x" type="button" aria-label="Dismiss" data-toast-dismiss="popup-toast">
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 6l12 12M18 6 6 18"/></svg>
  </button>
</div>

`;

(document.documentElement || document.body).appendChild(host);

  const $ = (id) => shadow.getElementById(id);
  const show = (el, on) => {
    if (!el) return;
    if (on) el.removeAttribute('hidden');
    else el.setAttribute('hidden', '');
  };

  const ICO_OK =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.5 2.5L16 9"/></svg>';
  const ICO_ERR =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l9 16H3L12 3z"/><path d="M12 10v4M12 17h.01"/></svg>';
  const ICO_EDIT =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>';
  const ICO_TRASH =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/></svg>';
  const ICO_CHECK =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.5 2.5L16 9"/></svg>';
  const ICO_EYE =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>';
  const ICO_EYE_OFF =
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19M1 1l22 22M14.12 14.12a3 3 0 1 1-4.24-4.24"/></svg>';

  const SMTP_PROGRESS_STEPS = [
    'Looking up mail server…',
    'Opening SMTP connection…',
    'Signing in…',
    'Saving account…'
  ];
  let smtpProgressTimer = null;

  function paintPasswordToggles() {
    shadow.querySelectorAll('[data-pw-toggle]').forEach((btn) => {
      if (!btn.innerHTML.trim()) btn.innerHTML = ICO_EYE;
    });
  }

  function togglePasswordVisibility(btn) {
    const id = btn.getAttribute('data-pw-toggle');
    const input = $(id);
    if (!input) return;
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
    btn.setAttribute('aria-pressed', show ? 'true' : 'false');
    btn.innerHTML = show ? ICO_EYE_OFF : ICO_EYE;
  }

  function setSmtpProgress(on, text) {
    const box = $('smtp-progress');
    const label = $('smtp-progress-text');
    if (label && text) label.textContent = text;
    if (box) box.hidden = !on;
  }

  function startSmtpProgress() {
    let i = 0;
    setSmtpProgress(true, SMTP_PROGRESS_STEPS[0]);
    clearInterval(smtpProgressTimer);
    smtpProgressTimer = setInterval(() => {
      i = Math.min(i + 1, SMTP_PROGRESS_STEPS.length - 1);
      setSmtpProgress(true, SMTP_PROGRESS_STEPS[i]);
      if (i >= SMTP_PROGRESS_STEPS.length - 1) {
        clearInterval(smtpProgressTimer);
        smtpProgressTimer = null;
      }
    }, 1800);
  }

  function stopSmtpProgress() {
    clearInterval(smtpProgressTimer);
    smtpProgressTimer = null;
    setSmtpProgress(false);
  }

  function formatUserError(value, fallback) {
    if (typeof toUserMessage === 'function') {
      return toUserMessage(value, fallback || 'Something went wrong. Please try again.');
    }
    const s = String(value || '').trim();
    return s && s !== '[object Object]' ? s : fallback || 'Something went wrong. Please try again.';
  }

  function friendlyUiText(text, fallback) {
    let s = formatUserError(text, '');
    s = String(s || '')
      .replace(/https?:\/\/[^\s"'<>)\]]+/gi, '')
      .replace(/\b[\w.-]*apexskillzone\.com\b/gi, '')
      .replace(/\bGOOGLE_[A-Z0-9_]+\b/g, '')
      .replace(/\s{2,}/g, ' ')
      .trim();
    if (!s || s === '[object Object]') {
      return fallback || 'Something went wrong. Please try again.';
    }
    return s;
  }

  function send(type, extra = {}) {
    return new Promise((resolve) => {
      const attempt = (triesLeft) => {
        try {
          chrome.runtime.sendMessage({ type, ...extra }, (res) => {
            if (chrome.runtime.lastError) {
              if (triesLeft > 0) {
                setTimeout(() => attempt(triesLeft - 1), 50);
                return;
              }
              resolve({
                success: false,
                message: 'Please try again in a moment.'
              });
              return;
            }
            resolve(res || { success: false, message: 'Please try again in a moment.' });
          });
        } catch (err) {
          if (triesLeft > 0) {
            setTimeout(() => attempt(triesLeft - 1), 50);
            return;
          }
          resolve({ success: false, message: 'Please try again in a moment.' });
        }
      };
      attempt(2);
    });
  }

  function toast(message, ok = true, target = 'toast', desc = '') {
    const el = $(target);
    if (!el) return;
    const titleEl = el.querySelector('.toast-title');
    const descEl = el.querySelector('.toast-desc');
    const icoEl = el.querySelector('.toast-ico');
    const title = friendlyUiText(message, ok ? '' : 'Something went wrong. Please try again.');
    const detail = desc ? friendlyUiText(desc, '') : '';
    if (titleEl) titleEl.textContent = title || '';
    else el.textContent = title || '';
    if (descEl) {
      descEl.textContent = detail || '';
      descEl.hidden = !detail;
    }
    if (icoEl) icoEl.innerHTML = ok
      ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 13l4 4L19 7"/></svg>'
      : '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2a10 10 0 100 20 10 10 0 000-20zm1 14h-2v-2h2v2zm0-4h-2V7h2v5z"/></svg>';
    el.className = 'toast show ' + (ok ? 'ok' : 'err');
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.remove('show'), 5000);
  }

  function accounts() {
    const list = state.status?.accounts;
    if (Array.isArray(list) && list.length) return list;
    if (state.status?.account) return [state.status.account];
    return [];
  }

  function emailLimits() {
    const l = state.status?.limits || {};
    return {
      maxAccounts: Number(l.maxEmailAccounts) || 0,
      maxTemplates: Number(l.maxTemplates) || 0,
      accountsUsed: Number(l.emailAccountsUsed != null ? l.emailAccountsUsed : accounts().length) || 0,
      templatesUsed:
        Number(
          l.templatesUsed != null ? l.templatesUsed : (state.status?.templates || []).length
        ) || 0
    };
  }

  function atAccountLimit() {
    const l = emailLimits();
    return l.maxAccounts > 0 && l.accountsUsed >= l.maxAccounts;
  }

  function atTemplateLimit() {
    const l = emailLimits();
    return l.maxTemplates > 0 && l.templatesUsed >= l.maxTemplates;
  }

  function isAccountUsable(a) {
    if (!a) return false;
    if (typeof a.usable === 'boolean') return a.usable;
    if (typeof a.allowed === 'boolean') return a.allowed;
    return false;
  }

  function usableAccounts() {
    return accounts().filter(isAccountUsable);
  }

  function accountLimitMessage() {
    const l = emailLimits();
    const extra = Math.max(0, l.accountsUsed - l.maxAccounts);
    if (extra > 0) {
      return (
        l.maxAccounts +
        ' of ' +
        l.accountsUsed +
        ' emails can send. Ask an admin to enable which inboxes you can use.'
      );
    }
    if (l.maxAccounts === 1) {
      return 'Your account allows 1 connected email. Ask an admin to remove one before adding another.';
    }
    return (
      'Your account allows ' +
      l.maxAccounts +
      ' connected emails. Ask an admin to remove one before adding another.'
    );
  }

  function templateLimitMessage() {
    const l = emailLimits();
    if (l.maxTemplates === 1) {
      return 'Your account allows 1 template. Delete one to create another.';
    }
    return 'Your account allows ' + l.maxTemplates + ' templates. Delete one to create another.';
  }

  function cloneStatus() {
    try {
      return state.status
        ? JSON.parse(JSON.stringify(state.status))
        : { templates: [], accounts: [], account: null, connected: false };
    } catch {
      return { templates: [], accounts: [], account: null, connected: false };
    }
  }

  let statusWriteAt = 0;

  function writeStatusCache(data) {
    if (!data || typeof data !== 'object') return;
    state.status = data;
    state.statusLoaded = true;
    statusWriteAt = Date.now();
    try {
      chrome.storage.local.set({ emailStatusCache: { at: statusWriteAt, data } });
    } catch {
      // ignore
    }
    send('EMAIL_CACHE_STATUS', { data, at: statusWriteAt });
  }

  function commitStatus(data) {
    writeStatusCache(data);
    render();
  }

  function sortTemplates(list) {
    return (list || []).slice().sort((a, b) =>
      String(a.name || '').localeCompare(String(b.name || ''), undefined, { sensitivity: 'base' })
    );
  }

  function applyAccountList(next, accounts) {
    const list = Array.isArray(accounts) ? accounts : [];
    next.accounts = list;
    next.account = list.find((a) => a.isDefault && isAccountUsable(a)) || list.find(isAccountUsable) || null;
    next.connected = list.some(isAccountUsable);
    return next;
  }

  function applyVars(text, to) {
    const api = Tpl();
    if (api && typeof api.substituteTemplate === 'function') {
      return api.substituteTemplate(text, state.loadVars || api.SAMPLE_LOAD, to || state.recipient);
    }
    return String(text || '').replace(/\{\{\s*(email|to)\s*\}\}/gi, to || state.recipient || '');
  }

  function currentComposeVars() {
    const api = Tpl();
    const to = ($('popup-to') && $('popup-to').value.trim()) || state.recipient || '';
    if (api && typeof api.buildVars === 'function') {
      return api.buildVars(state.loadVars || {}, to);
    }
    return { email: to, to };
  }

  function updateLoadKv() {
    const v = state.loadVars || {};
    const set = (id, val) => {
      const el = $(id);
      if (el) el.textContent = val && String(val).trim() ? String(val) : '—';
    };
    set('kv-origin', v.origin || v.originCity);
    set('kv-destination', v.destination || v.dest || v.destinationCity);
    set('kv-rate', v.rate);
    set('kv-miles', v.miles);
    set('kv-broker', v.broker || v.company);
    set('kv-ref', v.ref || v.reference || v.loadId);
  }

  function escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function setPreviewHtml(box, subject, body) {
    if (!box) return;
    box.innerHTML =
      '<span class="pv-subject">' +
      escapeHtml(subject || '(no subject)') +
      '</span><span class="pv-body">' +
      escapeHtml(body || '') +
      '</span>';
  }

  function updatePreview() {
    const to = ($('popup-to')?.value || '').trim();
    const subject = applyVars($('popup-subject')?.value, to) || '(no subject)';
    const body = applyVars($('popup-body')?.value, to) || '';
    setPreviewHtml($('popup-preview'), subject, body);
  }

  function setTplPreviewOpen(on) {
    state.tplPreviewOpen = Boolean(on);
    show($('tpl-editor-fields'), !state.tplPreviewOpen);
    show($('tpl-preview-view'), state.tplPreviewOpen);
    if (state.tplPreviewOpen) updateTemplateEditorPreview();
    updateChrome();
  }

  function updateTemplateEditorPreview() {
    if (!state.tplPreviewOpen) return;
    const api = Tpl();
    const sample = state.loadVars || (api && api.SAMPLE_LOAD) || {};
    const sub =
      api && api.substituteTemplate ? (t) => api.substituteTemplate(t, sample) : (t) => t;
    const subject = sub($('tpl-subject')?.value) || '(subject)';
    const body = sub($('tpl-body')?.value) || '';
    setPreviewHtml($('tpl-preview'), subject, body);
  }

  function setupTemplateVarChips() {
    const api = Tpl();
    const syncInsertButtons = () => {
      const subBtn = $('tpl-focus-subject');
      const bodyBtn = $('tpl-focus-body');
      if (subBtn) subBtn.classList.toggle('active', state.tplInsertTarget === 'subject');
      if (bodyBtn) bodyBtn.classList.toggle('active', state.tplInsertTarget === 'body');
    };

    const fill = (wrapId, getTarget) => {
      const wrap = $(wrapId);
      if (!wrap || !api) return;
      wrap.innerHTML = '';
      (api.INSERT_VARS || []).forEach((v) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'chip';
        btn.title = 'Insert ' + (v.label || v.key) + ' (' + v.token + ')';
        btn.innerHTML =
          '<span>' +
          (v.label || v.key) +
          '</span><span class="chip-key">' +
          v.token +
          '</span>';
        btn.addEventListener('mousedown', (e) => e.preventDefault());
        btn.addEventListener('click', () => {
          const target = getTarget();
          if (!target || !api.insertAtCursor) return;
          api.insertAtCursor(target, v.token);
          target.focus();
          if (wrapId === 'tpl-chips' && state.tplPreviewOpen) updateTemplateEditorPreview();
          else updatePreview();
        });
        wrap.appendChild(btn);
      });
    };

    fill('tpl-chips', () =>
      state.tplInsertTarget === 'subject' ? $('tpl-subject') : $('tpl-body')
    );
    fill('popup-chips', () => {
      const active = shadow.activeElement;
      if (active === $('popup-subject')) return $('popup-subject');
      return $('popup-body');
    });

    $('tpl-subject')?.addEventListener('focus', () => {
      state.tplInsertTarget = 'subject';
      syncInsertButtons();
    });
    $('tpl-body')?.addEventListener('focus', () => {
      state.tplInsertTarget = 'body';
      syncInsertButtons();
    });
    $('tpl-focus-subject')?.addEventListener('click', () => {
      state.tplInsertTarget = 'subject';
      syncInsertButtons();
      $('tpl-subject')?.focus();
    });
    $('tpl-focus-body')?.addEventListener('click', () => {
      state.tplInsertTarget = 'body';
      syncInsertButtons();
      $('tpl-body')?.focus();
    });
    ['tpl-subject', 'tpl-body', 'tpl-name'].forEach((id) => {
      $(id)?.addEventListener('input', () => {
        if (state.tplPreviewOpen) updateTemplateEditorPreview();
      });
    });
    syncInsertButtons();
  }

  const ADD_ACCOUNT = '__add_account__';
  const ADD_TEMPLATE = '__add_template__';

  function prependAddOption(sel, value, label) {
    if (!sel) return;
    const sep = document.createElement('option');
    sep.disabled = true;
    sep.textContent = '────────';
    const opt = document.createElement('option');
    opt.value = value;
    opt.textContent = label;
    sel.insertBefore(sep, sel.firstChild);
    sel.insertBefore(opt, sel.firstChild);
  }

  function fillFromSelect() {
    const sel = $('popup-from');
    if (!sel) return;
    const list = accounts();
    const prev = sel.value !== ADD_ACCOUNT ? sel.value : '';
    sel.innerHTML = '';
    list.forEach((a) => {
      const opt = document.createElement('option');
      opt.value = a.id;
      const method =
        a.method === 'smtp' ? 'SMTP' : a.method === 'oauth' ? 'Google' : 'Gmail';
      const usable = isAccountUsable(a);
      opt.textContent =
        a.email +
        (a.isDefault ? ' (default)' : '') +
        (usable ? '' : ' (disabled)') +
        ' · ' +
        method;
      if (!usable) opt.disabled = true;
      sel.appendChild(opt);
    });
    if (!atAccountLimit()) prependAddOption(sel, ADD_ACCOUNT, '+ Add new account');
    const usable = usableAccounts();
    const preferred =
      (prev && usable.some((a) => a.id === prev) && prev) ||
      usable.find((a) => a.isDefault)?.id ||
      usable[0]?.id ||
      '';
    sel.value = preferred;
  }

  function fillTemplateSelect(selectEl) {
    if (!selectEl) return '';
    const templates = state.status?.templates || [];
    const current = selectEl.value !== ADD_TEMPLATE ? selectEl.value : '';
    selectEl.innerHTML = '<option value="">— No template / custom —</option>';
    templates.forEach((t) => {
      const opt = document.createElement('option');
      opt.value = t.id;
      opt.textContent = t.name;
      selectEl.appendChild(opt);
    });
    prependAddOption(selectEl, ADD_TEMPLATE, '+ Add new template');
    const preferred =
      (current && templates.some((t) => t.id === current) && current) ||
      '';
    selectEl.value = preferred;
    return preferred;
  }

  function applyTemplateToPopup(id) {
    const tpl = (state.status?.templates || []).find((t) => t.id === id);
    if (!tpl) return;
    $('popup-subject').value = tpl.subject || '';
    $('popup-body').value = tpl.body || '';
    updatePreview();
  }

  const TOOLBAR_BTN_ID = 'dat-email-filters-button';
  const TOOLBAR_STYLE_ID = 'dat-email-filters-css';

  function hasSendingAccount() {
    return usableAccounts().length > 0;
  }

  function toolbarButtonCopy() {
    if (hasSendingAccount()) {
      return {
        label: 'MANAGE TEMPLATES',
        title: 'Manage email templates'
      };
    }
    return {
      label: 'CONNECT EMAIL',
      title: 'Connect an email sending account'
    };
  }

  function nativeFilterButton() {
    return (
      document.getElementById('bookBidFiltersButton') ||
      document.querySelector(
        '.search-filters.search-filters-updated .search-filters-button:not(#' + TOOLBAR_BTN_ID + ')'
      )
    );
  }

  function toolbarButtonClassName() {
    const native = nativeFilterButton();
    if (native && native.className) {
      return String(native.className)
        .split(/\s+/)
        .filter((cls) => cls && !/^cdk-|^mat-button-disabled$|^mat-button-ripple-round$/.test(cls))
        .join(' ');
    }
    return 'mat-focus-indicator search-filters-button mat-button mat-button-base';
  }

  function copyNativeNgAttrs(btn) {
    const native = nativeFilterButton();
    if (!native || !btn) return;
    Array.from(native.attributes).forEach((attr) => {
      if (attr.name.startsWith('_ngcontent') || attr.name.startsWith('_nghost')) {
        btn.setAttribute(attr.name, attr.value);
      }
    });
  }

  function cssColor(value, fallback) {
    const v = String(value || '').trim();
    if (!v || v === 'transparent' || v === 'rgba(0, 0, 0, 0)') return fallback;
    return v;
  }

  function lightenColor(color, amount) {
    const m = String(color).match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
    if (!m) return '#f8f9fb';
    const mix = (c) => Math.round(Number(c) + (255 - Number(c)) * amount);
    return 'rgb(' + mix(m[1]) + ', ' + mix(m[2]) + ', ' + mix(m[3]) + ')';
  }

  function syncToolbarButtonLabel() {
    const btn = document.getElementById(TOOLBAR_BTN_ID);
    if (!btn) return;
    const copy = toolbarButtonCopy();
    const text = document.getElementById('datEmailFilterButtonText');
    if (text) text.textContent = copy.label;
    btn.title = copy.title;
    btn.setAttribute('aria-label', copy.label);
  }

  function defaultSidebarTab() {
    return hasSendingAccount() ? 'templates' : 'account';
  }

  function setSidebarOpen(next, tab) {
    state.sidebarOpen = !!next;
    $('panel')?.classList.toggle('open', state.sidebarOpen);
    $('panel-backdrop')?.classList.toggle('open', state.sidebarOpen);
    syncToolbarButtonState();
    if (state.sidebarOpen) {
      if (tab) setTab(tab);
      loadAll();
    }
  }

  function ensureToolbarStyles() {
    let style = document.getElementById(TOOLBAR_STYLE_ID);
    if (!style) {
      style = document.createElement('style');
      style.id = TOOLBAR_STYLE_ID;
      (document.head || document.documentElement).appendChild(style);
    }

    let bg = '#eceff1';
    let hoverBg = '#f7f8fa';
    let borderColor = '#d5dbe3';
    let color = '#333333';
    let radius = '4px';
    let fontSize = '12px';
    let fontWeight = '400';
    let fontFamily = '"Sequel Sans", Helvetica, Arial, sans-serif';
    let height = '28px';
    let padL = '10px';
    let padR = '4px';
    let letter = 'normal';
    let marginLeft = '8px';

    const native = nativeFilterButton();
    if (native) {
      const cs = window.getComputedStyle(native);
      const textEl = native.querySelector('.search-filters-button-text, .mat-button-wrapper > span');
      const ts = textEl ? window.getComputedStyle(textEl) : cs;
      bg = cssColor(cs.backgroundColor, bg);
      borderColor = cssColor(cs.borderTopColor, borderColor);
      color = cssColor(ts.color || cs.color, color);
      if (cs.borderRadius) radius = cs.borderRadius;
      if (ts.fontSize) fontSize = ts.fontSize;
      if (ts.fontWeight) fontWeight = ts.fontWeight;
      if (ts.fontFamily) fontFamily = ts.fontFamily;
      if (cs.height && cs.height !== 'auto') height = cs.height;
      if (cs.paddingLeft) padL = cs.paddingLeft;
      if (cs.paddingRight) padR = cs.paddingRight;
      if (ts.letterSpacing && ts.letterSpacing !== 'normal') letter = ts.letterSpacing;
      if (cs.marginLeft && cs.marginLeft !== '0px') marginLeft = cs.marginLeft;
    }
    if (parseFloat(fontSize) >= 13.5) fontSize = '12px';
    if (parseInt(fontWeight, 10) >= 600) fontWeight = '400';
    hoverBg = lightenColor(bg, 0.42);

    style.textContent = `
      #${TOOLBAR_BTN_ID} {
        appearance: none !important;
        -webkit-appearance: none !important;
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        box-sizing: border-box !important;
        background: ${bg} !important;
        background-image: none !important;
        border: 1px solid ${borderColor} !important;
        border-radius: ${radius} !important;
        box-shadow: none !important;
        color: ${color} !important;
        font-family: ${fontFamily} !important;
        font-size: ${fontSize} !important;
        font-weight: ${fontWeight} !important;
        letter-spacing: ${letter} !important;
        line-height: 1 !important;
        height: ${height} !important;
        min-height: ${height} !important;
        max-height: ${height} !important;
        padding: 0 ${padR} 0 ${padL} !important;
        margin: 0 0 0 ${marginLeft} !important;
        text-transform: uppercase !important;
        cursor: pointer !important;
        vertical-align: middle !important;
      }
      #${TOOLBAR_BTN_ID}:hover,
      #${TOOLBAR_BTN_ID}:focus {
        background: ${hoverBg} !important;
        background-image: none !important;
        color: ${color} !important;
        border-color: ${borderColor} !important;
        box-shadow: none !important;
      }
      #${TOOLBAR_BTN_ID} .mat-button-wrapper {
        display: inline-flex !important;
        align-items: center !important;
        gap: 0 !important;
        padding: 0 !important;
        line-height: 1 !important;
      }
      #${TOOLBAR_BTN_ID} .search-filters-button-text {
        font-family: ${fontFamily} !important;
        font-size: ${fontSize} !important;
        font-weight: ${fontWeight} !important;
        letter-spacing: ${letter} !important;
        text-transform: uppercase !important;
        white-space: nowrap !important;
        line-height: 1 !important;
        color: inherit !important;
      }
      #${TOOLBAR_BTN_ID} .dat-email-filters-caret,
      #${TOOLBAR_BTN_ID} mat-icon,
      #${TOOLBAR_BTN_ID} .mat-icon,
      #${TOOLBAR_BTN_ID} .mat-button-ripple,
      #${TOOLBAR_BTN_ID} .mat-button-focus-overlay,
      #${TOOLBAR_BTN_ID} .dat-email-filters-ico {
        display: none !important;
      }
    `;
  }

  function syncToolbarButtonState() {
    const btn = document.getElementById(TOOLBAR_BTN_ID);
    if (!btn) return;
    btn.classList.toggle('dat-email-filters-open', !!state.sidebarOpen);
    btn.setAttribute('aria-pressed', state.sidebarOpen ? 'true' : 'false');
    syncToolbarButtonLabel();
  }

  function fillToolbarButton(btn) {
    const copy = toolbarButtonCopy();
    btn.id = TOOLBAR_BTN_ID;
    btn.type = 'button';
    btn.className = toolbarButtonClassName();
    btn.title = copy.title;
    btn.setAttribute('aria-label', copy.label);
    btn.setAttribute('aria-pressed', state.sidebarOpen ? 'true' : 'false');
    btn.setAttribute('data-test', 'dat-email-filters-button');
    btn.setAttribute('data-dat-email-bound', '1');
    btn.removeAttribute('aria-haspopup');
    btn.removeAttribute('aria-expanded');
    btn.removeAttribute('aria-controls');
    copyNativeNgAttrs(btn);
    btn.innerHTML =
      '<span class="mat-button-wrapper">' +
      '<span id="datEmailFilterButtonText" class="search-filters-button-text">' +
      copy.label +
      '</span>' +
      '</span>' +
      '<span class="mat-ripple mat-button-ripple"></span>' +
      '<span class="mat-button-focus-overlay"></span>';
  }

  function createToolbarButton() {
    const btn = document.createElement('button');
    fillToolbarButton(btn);
    btn.addEventListener(
      'click',
      (e) => {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        const opening = !state.sidebarOpen;
        setSidebarOpen(opening, opening ? defaultSidebarTab() : undefined);
      },
      true
    );
    return btn;
  }

  function placeToolbarButton(btn) {
    const bar = document.querySelector('.search-filters.search-filters-updated');
    if (!bar) return false;
    const inner = bar.firstElementChild || bar;
    const bookBid =
      inner.querySelector('#bookBidFiltersButton') ||
      document.getElementById('bookBidFiltersButton');

    if (bookBid && inner.contains(bookBid)) {
      let after = bookBid;
      let next = bookBid.nextElementSibling;
      if (next === btn) next = btn.nextElementSibling;
      if (next && String(next.tagName || '').toLowerCase() === 'mat-menu') {
        after = next;
      }
      if (btn.previousElementSibling !== after) {
        after.insertAdjacentElement('afterend', btn);
      }
      return true;
    }

    if (btn.parentElement !== inner) inner.appendChild(btn);
    return true;
  }

  function mountToolbarButton() {
    const bar = document.querySelector('.search-filters.search-filters-updated');
    if (!bar) return false;
    ensureToolbarStyles();

    const unbound = document.querySelectorAll('[id="' + TOOLBAR_BTN_ID + '"]');
    unbound.forEach((el) => {
      if (el.getAttribute('data-dat-email-bound') !== '1') el.remove();
    });
    const leftover = document.querySelectorAll('[id="' + TOOLBAR_BTN_ID + '"]');
    leftover.forEach((el, i) => {
      if (i > 0) el.remove();
    });

    let btn = document.getElementById(TOOLBAR_BTN_ID);
    if (btn && btn.getAttribute('data-dat-email-bound') !== '1') {
      btn.remove();
      btn = null;
    }
    if (!btn) btn = createToolbarButton();
    else if (
      btn.querySelector('.dat-email-filters-ico') ||
      btn.querySelector('.dat-email-filters-caret, mat-icon, .mat-icon') ||
      !btn.querySelector('#datEmailFilterButtonText')
    ) {
      fillToolbarButton(btn);
    }
    placeToolbarButton(btn);
    copyNativeNgAttrs(btn);
    ensureToolbarStyles();
    syncToolbarButtonState();
    return true;
  }

  function startToolbarMount() {
    let timer = null;
    const schedule = () => {
      if (timer) return;
      timer = setTimeout(() => {
        timer = null;
        mountToolbarButton();
      }, 200);
    };
    mountToolbarButton();
    const observer = new MutationObserver(schedule);
    observer.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(mountToolbarButton, 400);
    setTimeout(mountToolbarButton, 1200);
    setTimeout(mountToolbarButton, 2500);
  }

  function isSubView() {
    if (state.oauthWaiting) return false;
    return (
      (state.tab === 'account' && state.accountView === 'form') ||
      (state.tab === 'templates' && state.tplView === 'form')
    );
  }

  function updateChrome() {
    const sub = isSubView();
    show($('panel-head-main'), !sub);
    show($('panel-head-sub'), sub);
    show($('main-tabs'), !sub);

    if (state.tab === 'account' && state.accountView === 'form') {
      if ($('sub-title')) {
        $('sub-title').textContent = state.connectForm === 'smtp' ? 'Connect SMTP' : 'Add account';
      }
      if ($('sub-desc')) $('sub-desc').textContent = '';
    } else if (state.tab === 'templates' && state.tplView === 'form') {
      const editing = !!$('tpl-id')?.value;
      if ($('sub-title')) {
        $('sub-title').textContent = state.tplPreviewOpen
          ? 'Preview'
          : editing
            ? 'Edit template'
            : 'New template';
      }
      if ($('sub-desc')) $('sub-desc').textContent = '';
    }

    show($('oauth-wait'), state.oauthWaiting);
    show($('account-list-view'), !state.oauthWaiting && state.accountView === 'list');
    show($('account-form-view'), !state.oauthWaiting && state.accountView === 'form');
    show($('tpl-list-view'), state.tplView === 'list');
    show($('tpl-form-view'), state.tplView === 'form');
  }

  function openAccountForm() {
    if (atAccountLimit()) {
      toast(accountLimitMessage(), false);
      return;
    }
    state.tab = 'account';
    state.accountView = 'form';
    state.connectMode = 'force';
    setConnectForm('gmail');
    shadow.querySelectorAll('.tab').forEach((el) => {
      el.classList.toggle('active', el.dataset.tab === 'account');
    });
    show($('view-templates'), false);
    show($('view-account'), true);
    updateChrome();
  }

  function closeAccountForm() {
    state.accountView = 'list';
    state.connectMode = null;
    updateChrome();
  }

  function openTplForm({ reset = true } = {}) {
    if (reset && atTemplateLimit()) {
      toast(templateLimitMessage(), false);
      return;
    }
    state.tab = 'templates';
    state.tplView = 'form';
    if (reset) resetTplForm();
    shadow.querySelectorAll('.tab').forEach((el) => {
      el.classList.toggle('active', el.dataset.tab === 'templates');
    });
    show($('view-account'), false);
    show($('view-templates'), true);
    updateChrome();
    setTplPreviewOpen(false);
  }

  function closeTplForm() {
    state.tplView = 'list';
    resetTplForm();
    updateChrome();
  }

  function goBack() {
    if (state.tab === 'account' && state.accountView === 'form') {
      if (state.connectForm === 'smtp') {
        setConnectForm('gmail');
        updateChrome();
        return;
      }
      closeAccountForm();
      return;
    }
    if (state.tab === 'templates' && state.tplView === 'form' && state.tplPreviewOpen) {
      setTplPreviewOpen(false);
      return;
    }
    if (state.tab === 'templates' && state.tplView === 'form') {
      closeTplForm();
    }
  }

  function setTab(tab) {
    state.tab = tab;
    if (tab === 'account') state.accountView = 'list';
    if (tab === 'templates') {
      state.tplView = 'list';
      setTplPreviewOpen(false);
    }
    shadow.querySelectorAll('.tab').forEach((el) => {
      el.classList.toggle('active', el.dataset.tab === tab);
    });
    show($('view-templates'), tab === 'templates');
    show($('view-account'), tab === 'account');
    updateChrome();
  }

  function setConnectForm(mode) {
    state.connectForm = mode === 'smtp' ? 'smtp' : 'gmail';
    const smtp = state.connectForm === 'smtp';
    const waiting = state.oauthWaiting;
    show($('connect-choice'), !waiting && !smtp);
    show($('connect-smtp'), !waiting && smtp);
    if (!smtp) stopSmtpProgress();
    if (state.accountView === 'form') {
      if ($('sub-title')) {
        $('sub-title').textContent = smtp ? 'Connect SMTP' : 'Add account';
      }
    }
  }

  async function quickSendFromRow(recipient, loadVars, templateId) {
    const to =
      String(recipient || '').trim() ||
      String((loadVars && loadVars.email) || '').trim();
    if (!to) {
      toast('No broker email on this load', false);
      return { success: false };
    }

    state.recipient = to;
    state.loadVars = loadVars && typeof loadVars === 'object' ? loadVars : null;

    if (!state.statusLoaded) await loadAll();
    else loadAll();

    if (!state.session?.signedIn) {
      setSidebarOpen(true, 'account');
      toast('Sign in to send email', false);
      return { success: false };
    }

    const list = accounts();
    const defaultAccount = list.find((a) => a.isDefault && isAccountUsable(a)) || null;
    const templates = state.status?.templates || [];
    const chosenId = String(templateId || '').trim();
    const tpl = chosenId ? templates.find((t) => String(t.id) === chosenId) : null;

    if (!defaultAccount) {
      setSidebarOpen(true, 'account');
      toast(
        list.some(isAccountUsable)
          ? 'Turn on Use default for an account first'
          : list.length
            ? accountLimitMessage()
            : 'Connect an email first',
        false
      );
      return { success: false };
    }

    if (!tpl) {
      setSidebarOpen(true, 'templates');
      toast(
        templates.length
          ? 'Choose a template to send'
          : 'Create a template first',
        false
      );
      return { success: false };
    }

    const account = defaultAccount;

    const api = Tpl();
    const vars =
      api && typeof api.buildVars === 'function'
        ? api.buildVars(state.loadVars || {}, to)
        : { email: to, to };
    const subject = applyVars(tpl.subject || '', to);
    const body = applyVars(tpl.body || '', to);
    if (!subject || !String(body || '').trim()) {
      toast('Template is missing subject or body', false);
      return { success: false };
    }

    const broker =
      (state.loadVars && (state.loadVars.broker || state.loadVars.company)) ||
      to.split('@')[0] ||
      to;
    const origin = state.loadVars?.origin || state.loadVars?.originCity || '';
    const dest = state.loadVars?.destination || state.loadVars?.dest || '';
    const ref = state.loadVars?.ref || state.loadVars?.reference || '';
    const routeBits = [origin && dest ? origin + ' → ' + dest : '', ref ? 'Ref ' + ref : '']
      .filter(Boolean)
      .join(' · ');

    toast('Email sent to ' + broker, true, 'toast', routeBits);
    send('EMAIL_SEND', {
      payload: {
        to,
        subject,
        body,
        templateId: tpl.id,
        accountId: account.id,
        vars
      }
    }).then((res) => {
      if (!res?.success) {
        toast(res?.message || 'Email failed to send', false);
      }
    });
    return { success: true, queued: true };
  }

  async function openComposePopup(recipient, loadVars) {
    state.popupOpen = true;
    state.recipient = String(recipient || '').trim();
    if (loadVars && typeof loadVars === 'object') {
      state.loadVars = loadVars;
      if (!state.recipient && loadVars.email) state.recipient = String(loadVars.email).trim();
    } else {
      state.loadVars = null;
    }
    $('popup-backdrop')?.classList.add('open');
    if (state.recipient && $('popup-to')) $('popup-to').value = state.recipient;
    updateLoadKv();
    if (state.statusLoaded && state.session?.signedIn && accounts().length) {
      showComposeReady();
    }

    if (!state.statusLoaded) await loadAll();
    else loadAll();

    if (!state.session?.signedIn) {
      closeComposePopup();
      setSidebarOpen(true, 'account');
      toast('Sign in to send email', false);
      return;
    }

    if (!accounts().length) {
      closeComposePopup();
      setSidebarOpen(true, 'account');
      openAccountForm();
      toast('Connect an email first', false);
      return;
    }

    showComposeReady();
  }

  function showComposeReady() {
    fillFromSelect();
    const tplId = fillTemplateSelect($('popup-template'));
    if (tplId) applyTemplateToPopup(tplId);
    if (state.recipient) $('popup-to').value = state.recipient;
    updateLoadKv();
    updatePreview();
    $('popup-sub').textContent = state.recipient ? state.recipient : '';
  }

  function closeComposePopup() {
    state.popupOpen = false;
    $('popup-backdrop')?.classList.remove('open');
  }

  function methodLabel(a) {
    if (a.method === 'smtp') {
      return 'Custom SMTP' + (a.smtpHost ? ' - ' + a.smtpHost : '');
    }
    if (a.method === 'oauth') return 'Google - OAuth';
    return 'Gmail - App password';
  }

  function defaultSwitchMarkup(checked, locked) {
    return (
      '<label class="sw-wrap' +
      (locked ? ' is-locked' : '') +
      '"' +
      (locked ? ' title="Ask an admin to enable this email"' : '') +
      '>' +
      '<span class="sw-text">Use default</span>' +
      '<span class="sw">' +
      '<input class="def-sw" type="checkbox"' +
      (checked ? ' checked' : '') +
      (locked ? ' disabled' : '') +
      ' />' +
      '<span class="track" aria-hidden="true"></span>' +
      '</span>' +
      '</label>'
    );
  }

  function bindDefaultSwitch(root, onToggle) {
    const input = root.querySelector('.def-sw');
    if (!input) return;
    input.addEventListener('click', (e) => e.stopPropagation());
    input.addEventListener('change', () => {
      const next = input.checked;
      try {
        if (onToggle(next) === false) input.checked = !next;
      } catch (err) {
        input.checked = !next;
        toast(err.message || 'Could not update default', false);
      }
    });
  }

  function setDefaultAccount(account) {
    if (!account || account.isDefault) return true;
    if (!isAccountUsable(account)) {
      toast('This email is disabled. Ask an admin to enable it.', false);
      return false;
    }
    const prev = cloneStatus();
    const next = cloneStatus();
    const list = (next.accounts || []).map((a) => ({
      ...a,
      isDefault: String(a.id) === String(account.id)
    }));
    applyAccountList(next, list);
    commitStatus(next);
    toast('Default account: ' + account.email);
    send('EMAIL_SET_DEFAULT', { payload: { accountId: account.id } }).then((res) => {
      if (!res?.success) {
        commitStatus(prev);
        toast(res?.message || 'Could not set default account', false);
        return;
      }
      if (Array.isArray(res.data?.accounts)) {
        const merged = cloneStatus();
        applyAccountList(merged, res.data.accounts);
        commitStatus(merged);
      }
    });
    return true;
  }

  function deleteTemplateById(id, name) {
    const prev = cloneStatus();
    const next = cloneStatus();
    next.templates = (next.templates || []).filter((t) => String(t.id) !== String(id));
    commitStatus(next);
    toast('Template deleted', true, 'toast', name || '');
    send('EMAIL_DELETE_TEMPLATE', { id }).then((res) => {
      if (!res?.success) {
        commitStatus(prev);
        toast(res?.message || 'Delete failed', false);
      }
    });
  }

  function upsertTemplateLocal(tpl) {
    const next = cloneStatus();
    const list = Array.isArray(next.templates) ? next.templates.slice() : [];
    const idx = list.findIndex((t) => String(t.id) === String(tpl.id));
    if (idx >= 0) list[idx] = { ...list[idx], ...tpl };
    else list.unshift(tpl);
    next.templates = sortTemplates(list);
    commitStatus(next);
  }

  function setTplAiStatus(text, isErr) {
    const el = $('tpl-ai-status');
    if (!el) return;
    const msg = String(text || '').trim();
    el.textContent = msg;
    el.classList.toggle('is-err', Boolean(isErr));
    el.classList.toggle('is-ok', Boolean(msg) && !isErr && /filled/i.test(msg));
    show(el, Boolean(msg));
  }

  function setTplAiBusy(busy) {
    const wrap = $('tpl-ai');
    const btn = $('btn-tpl-ai');
    const input = $('tpl-ai-prompt');
    wrap?.classList.toggle('is-busy', busy);
    wrap?.setAttribute('aria-busy', busy ? 'true' : 'false');
    if (input) input.disabled = busy;
    wrap?.querySelectorAll('.ai-suggest button').forEach((chip) => {
      chip.disabled = busy;
    });
    if (!btn) return;
    btn.disabled = busy;
    btn.setAttribute('aria-label', busy ? 'Writing draft' : 'Write draft with AI');
    btn.innerHTML = busy
      ? '<span class="ai-spin" aria-hidden="true"></span>'
      : 'Write';
  }

  let tplAiSeq = 0;

  async function generateTplWithAi() {
    const prompt = ($('tpl-ai-prompt')?.value || '').trim();
    const payload = {
      prompt,
      name: ($('tpl-name')?.value || '').trim(),
      subject: ($('tpl-subject')?.value || '').trim(),
      body: $('tpl-body')?.value || '',
      mode: ($('tpl-id')?.value || '').trim() ? 'edit' : 'create'
    };
    if (!payload.prompt && !payload.subject && !String(payload.body).trim()) {
      setTplAiStatus('Describe the email, or pick a suggestion.', true);
      return;
    }
    const seq = ++tplAiSeq;
    setTplAiBusy(true);
    setTplAiStatus('Writing…');
    try {
      const res = await send('EMAIL_AI_TEMPLATE', { payload });
      if (seq !== tplAiSeq) return;
      if (!res?.success) throw new Error(res?.message || 'Could not write that template');
      const draft = res.data?.template;
      if (!draft?.subject || !draft?.body) throw new Error('AI returned an empty draft');
      if (draft.name && $('tpl-name')) $('tpl-name').value = draft.name;
      if ($('tpl-subject')) $('tpl-subject').value = draft.subject;
      if ($('tpl-body')) $('tpl-body').value = draft.body;
      setTplAiStatus('Draft filled — review and save.');
      toast('AI draft ready — review before saving');
    } catch (err) {
      if (seq !== tplAiSeq) return;
      setTplAiStatus(err.message || 'Could not write that template', true);
      toast(err.message || 'Could not write that template', false);
    } finally {
      if (seq === tplAiSeq) setTplAiBusy(false);
    }
  }

  function openEditTemplate(tpl) {
    openTplForm({ reset: false });
    $('tpl-id').value = tpl.id || '';
    $('tpl-name').value = tpl.name || '';
    $('tpl-subject').value = tpl.subject || '';
    $('tpl-body').value = tpl.body || '';
    if ($('tpl-editor-title')) $('tpl-editor-title').textContent = 'Edit template';
    show($('btn-delete-tpl'), true);
    if ($('tpl-ai-prompt')) $('tpl-ai-prompt').value = '';
    setTplAiStatus('');
  }

  function renderAccountsSidebar() {
    const list = accounts();
    const wrap = $('accounts-list');
    const empty = $('accounts-empty');
    if (!wrap) return;
    wrap.innerHTML = '';
    show(empty, !list.length);
    show($('accounts-bar'), list.length > 0);
    show($('accounts-hint'), list.length > 0);
    list.forEach((a) => {
      const el = document.createElement('div');
      el.className =
        'list-card' +
        (a.isDefault ? ' is-default' : '') +
        (isAccountUsable(a) ? '' : ' is-over-limit');
      el.innerHTML =
        '<div class="body"><div class="title"></div><div class="sub"></div></div>' +
        '<div class="actions">' +
        defaultSwitchMarkup(!!a.isDefault, !isAccountUsable(a)) +
        '</div>';
      el.querySelector('.title').textContent = a.email;
      el.querySelector('.sub').textContent = isAccountUsable(a)
        ? methodLabel(a) + (a.isDefault ? ' · Used to send' : '')
        : methodLabel(a) + ' · Disabled · ask admin to enable';
      bindDefaultSwitch(el, (next) => {
        if (!isAccountUsable(a)) {
          toast('This email is disabled. Ask an admin to enable it.', false);
          return false;
        }
        if (!next) {
          if (a.isDefault) {
            toast('Turn on another account to change the default', false);
          }
          return false;
        }
        return setDefaultAccount(a);
      });
      wrap.appendChild(el);
    });
  }

  function renderTemplates() {
    const list = $('tpl-list');
    const empty = $('tpl-empty');
    if (!list) return;
    const templates = state.status?.templates || [];
    list.innerHTML = '';
    show(empty, !templates.length);
    const label = $('tpl-section-label');
    if (label) {
      const lim = emailLimits();
      label.textContent = templates.length
        ? lim.maxTemplates
          ? 'Templates · ' + templates.length + ' / ' + lim.maxTemplates
          : 'Templates · ' + templates.length
        : 'Templates';
    }
    const tplHint = $('tpl-hint');
    if (tplHint) {
      tplHint.textContent = atTemplateLimit()
        ? templateLimitMessage()
        : 'Create templates, then pick one from the email icon on a load row.';
    }
    show($('btn-new-tpl'), !atTemplateLimit());
    show($('btn-new-tpl-empty'), !atTemplateLimit());
    templates.forEach((t) => {
      const el = document.createElement('div');
      el.className = 'list-card';
      el.innerHTML =
        '<div class="body"><div class="title"></div><div class="sub"></div></div>' +
        '<div class="actions">' +
        '<button class="icon-btn edit" type="button" aria-label="Edit template">' +
        ICO_EDIT +
        '</button>' +
        '<button class="icon-btn del" type="button" aria-label="Delete template">' +
        ICO_TRASH +
        '</button></div>';
      el.querySelector('.title').textContent = t.name;
      el.querySelector('.sub').textContent = t.subject || '';
      el.querySelector('.edit').addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        openEditTemplate(t);
      });
      el.querySelector('.del').addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!confirm('Delete this template?')) return;
        deleteTemplateById(t.id, t.name);
      });
      list.appendChild(el);
    });
  }

  function render() {
    const signedIn = Boolean(state.session?.signedIn) && !state.forceSignedOut;
    const list = signedIn ? accounts() : [];
    const connected = list.some(isAccountUsable);

    show($('auth-signed-out'), !signedIn);
    show($('auth-card'), !signedIn);
    show($('accounts-card'), signedIn);
    show($('btn-add-account'), signedIn && list.length > 0 && !atAccountLimit());
    const accHint = $('accounts-hint');
    if (accHint) {
      const lim = emailLimits();
      accHint.innerHTML = atAccountLimit()
        ? accountLimitMessage()
        : lim.maxAccounts
          ? 'Turn on <strong>Use default</strong> among enabled emails. Extra inboxes stay off until an admin enables them. ' +
            lim.accountsUsed +
            ' of ' +
            lim.maxAccounts +
            ' emails connected.'
          : 'Turn on <strong>Use default</strong> for the account used when sending from a load row.';
    }

    if (!signedIn) {
      state.accountView = 'list';
      state.status = null;
    }

    // Always offer Google connect in the UI (API will error clearly if not configured).
    setConnectForm(state.connectForm || 'gmail');
    renderAccountsSidebar();
    renderTemplates();
    updateChrome();
    syncToolbarButtonLabel();

    if (state.popupOpen && signedIn && connected) {
      fillFromSelect();
      const curTpl = $('popup-template')?.value;
      fillTemplateSelect($('popup-template'));
      if (curTpl && curTpl !== ADD_TEMPLATE) $('popup-template').value = curTpl;
      updatePreview();
    }
  }

  let loadAllInflight = null;

  async function hydrateFromStorage() {
    try {
      const stored = await chrome.storage.local.get([
        'emailStatusCache',
        'token',
        'apiBase',
        'userEmail',
        'loggedOut',
        'source'
      ]);
      if (stored.loggedOut || state.forceSignedOut) {
        state.session = {
          signedIn: false,
          apiBase: String(stored.apiBase || ''),
          source: 'none',
          userEmail: null
        };
        return;
      }
      if (stored.token) {
        state.session = {
          signedIn: true,
          apiBase: String(stored.apiBase || ''),
          source: stored.source || 'manual',
          userEmail: stored.userEmail || null
        };
      }
      const cache = stored.emailStatusCache;
      if (cache?.data && (!cache.at || Date.now() - Number(cache.at) < 10 * 60 * 1000)) {
        state.status = cache.data;
        state.statusLoaded = true;
        statusWriteAt = Number(cache.at) || Date.now();
      }
    } catch {
      // ignore
    }
  }

  async function refreshFromNetwork(force) {
    const started = Date.now();
    const sessionRes = await send('GET_SESSION');
    if (!force && started < statusWriteAt) return;
    state.session = sessionRes?.success
      ? sessionRes.data
      : { signedIn: false, apiBase: '' };

    if (!state.session.signedIn) {
      state.status = null;
      state.statusLoaded = true;
      render();
      return;
    }

    const statusRes = await send('EMAIL_STATUS', force ? { force: true } : {});
    if (!force && started < statusWriteAt) return;
    if (!statusRes?.success) {
      if (!state.status) {
        const errMsg =
          statusRes?.code === 'SESSION_REPLACED'
            ? 'Your Dat Desk session changed. Close DAT and click Open DAT again.'
            : statusRes?.code === 'INVALID_TOKEN' || statusRes?.code === 'AUTH_FAILED'
              ? 'Your session expired. Sign in to Dat Desk again, then click Open DAT.'
              : formatUserError(
                  statusRes?.message,
                  'Could not load email settings. Sign in to Dat Desk and click Open DAT again.'
                );
        toast(errMsg, false);
        state.status = null;
      }
      state.statusLoaded = true;
      render();
      return;
    }
    if (!force && started < statusWriteAt) return;
    state.status = statusRes.data;
    state.statusLoaded = true;
    statusWriteAt = Date.now();
    render();
  }

  async function loadAll(opts = {}) {
    const force = Boolean(opts && opts.force);
    if (state.forceSignedOut) {
      state.session = { signedIn: false, apiBase: '', source: 'none', userEmail: null };
      state.status = null;
      state.statusLoaded = true;
      render();
      return;
    }

    if (!force && state.statusLoaded && state.session) {
      render();
      if (!loadAllInflight) {
        loadAllInflight = refreshFromNetwork(false).finally(() => {
          loadAllInflight = null;
        });
      }
      return;
    }

    if (loadAllInflight && !force) return loadAllInflight;

    loadAllInflight = (async () => {
      if (!state.statusLoaded) {
        await hydrateFromStorage();
        if (state.session || state.status) render();
      }
      await refreshFromNetwork(force);
    })().finally(() => {
      loadAllInflight = null;
    });
    return loadAllInflight;
  }

  function resetTplForm() {
    $('tpl-id').value = '';
    $('tpl-name').value = '';
    $('tpl-subject').value = '';
    $('tpl-body').value = '';
    if ($('tpl-ai-prompt')) $('tpl-ai-prompt').value = '';
    setTplAiStatus('');
    $('tpl-editor-title').textContent = 'New template';
    show($('btn-delete-tpl'), false);
    setTplPreviewOpen(false);
  }

  const SMTP_UI_PRESETS = {
    gmail: { host: 'smtp.gmail.com', port: 587, secure: false },
    outlook: { host: 'smtp.office365.com', port: 587, secure: false },
    yahoo: { host: 'smtp.mail.yahoo.com', port: 465, secure: true }
  };

  const SMTP_DOMAIN_PRESETS = {
    'gmail.com': SMTP_UI_PRESETS.gmail,
    'googlemail.com': SMTP_UI_PRESETS.gmail,
    'outlook.com': SMTP_UI_PRESETS.outlook,
    'hotmail.com': SMTP_UI_PRESETS.outlook,
    'live.com': SMTP_UI_PRESETS.outlook,
    'msn.com': SMTP_UI_PRESETS.outlook,
    'yahoo.com': SMTP_UI_PRESETS.yahoo,
    'ymail.com': SMTP_UI_PRESETS.yahoo
  };

  function applySmtpFields(preset) {
    if (!preset) return;
    if ($('smtp-host')) $('smtp-host').value = preset.host;
    if ($('smtp-port')) $('smtp-port').value = String(preset.port);
    if ($('smtp-secure')) $('smtp-secure').checked = !!preset.secure;
  }

  function autofillSmtpFromEmail(email) {
    const domain = String(email || '')
      .split('@')[1]
      ?.toLowerCase()
      .trim();
    if (!domain) return;
    applySmtpFields(SMTP_DOMAIN_PRESETS[domain]);
  }

  function syncSmtpSecureFromPort() {
    const port = Number($('smtp-port')?.value) || 0;
    if (!$('smtp-secure')) return;
    if (port === 465) $('smtp-secure').checked = true;
    else if (port === 587 || port === 2525 || port === 25) $('smtp-secure').checked = false;
  }

  async function connectSmtpManual() {
    const btn = $('btn-connect-smtp');
    syncSmtpSecureFromPort();
    let email = $('smtp-email').value.trim();
    const user = ($('smtp-user')?.value || '').trim();
    if (!email && user) email = user;
    const payload = {
      email,
      password: ($('smtp-pass').value || '').replace(/\s+/g, ''),
      displayName: ($('smtp-name')?.value || '').trim(),
      smtpHost: $('smtp-host').value.trim(),
      smtpPort: Number($('smtp-port').value) || 587,
      smtpSecure: !!$('smtp-secure')?.checked,
      smtpUser: user || email
    };
    if (!payload.email || !payload.password) {
      return toast('Email and password are required', false);
    }
    if (!payload.smtpHost) {
      autofillSmtpFromEmail(payload.email);
      payload.smtpHost = $('smtp-host').value.trim();
      payload.smtpPort = Number($('smtp-port').value) || payload.smtpPort;
      payload.smtpSecure = !!$('smtp-secure')?.checked;
    }
    if (!payload.smtpHost) {
      return toast('SMTP host is required (or use a Gmail/Outlook/Yahoo address)', false);
    }
    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Connecting…';
    }
    startSmtpProgress();
    console.log('[Signal SMTP] connect', {
      email: payload.email,
      smtpUser: payload.smtpUser,
      smtpHost: payload.smtpHost,
      smtpPort: payload.smtpPort,
      smtpSecure: payload.smtpSecure,
      passLen: payload.password.length
    });
    try {
      const res = await send('EMAIL_CONNECT_SMTP', { payload });
      console.log('[Signal SMTP] result', {
        success: res?.success,
        code: res?.code,
        message: res?.message
      });
      if (!res?.success) throw new Error(res?.message || 'Connect failed');
      setSmtpProgress(true, 'Email connected');
      toast('Email connected', true, 'toast', payload.email);
      $('smtp-pass').value = '';
      state.connectMode = null;
      state.accountView = 'list';
      await loadAll({ force: true });
    } catch (err) {
      toast(err.message || 'Connect failed', false);
    } finally {
      stopSmtpProgress();
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Connect SMTP';
      }
    }
  }

  // —— Events ——
  startToolbarMount();
  paintPasswordToggles();
  $('panel-backdrop').addEventListener('click', () => setSidebarOpen(false));
  $('panel-close').addEventListener('click', () => setSidebarOpen(false));
  $('panel-close-sub')?.addEventListener('click', () => setSidebarOpen(false));
  $('btn-back')?.addEventListener('click', goBack);
  $('btn-refresh-accounts')?.addEventListener('click', () => loadAll({ force: true }));
  shadow.querySelectorAll('.tab').forEach((btn) => {
    btn.addEventListener('click', () => setTab(btn.dataset.tab));
  });
  shadow.addEventListener('click', (e) => {
    const pwBtn = e.target && e.target.closest && e.target.closest('[data-pw-toggle]');
    if (pwBtn && shadow.contains(pwBtn)) {
      e.preventDefault();
      togglePasswordVisibility(pwBtn);
      return;
    }
    const btn = e.target && e.target.closest && e.target.closest('[data-toast-dismiss]');
    if (!btn || !shadow.contains(btn)) return;
    e.preventDefault();
    e.stopPropagation();
    const id = btn.getAttribute('data-toast-dismiss');
    $(id)?.classList.remove('show');
  });

  $('popup-close').addEventListener('click', closeComposePopup);
  $('popup-backdrop').addEventListener('click', (e) => {
    if (e.target === $('popup-backdrop')) closeComposePopup();
  });
  $('popup-save-tpl')?.addEventListener('click', async () => {
    const nameRaw = ($('popup-template')?.selectedOptions?.[0]?.textContent || '').replace(
      /\s*\(default\)\s*$/i,
      ''
    );
    const name =
      nameRaw &&
      nameRaw !== '— No template / custom —' &&
      nameRaw !== '+ Add new template' &&
      !nameRaw.startsWith('─')
        ? nameRaw
        : 'Saved from compose';
    const payload = {
      name: name.trim(),
      subject: ($('popup-subject')?.value || '').trim(),
      body: $('popup-body')?.value || '',
      isDefault: false
    };
    if (!payload.subject || !payload.body.trim()) {
      return toast('Subject and body are required', false, 'popup-toast');
    }
    if (atTemplateLimit()) return toast(templateLimitMessage(), false, 'popup-toast');
    const res = await send('EMAIL_CREATE_TEMPLATE', { payload });
    if (!res?.success) return toast(res?.message || 'Save failed', false, 'popup-toast');
    const saved = res.data?.template;
    if (saved) upsertTemplateLocal(saved);
    toast('Template saved', true, 'popup-toast', payload.name);
    fillTemplateSelect($('popup-template'));
    if (saved?.id) $('popup-template').value = saved.id;
  });

  let oauthWaitSeq = 0;

  function setOAuthWaiting(on) {
    state.oauthWaiting = Boolean(on);
    setConnectForm(state.connectForm || 'gmail');
    updateChrome();
  }

  function findNewOAuthAccount(previous) {
    const prev = new Set((previous || []).map((a) => String(a.email || '').toLowerCase()));
    const prevTimes = new Map(
      (previous || []).map((a) => [
        String(a.email || '').toLowerCase(),
        Date.parse(a.connectedAt || 0) || 0
      ])
    );
    return accounts().find((a) => {
      const email = String(a.email || '').toLowerCase();
      if (!prev.has(email)) return true;
      const t = Date.parse(a.connectedAt || 0) || 0;
      return t > (prevTimes.get(email) || 0);
    }) || null;
  }

  async function waitForOAuthOutcome(previous, seq) {
    const deadline = Date.now() + 3 * 60 * 1000;
    while (state.oauthWaiting && seq === oauthWaitSeq && Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 1200));
      if (!state.oauthWaiting || seq !== oauthWaitSeq) return { found: null };
      const statusRes = await send('EMAIL_STATUS');
      if (statusRes?.success) state.status = statusRes.data;
      const found = findNewOAuthAccount(previous);
      if (found) return { found };
      const oauthRes = await send('EMAIL_OAUTH_RESULT');
      const st = oauthRes?.data?.status;
      if (st === 'error') {
        return { found: null, denied: true, message: oauthRes.data.message || '' };
      }
      if (st === 'ok') {
        const again = findNewOAuthAccount(previous);
        if (again) return { found: again };
      }
    }
    return { found: null, timedOut: true };
  }

  let oauthLaunchLock = false;

  async function startGoogleOAuth() {
    if (state.oauthWaiting || oauthLaunchLock) return;
    oauthLaunchLock = true;
    try {
      if (!state.session?.signedIn) {
        setTab('account');
        return toast('Sign in first, then connect Gmail', false);
      }
      const res = await send('EMAIL_OAUTH_URL');
      if (!res?.success) {
        return toast(
          res?.message ||
            'Google sign-in is not available right now. You can connect with an app password instead.',
          false
        );
      }
      const url = res.data?.url;
      if (!url) {
        return toast('Could not start Google sign-in. Please try again.', false);
      }

      const previous = accounts().map((a) => ({ email: a.email, connectedAt: a.connectedAt }));
      const seq = ++oauthWaitSeq;
      setOAuthWaiting(true);
      toast('Finish Google sign-in', true, 'toast', 'Pick your account in the popup, then allow access');

      const opened = await send('OPEN_GOOGLE_OAUTH', { url });
      if (seq !== oauthWaitSeq) return;
      if (!opened?.success || opened.via !== 'host') {
        const w = 520;
        const h = 720;
        const left = Math.max(0, Math.round((window.screen.width - w) / 2));
        const top = Math.max(0, Math.round((window.screen.height - h) / 2));
        window.open(
          url,
          'dat-gmail-oauth',
          `popup=yes,width=${w},height=${h},left=${left},top=${top},resizable=yes,scrollbars=yes`
        );
      }

      const result = await waitForOAuthOutcome(previous, seq);
      if (seq !== oauthWaitSeq) return;

      if (result.found) {
        setOAuthWaiting(false);
        toast('Email connected', true, 'toast', result.found.email || 'Gmail is ready to send');
        state.connectMode = null;
        state.accountView = 'list';
        await loadAll({ force: true });
        return;
      }

      if (result.denied) {
        setOAuthWaiting(false);
        state.connectMode = null;
        state.accountView = 'list';
        updateChrome();
        await loadAll({ force: true });
        toast(
          'Google sign-in cancelled',
          false,
          'toast',
          result.message || 'Google denied the request'
        );
        return;
      }

      if (result.timedOut) {
        toast(
          'Still waiting on Google',
          false,
          'toast',
          'Finish sign-in in the Google window, or press Cancel'
        );
      }
    } finally {
      oauthLaunchLock = false;
    }
  }

  const openAddAccount = () => openAccountForm();
  $('btn-add-account')?.addEventListener('click', openAddAccount);
  $('btn-add-account-empty')?.addEventListener('click', openAddAccount);
  $('btn-connect-gmail-empty')?.addEventListener('click', () => startGoogleOAuth());
  $('choice-oauth')?.addEventListener('click', () => startGoogleOAuth());
  $('choice-smtp')?.addEventListener('click', () => {
    setConnectForm('smtp');
    updateChrome();
    $('smtp-email')?.focus();
  });
  $('oauth-wait-cancel')?.addEventListener('click', () => {
    oauthWaitSeq += 1;
    setOAuthWaiting(false);
    state.connectMode = null;
    state.accountView = 'list';
    updateChrome();
    toast('Google connect cancelled', false);
  });

  window.addEventListener('message', (ev) => {
    const data = ev?.data;
    if (!data || data.type !== 'DAT_EMAIL_OAUTH_DONE') return;
    oauthWaitSeq += 1;
    setOAuthWaiting(false);
    state.connectMode = null;
    state.accountView = 'list';
    updateChrome();
    if (data.ok) {
      toast('Email connected', true, 'toast', data.email || 'Gmail is ready to send');
      loadAll({ force: true });
    } else {
      toast("Couldn't connect that email", false, 'toast', data.message || 'Try again from the Account tab');
    }
  });

  window.addEventListener('storage', (ev) => {
    if (ev.key !== 'dat-email-oauth-result' || !ev.newValue) return;
    try {
      const data = JSON.parse(ev.newValue);
      if (data?.type !== 'DAT_EMAIL_OAUTH_DONE') return;
      oauthWaitSeq += 1;
      setOAuthWaiting(false);
      state.connectMode = null;
      state.accountView = 'list';
      if (data.ok) {
        toast('Email connected', true, 'toast', data.email || 'Gmail is ready to send');
        loadAll({ force: true });
      }
    } catch {
      // ignore
    }
  });

  $('btn-connect-smtp')?.addEventListener('click', () => connectSmtpManual());

  $('popup-template')?.addEventListener('change', () => {
    if ($('popup-template').value === ADD_TEMPLATE) {
      closeComposePopup();
      setSidebarOpen(true);
      openTplForm({ reset: true });
      return;
    }
    if ($('popup-template').value) applyTemplateToPopup($('popup-template').value);
    else updatePreview();
  });
  $('popup-from')?.addEventListener('change', () => {
    if ($('popup-from').value === ADD_ACCOUNT) {
      closeComposePopup();
      setSidebarOpen(true);
      openAccountForm();
      return;
    }
    updatePreview();
  });
  ['popup-to', 'popup-subject', 'popup-body'].forEach((id) => {
    $(id)?.addEventListener('input', updatePreview);
    $(id)?.addEventListener('change', updatePreview);
  });

  $('popup-send')?.addEventListener('click', async () => {
    const to = $('popup-to').value.trim();
    const subjectRaw = $('popup-subject').value.trim();
    const bodyRaw = $('popup-body').value;
    const templateVal = $('popup-template').value || '';
    const accountVal = $('popup-from').value || '';
    if (accountVal === ADD_ACCOUNT) {
      closeComposePopup();
      setSidebarOpen(true);
      openAccountForm();
      return;
    }
    if (templateVal === ADD_TEMPLATE) {
      closeComposePopup();
      setSidebarOpen(true);
      openTplForm({ reset: true });
      return;
    }
    const templateId = templateVal || undefined;
    const accountId = accountVal || undefined;
    if (!to) return toast('Recipient is required', false, 'popup-toast');
    if (!subjectRaw || !bodyRaw.trim()) {
      return toast('Subject and body are required', false, 'popup-toast');
    }
    if (!accountId) return toast('Select an account to send from', false, 'popup-toast');
    const fromAccount = accounts().find((a) => String(a.id) === String(accountId));
    if (!fromAccount || !isAccountUsable(fromAccount)) {
      return toast(
        accountLimitMessage(),
        false,
        'popup-toast'
      );
    }
    const vars = currentComposeVars();
    const subject = applyVars(subjectRaw, to);
    const body = applyVars(bodyRaw, to);
    const broker =
      (state.loadVars && (state.loadVars.broker || state.loadVars.company)) ||
      to.split('@')[0] ||
      to;
    const origin = state.loadVars?.origin || state.loadVars?.originCity || '';
    const dest = state.loadVars?.destination || state.loadVars?.dest || '';
    const ref = state.loadVars?.ref || state.loadVars?.reference || '';
    const routeBits = [origin && dest ? origin + ' → ' + dest : '', ref ? 'Ref ' + ref : '']
      .filter(Boolean)
      .join(' · ');
    $('popup-send').disabled = true;
    toast('Email sent to ' + broker, true, 'popup-toast', routeBits);
    setTimeout(closeComposePopup, 500);
    send('EMAIL_SEND', {
      payload: { to, subject, body, templateId, accountId, vars }
    }).then((res) => {
      if (!res?.success) {
        toast('Email failed to send', false, 'popup-toast', res?.message || 'Send failed');
      }
    }).finally(() => {
      const btn = $('popup-send');
      if (btn) btn.disabled = false;
    });
  });

  $('login-pass')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') $('btn-login')?.click();
  });
  $('login-email')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') $('login-pass')?.focus();
  });

  $('btn-login')?.addEventListener('click', async () => {
    const email = $('login-email').value.trim();
    const password = $('login-pass').value;
    if (!email || !password) {
      return toast('Email and password are required', false);
    }
    $('btn-login').disabled = true;
    try {
      const res = await send('LOGIN', {
        payload: {
          apiBase: state.session?.apiBase || '',
          email,
          password
        }
      });
      if (!res?.success) throw new Error(res?.message || 'Login failed');
      state.forceSignedOut = false;
      $('login-pass').value = '';
      toast('Signed in');
      await loadAll({ force: true });
    } catch (err) {
      toast(err.message || 'Login failed', false);
    } finally {
      $('btn-login').disabled = false;
    }
  });

  async function openHelpUrl(url) {
    const res = await send('OPEN_EXTERNAL', { url });
    if (!res?.success) {
      try {
        window.open(url, '_blank', 'noopener');
        return;
      } catch {
        toast('Could not open that page', false);
      }
    }
  }

  shadow.addEventListener('click', (e) => {
    const gmail = e.target && e.target.closest && e.target.closest('#smtp-help-gmail');
    const outlook = e.target && e.target.closest && e.target.closest('#smtp-help-outlook');
    if (!gmail && !outlook) return;
    e.preventDefault();
    e.stopPropagation();
    openHelpUrl(
      gmail
        ? 'https://myaccount.google.com/apppasswords'
        : 'https://account.microsoft.com/security'
    );
  });

  $('smtp-email')?.addEventListener('blur', () => {
    autofillSmtpFromEmail($('smtp-email').value);
    if ($('smtp-user') && !$('smtp-user').value.trim()) {
      $('smtp-user').value = $('smtp-email').value.trim();
    }
  });
  $('smtp-port')?.addEventListener('change', syncSmtpSecureFromPort);
  $('smtp-secure')?.addEventListener('change', () => {
    if ($('smtp-secure').checked) $('smtp-port').value = '465';
    else if (Number($('smtp-port').value) === 465) $('smtp-port').value = '587';
  });

  $('btn-new-tpl')?.addEventListener('click', () => openTplForm({ reset: true }));
  $('btn-new-tpl-empty')?.addEventListener('click', () => openTplForm({ reset: true }));
  $('btn-tpl-ai')?.addEventListener('click', () => generateTplWithAi());
  $('tpl-ai-prompt')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      generateTplWithAi();
    }
  });
  $('tpl-ai-suggest')?.addEventListener('click', (e) => {
    const chip = e.target.closest('[data-ai-suggest]');
    if (!chip || chip.disabled) return;
    const input = $('tpl-ai-prompt');
    if (input) input.value = chip.getAttribute('data-ai-suggest') || '';
    generateTplWithAi();
  });
  $('btn-tpl-preview')?.addEventListener('click', () => setTplPreviewOpen(true));
  $('btn-tpl-preview-back')?.addEventListener('click', () => setTplPreviewOpen(false));
  $('btn-reset-tpl')?.addEventListener('click', resetTplForm);
  $('btn-delete-tpl')?.addEventListener('click', () => {
    const id = $('tpl-id').value;
    if (!id) return;
    if (!confirm('Delete this template?')) return;
    const name = $('tpl-name').value.trim();
    closeTplForm();
    deleteTemplateById(id, name);
  });
  $('btn-save-tpl')?.addEventListener('click', () => {
    const payload = {
      name: $('tpl-name').value.trim(),
      subject: $('tpl-subject').value.trim(),
      body: $('tpl-body').value
    };
    if (!payload.name || !payload.subject || !payload.body.trim()) {
      return toast('Name, subject, and body are required', false);
    }
    const id = $('tpl-id').value;
    if (!id && atTemplateLimit()) return toast(templateLimitMessage(), false);
    const prev = cloneStatus();
    const localTpl = {
      id: id || '__tmp_' + Date.now(),
      name: payload.name,
      subject: payload.subject,
      body: payload.body
    };
    upsertTemplateLocal(localTpl);
    closeTplForm();
    toast(id ? 'Template updated' : 'Template created');
    const req = id
      ? send('EMAIL_UPDATE_TEMPLATE', { id, payload })
      : send('EMAIL_CREATE_TEMPLATE', { payload });
    req.then((res) => {
      if (!res?.success) {
        commitStatus(prev);
        toast(res?.message || 'Save failed', false);
        return;
      }
      const saved = res.data?.template;
      if (saved) {
        if (!id) {
          const merged = cloneStatus();
          merged.templates = sortTemplates(
            (merged.templates || [])
              .filter((t) => t.id !== localTpl.id)
              .concat([saved])
          );
          commitStatus(merged);
        } else {
          upsertTemplateLocal(saved);
        }
      }
    });
  });

  window.__datEmailOpen = function (email, loadVars) {
    openComposePopup(email || '', loadVars || null);
  };
  function rowSendContext() {
    const signedIn = Boolean(state.session?.signedIn) && !state.forceSignedOut;
    const list = signedIn ? accounts() : [];
    const templates = signedIn
      ? (state.status?.templates || []).map((t) => ({
          id: t.id,
          name: t.name
        }))
      : [];
    templates.sort((a, b) =>
      String(a.name || '').localeCompare(String(b.name || ''), undefined, { sensitivity: 'base' })
    );
    return {
      signedIn,
      hasInbox: usableAccounts().length > 0,
      hasDefaultInbox: Boolean(list.find((a) => a.isDefault && isAccountUsable(a))),
      templates,
      loading: !state.statusLoaded
    };
  }
  window.__datEmailGetRowSendContextSync = function () {
    return rowSendContext();
  };
  window.__datEmailGetRowSendContext = async function () {
    if (!state.statusLoaded) await loadAll();
    else loadAll();
    return rowSendContext();
  };
  window.__datEmailQuickSend = function (email, loadVars, templateId) {
    return quickSendFromRow(email || '', loadVars || null, templateId || '');
  };
  window.__datEmailToggle = function () {
    const opening = !state.sidebarOpen;
    setSidebarOpen(opening, opening ? defaultSidebarTab() : undefined);
  };
  window.addEventListener('dat-email-open', (ev) => {
    openComposePopup(ev?.detail?.email || '', ev?.detail?.load || null);
  });
  window.addEventListener('dat-email-quick-send', (ev) => {
    quickSendFromRow(ev?.detail?.email || '', ev?.detail?.load || null, ev?.detail?.templateId || '');
  });

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === 'DAT_EMAIL_OPEN') {
      if (message.recipient || message.load) {
        openComposePopup(message.recipient || '', message.load || null);
      } else {
        setSidebarOpen(true, defaultSidebarTab());
      }
      sendResponse({ success: true, open: true });
      return true;
    }
    if (message?.type === 'DAT_EMAIL_TOGGLE') {
      const opening = !state.sidebarOpen;
      setSidebarOpen(opening, opening ? defaultSidebarTab() : undefined);
      sendResponse({ success: true, open: state.sidebarOpen });
      return true;
    }
    if (message?.type === 'DAT_EMAIL_PING_UI') {
      sendResponse({ success: true, mounted: true });
      return true;
    }
    return false;
  });

  setConnectForm('gmail');
  setTab('account');
  setupTemplateVarChips();

  hydrateFromStorage().then(() => {
    if (state.session || state.status) render();
    loadAll();
  });
})();


