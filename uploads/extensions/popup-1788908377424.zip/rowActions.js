'use strict';

/**
 * DAT One load-board row email/copy icons (CargoSignal-style selectors).
 * Runs as a content script in normal Chrome — not Electron.
 */
(function () {
  if (window.__fdExtRowActions === 1) return;
  window.__fdExtRowActions = 1;

  const COPY_ICON =
    '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2" stroke="currentColor" stroke-width="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" stroke="currentColor" stroke-width="2"/></svg>';
  const CHECK_ICON =
    '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 13l4 4L19 7" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  const MAIL_ICON =
    '<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M3 6.75A1.75 1.75 0 0 1 4.75 5h14.5A1.75 1.75 0 0 1 21 6.75v10.5A1.75 1.75 0 0 1 19.25 19H4.75A1.75 1.75 0 0 1 3 17.25V6.75zm1.8.55 6.55 4.7a1 1 0 0 0 1.2 0l6.55-4.7-.9-1.26-6.25 4.48L5.7 6.04l-.9 1.26z"/></svg>';

  const ROW_SEL = '.row-container, [id^="table-row-"]';
  // Keep contact selectors tight — broad [class*="contact"] breaks expand/collapse scans.
  const CONTACTS_SEL = '.contacts__email, .contacts, .contact-state';
  const MAILTO_SEL = "a[href^='mailto:'], a[href*='mailto:']";
  const TEL_SEL = "a[href^='tel:'], a[href*='tel:']";
  const DETAIL_SEL = '.table-row-detail';
  const ROW_ATTR = 'data-fd-row-actions';
  const WATCH_ATTR = 'data-fd-contact-watch';
  const HOST_CLASS = 'fd-actions-host';
  const STYLE_ID = 'fd-ext-row-actions-css';
  const ROW_HOST_ATTR = 'data-fd-host-for';
  const POP_ID = 'fd-tpl-pop';

  function ensureStyles() {
    let style = document.getElementById(STYLE_ID);
    if (!style) {
      style = document.createElement('style');
      style.id = STYLE_ID;
      (document.head || document.documentElement).appendChild(style);
    }
    const css = `
      .${HOST_CLASS} {
        display: inline-flex !important;
        align-items: center !important;
        gap: 4px !important;
        margin-left: 6px !important;
        vertical-align: middle !important;
        position: relative !important;
        z-index: 5 !important;
        pointer-events: auto !important;
      }
      .fd-copy-btn, .fd-email-btn {
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        width: 24px !important;
        height: 24px !important;
        min-width: 24px !important;
        min-height: 24px !important;
        padding: 0 !important;
        margin: 0 !important;
        border-radius: 5px !important;
        cursor: pointer !important;
        flex-shrink: 0 !important;
        box-shadow: none !important;
        opacity: 1 !important;
        visibility: visible !important;
        pointer-events: auto !important;
        z-index: 6 !important;
      }
      .fd-copy-btn {
        border: 1.5px solid #1565C0 !important;
        background: transparent !important;
        color: #1565C0 !important;
      }
      .fd-email-btn {
        border: none !important;
        background: #1565C0 !important;
        color: #fff !important;
      }
      .fd-copy-btn:hover { background: rgba(21, 101, 192, 0.12) !important; }
      .fd-email-btn:hover { background: #0D47A1 !important; }
      .fd-email-btn:disabled,
      .fd-email-btn.fd-sending {
        opacity: 0.7 !important;
        cursor: wait !important;
      }
      .fd-copy-btn.fd-copied {
        border-color: #1565C0 !important;
        color: #1565C0 !important;
        background: rgba(21, 101, 192, 0.12) !important;
      }
      .fd-email-btn.fd-sent {
        background: #10b981 !important;
      }
      .fd-copy-btn svg, .fd-email-btn svg {
        display: block !important;
        width: 12px !important;
        height: 12px !important;
        pointer-events: none !important;
      }
      .fd-email-btn.fd-open {
        background: #0D47A1 !important;
      }
      .fd-tpl-pop {
        position: fixed !important;
        z-index: 2147483000 !important;
        display: flex !important;
        flex-direction: column !important;
        min-width: 220px !important;
        width: 260px !important;
        max-width: min(280px, calc(100vw - 16px)) !important;
        max-height: min(360px, 70vh) !important;
        overflow: hidden !important;
        background: #ffffff !important;
        border: 0 !important;
        border-radius: 12px !important;
        box-shadow: 0 12px 30px rgba(13, 71, 161, 0.16) !important;
        padding: 10px 12px 8px !important;
        font-family: "Segoe UI", system-ui, sans-serif !important;
        color: #0B1220 !important;
        pointer-events: auto !important;
      }
      .fd-tpl-pop-title {
        font-size: 10px !important;
        font-weight: 700 !important;
        letter-spacing: 0.18em !important;
        text-transform: uppercase !important;
        color: #5B6B7C !important;
        padding: 2px 0 8px !important;
        line-height: 1.3 !important;
        flex: 0 0 auto !important;
      }
      .fd-tpl-pop-search {
        display: block !important;
        width: 100% !important;
        height: 32px !important;
        margin: 0 0 8px !important;
        padding: 0 0 6px !important;
        border: 0 !important;
        border-bottom: 1.5px solid #1565C0 !important;
        border-radius: 0 !important;
        background: transparent !important;
        color: #0B1220 !important;
        font-family: inherit !important;
        font-size: 12px !important;
        outline: none !important;
        box-sizing: border-box !important;
        flex: 0 0 auto !important;
      }
      .fd-tpl-pop-search:focus {
        border-color: #0D47A1 !important;
        background: transparent !important;
        box-shadow: 0 1px 0 #0D47A1 !important;
      }
      .fd-tpl-pop-list {
        overflow: auto !important;
        min-height: 0 !important;
        max-height: 240px !important;
        flex: 1 1 auto !important;
        scrollbar-width: thin !important;
        padding-right: 2px !important;
      }
      .fd-tpl-pop-item {
        display: block !important;
        width: 100% !important;
        text-align: left !important;
        border: 0 !important;
        border-bottom: 1px solid #D7E0EA !important;
        background: transparent !important;
        border-radius: 0 !important;
        padding: 10px 0 !important;
        margin: 0 !important;
        font-family: inherit !important;
        font-size: 12px !important;
        font-weight: 600 !important;
        line-height: 1.3 !important;
        color: #0B1220 !important;
        cursor: pointer !important;
        box-shadow: none !important;
      }
      .fd-tpl-pop-item:hover,
      .fd-tpl-pop-item:focus {
        background: transparent !important;
        color: #1565C0 !important;
        outline: none !important;
      }
      .fd-tpl-pop-empty {
        padding: 10px 0 !important;
        font-size: 12px !important;
        color: #5B6B7C !important;
        text-align: left !important;
      }
      .fd-tpl-pop-loading {
        display: flex !important;
        align-items: center !important;
        justify-content: flex-start !important;
        gap: 8px !important;
        padding: 14px 0 !important;
        font-size: 12px !important;
        color: #5B6B7C !important;
      }
      .fd-tpl-pop-spin {
        width: 14px !important;
        height: 14px !important;
        border: 2px solid #D7E0EA !important;
        border-top-color: #1565C0 !important;
        border-radius: 50% !important;
        animation: fd-tpl-spin 0.55s linear infinite !important;
        flex: 0 0 auto !important;
      }
      @keyframes fd-tpl-spin {
        to { transform: rotate(360deg); }
      }
      .fd-tpl-pop-arrow {
        position: absolute !important;
        width: 10px !important;
        height: 10px !important;
        background: #ffffff !important;
        border: 0 !important;
        pointer-events: none !important;
      }
      .fd-row-mail { display: none !important; }

      .row-container[${ROW_ATTR}], [id^="table-row-"][${ROW_ATTR}] {
        position: relative !important;
      }

      /* Hide DAT One native Connected Email compose / connect CTAs */
      connected-email-compose-email-button,
      connected-email-send-icon-button,
      connected-email-connect-cta,
      connected-email-connect-button,
      [data-test="connected-email-compose-button"],
      [data-test="connected-email-connect-cta"],
      .cell-email connected-email-compose-email-button,
      .table-cell.cell-email > connected-email-compose-email-button,
      .cell-email connected-email-connect-cta,
      .table-cell.cell-email > connected-email-connect-cta {
        display: none !important;
        visibility: hidden !important;
        pointer-events: none !important;
        width: 0 !important;
        max-width: 0 !important;
        height: 0 !important;
        max-height: 0 !important;
        margin: 0 !important;
        padding: 0 !important;
        overflow: hidden !important;
        opacity: 0 !important;
        position: absolute !important;
        left: -9999px !important;
      }
    `;
    if (style.textContent !== css) style.textContent = css;
  }

  function suppressDatNativeEmailButtons(root) {
    const scope = root && root.querySelectorAll ? root : document;
    const nodes = scope.querySelectorAll(
      'connected-email-compose-email-button, connected-email-connect-cta, connected-email-connect-button, [data-test="connected-email-compose-button"], [data-test="connected-email-connect-cta"]'
    );
    nodes.forEach((el) => {
      if (el.getAttribute('data-fd-hidden') === '1') return;
      el.setAttribute('data-fd-hidden', '1');
      el.setAttribute('hidden', '');
      el.style.setProperty('display', 'none', 'important');
      el.style.setProperty('visibility', 'hidden', 'important');
      el.style.setProperty('pointer-events', 'none', 'important');
      el.setAttribute('aria-hidden', 'true');
    });
  }

  function copyText(text) {
    const value = String(text || '').trim();
    if (!value) return Promise.resolve(false);
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(value).then(() => true).catch(() => fallback(value));
    }
    return Promise.resolve(fallback(value));
    function fallback(v) {
      try {
        const ta = document.createElement('textarea');
        ta.value = v;
        ta.setAttribute('readonly', '');
        ta.style.cssText = 'position:fixed;left:-9999px';
        document.body.appendChild(ta);
        ta.select();
        const ok = document.execCommand('copy');
        ta.remove();
        return ok;
      } catch {
        return false;
      }
    }
  }

  function flashCopied(btn) {
    const prev = btn.innerHTML;
    btn.classList.add('fd-copied');
    btn.innerHTML = CHECK_ICON;
    setTimeout(() => {
      btn.classList.remove('fd-copied');
      btn.innerHTML = prev;
    }, 1200);
  }

  function sendQuickEmail(email, loadVars, templateId) {
    const value = String(email || '').trim();
    if (!value && !(loadVars && loadVars.email)) return Promise.resolve({ success: false });
    const recipient = value || String(loadVars.email || '').trim();
    try {
      if (typeof window.__datEmailQuickSend === 'function') {
        return Promise.resolve(window.__datEmailQuickSend(recipient, loadVars || null, templateId || ''));
      }
    } catch {
      // ignore
    }
    window.dispatchEvent(
      new CustomEvent('dat-email-quick-send', {
        detail: { email: recipient, load: loadVars || null, templateId: templateId || '' }
      })
    );
    return Promise.resolve({ success: false });
  }

  function normalizeEmail(href) {
    return decodeURIComponent(String(href || '').replace(/^mailto:/i, '').split('?')[0]).trim();
  }

  function normalizePhone(href) {
    return String(href || '').replace(/^tel:/i, '').trim();
  }

  function isOurNode(node) {
    if (!node || node.nodeType !== 1) return false;
    if (node.id === STYLE_ID || node.id === POP_ID || node.id === 'dat-email-host') return true;
    const cls = typeof node.className === 'string' ? node.className : '';
    if (cls.includes('fd-') || node.hasAttribute(ROW_ATTR) || node.hasAttribute(WATCH_ATTR)) return true;
    return Boolean(
      node.closest &&
        node.closest('.fd-copy-btn, .fd-email-btn, .fd-row-mail, .fd-tpl-pop, .' + HOST_CLASS + ', #dat-email-host')
    );
  }

  function findDetailScopes(row) {
    const scopes = [row];
    const next = row.nextElementSibling;
    if (next && next.matches && next.matches(DETAIL_SEL)) scopes.push(next);

    const id = row.id || row.getAttribute('id');
    if (id && id.startsWith('table-row-')) {
      try {
        const via = document.querySelector('#' + CSS.escape(id) + ' + ' + DETAIL_SEL);
        if (via && !scopes.includes(via)) scopes.push(via);
      } catch {
        // ignore
      }
    }

    const nested = row.querySelector(DETAIL_SEL);
    if (nested && !scopes.includes(nested)) scopes.push(nested);
    return scopes;
  }

  function readEmail(row) {
    for (const scope of findDetailScopes(row)) {
      const mailto =
        scope.querySelector('.contact-state ' + MAILTO_SEL) ||
        scope.querySelector(CONTACTS_SEL + ' ' + MAILTO_SEL) ||
        scope.querySelector(MAILTO_SEL);
      if (mailto) {
        const email = normalizeEmail(mailto.getAttribute('href') || mailto.href || '');
        if (email && email.includes('@')) return email;
      }
    }
    return null;
  }

  function readPhone(row) {
    for (const scope of findDetailScopes(row)) {
      const tel =
        scope.querySelector('.contact-state ' + TEL_SEL) || scope.querySelector(TEL_SEL);
      if (tel) {
        const phone = normalizePhone(tel.getAttribute('href') || tel.href || '');
        if (phone && /\d{3}/.test(phone)) return phone;
      }
    }
    return null;
  }

  function findMailtoInRow(row) {
    for (const scope of findDetailScopes(row)) {
      const mailto =
        scope.querySelector('.contact-state ' + MAILTO_SEL) ||
        scope.querySelector(CONTACTS_SEL + ' ' + MAILTO_SEL) ||
        scope.querySelector(MAILTO_SEL);
      if (mailto) return mailto;
    }
    return null;
  }

  function ensureHostNear(anchorOrContainer) {
    if (anchorOrContainer && anchorOrContainer.tagName === 'A') {
      const next = anchorOrContainer.nextElementSibling;
      if (next && next.classList && next.classList.contains(HOST_CLASS)) return next;
      const host = document.createElement('span');
      host.className = HOST_CLASS;
      anchorOrContainer.insertAdjacentElement('afterend', host);
      return host;
    }
    const container = anchorOrContainer;
    let host =
      (container.querySelector && container.querySelector(':scope > .' + HOST_CLASS)) ||
      (container.querySelector && container.querySelector('.' + HOST_CLASS));
    if (host) return host;
    host = document.createElement('span');
    host.className = HOST_CLASS;
    container.appendChild(host);
    return host;
  }

  function makeCopyBtn(value, label) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'fd-copy-btn';
    btn.title = 'Copy ' + label;
    btn.setAttribute('aria-label', 'Copy ' + label);
    btn.dataset.fdCopyFor = value;
    btn.innerHTML = COPY_ICON;
    btn.addEventListener(
      'click',
      (e) => {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        copyText(value).then((ok) => {
          if (ok) flashCopied(btn);
        });
      },
      true
    );
    return btn;
  }

  function flashSent(btn) {
    const prev = btn.innerHTML;
    btn.classList.add('fd-sent');
    btn.innerHTML = CHECK_ICON;
    setTimeout(() => {
      btn.classList.remove('fd-sent');
      btn.innerHTML = prev;
    }, 1400);
  }

  function closeTplPop() {
    document.querySelectorAll('.fd-email-btn.fd-open').forEach((el) => el.classList.remove('fd-open'));
    const pop = document.getElementById(POP_ID);
    if (pop) pop.remove();
  }

  function placeTplPop(pop, btn) {
    const r = btn.getBoundingClientRect();
    const pad = 8;
    const width = Math.max(pop.offsetWidth || 176, 176);
    const height = pop.offsetHeight || 80;
    let left = r.left + r.width / 2 - width / 2;
    left = Math.max(pad, Math.min(left, window.innerWidth - width - pad));
    const below = r.bottom + 10;
    const above = r.top - height - 10;
    const placeBelow = below + height <= window.innerHeight - pad || above < pad;
    const top = placeBelow ? below : Math.max(pad, above);
    pop.style.left = Math.round(left) + 'px';
    pop.style.top = Math.round(top) + 'px';
    const arrow = pop.querySelector('.fd-tpl-pop-arrow');
    if (arrow) {
      const ax = r.left + r.width / 2 - left - 5;
      arrow.style.left = Math.round(ax) + 'px';
      if (placeBelow) {
        arrow.style.top = '-5px';
        arrow.style.transform = 'rotate(45deg)';
      } else {
        arrow.style.top = 'auto';
        arrow.style.bottom = '-5px';
        arrow.style.transform = 'rotate(225deg)';
      }
    }
  }

  function tplName(tpl) {
    return String((tpl && tpl.name) || 'Template');
  }

  function renderTplPopItems(listEl, templates, query, btn, email, loadVars, loading) {
    const q = String(query || '').trim().toLowerCase();
    listEl.innerHTML = '';
    if (loading) {
      const wait = document.createElement('div');
      wait.className = 'fd-tpl-pop-loading';
      const spin = document.createElement('span');
      spin.className = 'fd-tpl-pop-spin';
      wait.appendChild(spin);
      wait.appendChild(document.createTextNode('Loading templates…'));
      listEl.appendChild(wait);
      return;
    }
    const matches = (templates || []).filter((tpl) => {
      if (!q) return true;
      const name = tplName(tpl).toLowerCase();
      const subject = String(tpl.subject || '').toLowerCase();
      return name.includes(q) || subject.includes(q);
    });
    if (!matches.length) {
      const empty = document.createElement('div');
      empty.className = 'fd-tpl-pop-empty';
      empty.textContent = q ? 'No matching templates' : 'No templates';
      listEl.appendChild(empty);
      return;
    }
    matches.forEach((tpl) => {
      const item = document.createElement('button');
      item.type = 'button';
      item.className = 'fd-tpl-pop-item';
      item.setAttribute('role', 'menuitem');
      item.appendChild(document.createTextNode(tplName(tpl)));
      item.addEventListener(
        'click',
        (e) => {
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();
          closeTplPop();
          runRowSend(btn, email, loadVars, tpl.id);
        },
        true
      );
      listEl.appendChild(item);
    });
  }

  function openTplPop(btn, email, loadVars, templates, opts) {
    closeTplPop();
    const loading = Boolean(opts && opts.loading);
    const pop = document.createElement('div');
    pop.id = POP_ID;
    pop.className = 'fd-tpl-pop';
    pop.setAttribute('role', 'menu');
    pop._fdTemplates = templates || [];
    pop._fdLoading = loading;
    const arrow = document.createElement('div');
    arrow.className = 'fd-tpl-pop-arrow';
    pop.appendChild(arrow);
    const title = document.createElement('div');
    title.className = 'fd-tpl-pop-title';
    title.textContent = 'Send with template';
    pop.appendChild(title);

    const search = document.createElement('input');
    search.type = 'search';
    search.className = 'fd-tpl-pop-search';
    search.placeholder = 'Search templates';
    search.setAttribute('aria-label', 'Search templates');
    search.autocomplete = 'off';
    search.disabled = loading;
    ['mousedown', 'mouseup', 'click', 'keydown', 'keyup', 'keypress', 'input'].forEach((ev) => {
      search.addEventListener(ev, (e) => e.stopPropagation(), true);
    });
    pop.appendChild(search);

    const list = document.createElement('div');
    list.className = 'fd-tpl-pop-list';
    list.setAttribute('role', 'none');
    pop.appendChild(list);

    const paint = () =>
      renderTplPopItems(list, pop._fdTemplates, search.value, btn, email, loadVars, pop._fdLoading);
    search.addEventListener('input', paint);
    pop._fdPaint = paint;
    paint();

    document.body.appendChild(pop);
    btn.classList.add('fd-open');
    placeTplPop(pop, btn);
    requestAnimationFrame(() => {
      placeTplPop(pop, btn);
      if (!loading) search.focus();
    });
    return pop;
  }

  function updateTplPop(pop, btn, email, loadVars, templates, opts) {
    if (!pop) return;
    pop._fdTemplates = templates || [];
    pop._fdLoading = Boolean(opts && opts.loading);
    const search = pop.querySelector('.fd-tpl-pop-search');
    if (search) search.disabled = pop._fdLoading;
    if (typeof pop._fdPaint === 'function') pop._fdPaint();
    else {
      const list = pop.querySelector('.fd-tpl-pop-list');
      if (list) {
        renderTplPopItems(list, pop._fdTemplates, search ? search.value : '', btn, email, loadVars, pop._fdLoading);
      }
    }
    placeTplPop(pop, btn);
    if (!pop._fdLoading && search) {
      requestAnimationFrame(() => search.focus());
    }
  }

  function runRowSend(btn, email, loadVars, templateId) {
    if (!btn || btn.dataset.fdSending === '1') return;
    btn.dataset.fdSending = '1';
    flashSent(btn);
    sendQuickEmail(email, loadVars, templateId).finally(() => {
      btn.dataset.fdSending = '0';
    });
  }

  function makeEmailBtn(value, row) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'fd-email-btn';
    btn.title = 'Choose a template and send';
    btn.setAttribute('aria-label', 'Send email');
    btn.setAttribute('aria-haspopup', 'menu');
    btn.dataset.fdEmailFor = value;
    btn.innerHTML = MAIL_ICON;
    btn.addEventListener(
      'click',
      (e) => {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        if (btn.dataset.fdSending === '1') return;
        if (btn.classList.contains('fd-open')) {
          closeTplPop();
          return;
        }
        const load =
          (window.DatEmailTemplates &&
            typeof window.DatEmailTemplates.extractLoadFromRow === 'function' &&
            window.DatEmailTemplates.extractLoadFromRow(row)) ||
          null;
        const syncCtx =
          (typeof window.__datEmailGetRowSendContextSync === 'function' &&
            window.__datEmailGetRowSendContextSync()) ||
          null;
        const cachedTemplates = (syncCtx && syncCtx.templates) || [];
        const needsFetch = !syncCtx || syncCtx.loading;
        if (syncCtx && !syncCtx.loading && (!syncCtx.signedIn || !syncCtx.hasDefaultInbox)) {
          runRowSend(btn, value, load, '');
          return;
        }
        openTplPop(btn, value, load, cachedTemplates, { loading: Boolean(needsFetch && !cachedTemplates.length) });
        if (!needsFetch) return;
        const getCtx = window.__datEmailGetRowSendContext;
        if (typeof getCtx !== 'function') {
          updateTplPop(document.getElementById(POP_ID), btn, value, load, cachedTemplates, { loading: false });
          return;
        }
        Promise.resolve(getCtx())
          .then((ctx) => {
            const pop = document.getElementById(POP_ID);
            if (!pop || !btn.classList.contains('fd-open')) return;
            if (!ctx || !ctx.signedIn || !ctx.hasDefaultInbox) {
              closeTplPop();
              runRowSend(btn, value, load, '');
              return;
            }
            updateTplPop(pop, btn, value, load, ctx.templates || [], { loading: false });
          })
          .catch(() => {
            const pop = document.getElementById(POP_ID);
            if (pop && btn.classList.contains('fd-open')) {
              updateTplPop(pop, btn, value, load, cachedTemplates, { loading: false });
            }
          });
      },
      true
    );
    return btn;
  }

  function rowKey(row) {
    return row.id || row.getAttribute('id') || row.getAttribute('data-posting-id') || '';
  }

  function findHostForRow(row) {
    const key = rowKey(row);
    if (key) {
      const tagged = document.querySelector('.' + HOST_CLASS + '[' + ROW_HOST_ATTR + '="' + CSS.escape(key) + '"]');
      if (tagged && tagged.isConnected) return tagged;
    }
    return row.querySelector(':scope > .' + HOST_CLASS) || row.querySelector('.' + HOST_CLASS);
  }

  function clearHostsForRowOnly(row) {
    const key = rowKey(row);
    // Only remove hosts owned by this row — never wipe other rows during expand.
    row.querySelectorAll('.' + HOST_CLASS + ', .fd-row-mail').forEach((el) => el.remove());
    if (key) {
      document.querySelectorAll('.' + HOST_CLASS + '[' + ROW_HOST_ATTR + '="' + CSS.escape(key) + '"]').forEach((el) => {
        el.remove();
      });
    }
    const next = row.nextElementSibling;
    if (next && next.matches && next.matches(DETAIL_SEL)) {
      next.querySelectorAll('.' + HOST_CLASS + '[' + ROW_HOST_ATTR + '="' + CSS.escape(key || '__none__') + '"], .fd-row-mail').forEach((el) => {
        // Only remove if tagged for this row, or untagged orphans inside this detail
        const tag = el.getAttribute(ROW_HOST_ATTR);
        if (!tag || tag === key) el.remove();
      });
    }
  }

  function pickMailtoAnchor(row) {
    // Prefer mailto still on the list row so icons stay visible while detail is open.
    const inRow =
      row.querySelector('.contact-state ' + MAILTO_SEL) ||
      row.querySelector(CONTACTS_SEL + ' ' + MAILTO_SEL) ||
      row.querySelector(MAILTO_SEL);
    if (inRow) return inRow;

    const scopes = findDetailScopes(row);
    for (let i = 1; i < scopes.length; i++) {
      const scope = scopes[i];
      const mailto =
        scope.querySelector('.contact-state ' + MAILTO_SEL) ||
        scope.querySelector(CONTACTS_SEL + ' ' + MAILTO_SEL) ||
        scope.querySelector(MAILTO_SEL);
      if (mailto) return mailto;
    }
    return null;
  }

  function fillHost(host, email, phone, row) {
    host.innerHTML = '';
    if (email) {
      host.appendChild(makeCopyBtn(email, 'email'));
      host.appendChild(makeEmailBtn(email, row));
    } else if (phone) {
      host.appendChild(makeCopyBtn(phone, 'phone'));
    }
  }

  function watchUntilEmail(row) {
    if (row.hasAttribute(WATCH_ATTR)) return;
    row.setAttribute(WATCH_ATTR, '1');
    const watch = new MutationObserver(() => {
      if (!readEmail(row)) return;
      watch.disconnect();
      row.removeAttribute(WATCH_ATTR);
      processRow(row);
    });
    watch.observe(row, { childList: true, subtree: true, characterData: true });
    const next = row.nextElementSibling;
    if (next && next.matches && next.matches(DETAIL_SEL)) {
      watch.observe(next, { childList: true, subtree: true, characterData: true });
    }
  }

  function processRow(row) {
    if (!row || !row.isConnected) return;
    // Ignore nested row-like nodes inside another load row / detail of another row
    const parentRow = row.parentElement && row.parentElement.closest(ROW_SEL);
    if (parentRow && parentRow !== row) return;

    suppressDatNativeEmailButtons(row);

    const email = readEmail(row);
    const phone = readPhone(row);
    const existing = findHostForRow(row);
    const sig = (email || '') + '|' + (phone && !email ? phone : '');

    // While a load is expanding, contacts can briefly disappear — keep existing icons.
    if (!email && !phone) {
      if (!existing) watchUntilEmail(row);
      return;
    }

    row.removeAttribute(WATCH_ATTR);

    if (existing && existing.isConnected && existing.dataset.fdSig === sig) {
      row.setAttribute(ROW_ATTR, '1');
      return;
    }

    clearHostsForRowOnly(row);

    const mailtoEl = pickMailtoAnchor(row);
    // Prefer attaching next to in-row mailto / contacts so icons stay on the list row.
    const inRowAnchor =
      row.querySelector('.contact-state ' + MAILTO_SEL) ||
      row.querySelector(CONTACTS_SEL + ' ' + MAILTO_SEL) ||
      row.querySelector(MAILTO_SEL) ||
      row.querySelector(CONTACTS_SEL);
    const anchor = inRowAnchor || mailtoEl || row;
    const host = ensureHostNear(anchor);
    const key = rowKey(row);
    if (key) host.setAttribute(ROW_HOST_ATTR, key);
    fillHost(host, email, phone, row);
    host.dataset.fdSig = sig;
    row.setAttribute(ROW_ATTR, '1');
  }

  function resetRecycledRow(row) {
    if (row.hasAttribute(ROW_ATTR) && !findHostForRow(row)) {
      row.removeAttribute(ROW_ATTR);
      row.removeAttribute(WATCH_ATTR);
    }
  }

  function listRows() {
    const active =
      document.querySelector('.mat-tab-body-active') ||
      document.querySelector('.mat-mdc-tab-body-active') ||
      document;
    return Array.from(active.querySelectorAll(ROW_SEL)).filter((row) => {
      const parent = row.parentElement && row.parentElement.closest(ROW_SEL);
      return !parent || parent === row;
    });
  }

  let scanning = false;
  function scanPage() {
    if (!document.body || scanning) return;
    if (document.visibilityState === 'hidden') return;
    ensureStyles();
    scanning = true;
    try {
      suppressDatNativeEmailButtons(document);
      const rows = listRows();
      if (!rows.length) {
        // Fallback: any mailto on the page
        document.querySelectorAll(MAILTO_SEL).forEach((link) => {
          const email = normalizeEmail(link.getAttribute('href') || link.href || '');
          if (!email || !email.includes('@')) return;
          if (link.nextElementSibling && link.nextElementSibling.classList.contains(HOST_CLASS)) {
            return;
          }
          let sib = link.nextElementSibling;
          while (
            sib &&
            (sib.classList.contains('fd-copy-btn') ||
              sib.classList.contains('fd-email-btn') ||
              sib.classList.contains(HOST_CLASS))
          ) {
            const n = sib.nextElementSibling;
            sib.remove();
            sib = n;
          }
          const host = ensureHostNear(link);
          fillHost(host, email, null);
        });
        return;
      }

      let withEmail = 0;
      rows.forEach((row) => {
        resetRecycledRow(row);
        processRow(row);
        if (row.querySelector('.fd-email-btn, .fd-row-mail')) withEmail += 1;
      });
      if (!window.__fdExtScanLogged || withEmail > 0) {
        window.__fdExtScanLogged = true;
        console.log('[Signal] rows=' + rows.length + ' emailIcons=' + withEmail);
      }
    } finally {
      scanning = false;
    }
  }

  let scanTimer = null;
  function scheduleScan() {
    if (document.visibilityState === 'hidden') return;
    if (scanTimer) return;
    scanTimer = setTimeout(() => {
      scanTimer = null;
      scanPage();
    }, 200);
  }

  function bindScroll() {
    if (window.__fdExtScrollBound) return;
    window.__fdExtScrollBound = true;
    document.addEventListener('scroll', (e) => {
      const pop = document.getElementById(POP_ID);
      if (pop && e.target && (e.target === pop || pop.contains(e.target))) return;
      closeTplPop();
      scheduleScan();
    }, { passive: true, capture: true });
    document
      .querySelectorAll(
        'cdk-virtual-scroll-viewport, .cdk-virtual-scroll-viewport, [class*="virtual-scroll"]'
      )
      .forEach((vp) => {
        if (vp.dataset.fdExtScrollBound === '1') return;
        vp.dataset.fdExtScrollBound = '1';
        vp.addEventListener('scroll', scheduleScan, { passive: true });
      });
  }

  const observer = new MutationObserver((mutations) => {
    for (const m of mutations) {
      if (m.type !== 'childList') continue;
      for (const n of m.addedNodes) {
        if (isOurNode(n)) continue;
        scheduleScan();
        return;
      }
      for (const n of m.removedNodes) {
        if (isOurNode(n)) continue;
        scheduleScan();
        return;
      }
    }
  });

  const start = () => {
    if (!document.body) return;
    ensureStyles();
    const viewport =
      document.querySelector(
        '.mat-tab-body-active cdk-virtual-scroll-viewport, cdk-virtual-scroll-viewport, .cdk-virtual-scroll-viewport'
      ) || document.body;
    observer.observe(viewport, { childList: true, subtree: true });
    bindScroll();
    scanPage();
  };

  document.addEventListener(
    'click',
    (e) => {
      const pop = document.getElementById(POP_ID);
      if (!pop) return;
      const t = e.target;
      if (t && (pop.contains(t) || (t.closest && t.closest('.fd-email-btn')))) return;
      closeTplPop();
    },
    true
  );
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeTplPop();
  });
  window.addEventListener('resize', closeTplPop);

  if (document.body) start();
  else document.addEventListener('DOMContentLoaded', start, { once: true });

  setTimeout(scanPage, 400);
  setTimeout(scanPage, 1200);
  setTimeout(scanPage, 2500);
  setInterval(scanPage, 6000);

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') scheduleScan();
  });

  console.log('[Signal] row actions content script loaded');
})();
