'use strict';

/**
 * CargoSignal-style template variables for Signal.
 * Shared by content.js (editor/preview) and rowActions.js (row scrape).
 */
(function (root) {
  const TEMPLATE_VARIABLES = [
    { key: 'origin', label: 'Origin', token: '{{origin}}' },
    { key: 'destination', label: 'Destination', token: '{{destination}}' },
    { key: 'miles', label: 'Miles', token: '{{miles}}' },
    { key: 'rate', label: 'Rate', token: '{{rate}}' },
    { key: 'ratePerMile', label: 'Rate/mi', token: '{{ratePerMile}}' },
    { key: 'broker', label: 'Broker', token: '{{broker}}' },
    { key: 'equipment', label: 'Equipment', token: '{{equipment}}' },
    { key: 'weight', label: 'Weight', token: '{{weight}}' },
    { key: 'ref', label: 'Ref', token: '{{ref}}' },
    { key: 'mc', label: 'MC#', token: '{{mc}}' },
    { key: 'email', label: 'Broker email', token: '{{email}}' },
    { key: 'to', label: 'To', token: '{{to}}' }
  ];

  /** Chips shown in the editor (high-use vars). */
  const INSERT_VARS = [
    'origin',
    'destination',
    'miles',
    'rate',
    'broker',
    'ref',
    'mc',
    'equipment',
    'weight',
    'email'
  ].map((key) => TEMPLATE_VARIABLES.find((v) => v.key === key)).filter(Boolean);

  const SAMPLE_LOAD = {
    origin: 'Dallas, TX',
    destination: 'Atlanta, GA',
    rate: '$2,400',
    ratePerMile: '$2.15',
    miles: '1,118 mi',
    broker: 'ABC Logistics',
    equipment: 'Van',
    weight: '42,000 lbs',
    ref: 'LR-1001',
    loadRef: 'LR-1001',
    mc: '659555',
    email: 'dispatch@example.com',
    to: 'dispatch@example.com'
  };

  const BUILTIN_TEMPLATES = [
    {
      name: 'Load inquiry',
      subject: 'Truck available — {{origin}} to {{destination}}',
      body:
        'Hi {{broker}},\n\nWe have a truck for your load from {{origin}} to {{destination}} ({{equipment}}, {{miles}}, {{rate}}).\n\nIs this still available? We can cover it.\n\nThanks,',
      isDefault: true
    },
    {
      name: 'Quick availability check',
      subject: 'Re: {{origin}} to {{destination}}',
      body:
        'Hello,\n\nIs this load still open? We have capacity for {{origin}} → {{destination}}.\n\nThanks,',
      isDefault: false
    },
    {
      name: 'Rate confirmation',
      subject: 'Re: {{origin}} → {{destination}} — rate {{rate}}',
      body:
        'Hi {{broker}},\n\nConfirming interest in {{origin}} to {{destination}} at {{rate}} ({{ratePerMile}}/mi over {{miles}}).\n\nPlease let me know if this is still firm and when pickup is scheduled.\n\nBest,',
      isDefault: false
    },
    {
      name: 'Follow-up (no response)',
      subject: 'Following up — {{origin}} → {{destination}}',
      body:
        'Hi {{broker}},\n\nFollowing up on the {{origin}} → {{destination}} load. Still interested if it\'s available.\n\nThanks,',
      isDefault: false
    }
  ];

  function formatMoney(n) {
    if (n == null || n === '' || Number.isNaN(Number(n))) return '';
    return '$' + Number(n).toLocaleString();
  }

  function formatMiles(n) {
    if (n == null || n === '' || Number.isNaN(Number(n))) return '';
    return Number(n).toLocaleString() + ' mi';
  }

  function formatWeight(n) {
    if (n == null || n === '' || Number.isNaN(Number(n))) return '';
    return Number(n).toLocaleString() + ' lbs';
  }

  function formatRatePerMile(n) {
    if (n == null || n === '' || Number.isNaN(Number(n))) return '';
    return '$' + Number(n).toFixed(2);
  }

  /**
   * Build flat string vars for {{placeholders}}.
   * Accepts either scraped flat strings or structured load fields.
   */
  function buildVars(load, recipient) {
    const l = load || {};
    const email = String(recipient || l.email || l.to || '').trim();

    const origin =
      l.origin ||
      [l.originCity, l.originState].filter(Boolean).join(', ') ||
      '';
    const destination =
      l.destination ||
      [l.destCity, l.destState].filter(Boolean).join(', ') ||
      '';
    const rate =
      l.rate ||
      (l.rateTotal != null ? formatMoney(l.rateTotal) : '') ||
      '';
    const ratePerMile =
      l.ratePerMileFormatted ||
      l.ratePerMileLabel ||
      (l.ratePerMile != null && typeof l.ratePerMile === 'number'
        ? formatRatePerMile(l.ratePerMile)
        : typeof l.ratePerMile === 'string'
          ? l.ratePerMile
          : '');
    const miles =
      l.milesLabel ||
      l.milesFormatted ||
      (l.miles != null && typeof l.miles === 'number' ? formatMiles(l.miles) : '') ||
      (typeof l.miles === 'string' ? l.miles : '');
    const weight =
      l.weightLabel ||
      (l.weightLbs != null ? formatWeight(l.weightLbs) : '') ||
      (typeof l.weight === 'string' ? l.weight : '');

    const ref = String(l.ref || l.loadRef || '').trim();

    return {
      origin,
      destination,
      rate,
      ratePerMile,
      miles,
      broker: String(l.broker || l.brokerName || '').trim(),
      equipment: String(l.equipment || l.equipmentType || '').trim(),
      weight,
      ref,
      loadRef: ref,
      mc: String(l.mc || l.brokerMcNumber || '').trim(),
      email,
      to: email
    };
  }

  function substituteTemplate(text, loadOrVars, recipient) {
    if (!text) return text;
    const vars =
      loadOrVars && loadOrVars.__flat
        ? loadOrVars
        : buildVars(loadOrVars, recipient);
    return String(text).replace(/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/g, (_, key) => {
      if (Object.prototype.hasOwnProperty.call(vars, key) && vars[key] != null) {
        return String(vars[key]);
      }
      return '{{' + key + '}}';
    });
  }

  function textContent(el) {
    return el ? String(el.textContent || '').replace(/\s+/g, ' ').trim() : '';
  }

  function parseMoney(str) {
    const m = String(str || '').replace(/,/g, '').match(/\$?\s*([\d]+(?:\.\d+)?)/);
    return m ? Number(m[1]) : null;
  }

  function parseIntish(str) {
    const m = String(str || '').replace(/,/g, '').match(/(\d+)/);
    return m ? Number(m[1]) : null;
  }

  /**
   * Scrape CargoSignal/DAT One row (+ detail sibling) into template vars.
   */
  function extractLoadFromRow(row) {
    if (!row || row.nodeType !== 1) return null;

    const scopes = [row];
    const next = row.nextElementSibling;
    if (next && /row-detail/i.test(next.className || '')) scopes.push(next);
    const nested = row.querySelector('.table-row-detail, [class*="row-detail"]');
    if (nested && !scopes.includes(nested)) scopes.push(nested);

    function q(sel) {
      for (const s of scopes) {
        const el = s.querySelector(sel);
        if (el) return el;
      }
      return null;
    }

    function qAllText(sel) {
      for (const s of scopes) {
        const el = s.querySelector(sel);
        if (el) return textContent(el);
      }
      return '';
    }

    const originEl = q('[data-test="load-origin-cell"], .city-state-container');
    let originCity = '';
    let originState = '';
    if (originEl) {
      originCity = textContent(originEl.querySelector('.truncate, [class*="city"]')) ||
        textContent(originEl).split(',')[0];
      originState = textContent(originEl.querySelector('.state'));
      if (!originState) {
        const bits = textContent(originEl).split(',');
        if (bits[1]) originState = bits[1].trim().slice(0, 2);
      }
    }

    const destCell = q('[data-test="load-destination-cell"]');
    let destCity = '';
    let destState = '';
    if (destCell) {
      destCity = textContent(destCell.querySelector('.truncate')) || textContent(destCell).split(',')[0];
      destState = textContent(destCell.querySelector('.state'));
      if (!destState) {
        const bits = textContent(destCell).split(',');
        if (bits[1]) destState = bits[1].trim().slice(0, 2);
      }
    }

    // If first city-state was destination because origin used same selector incorrectly
    const originCell = q('[data-test="load-origin-cell"]');
    if (originCell) {
      originCity = textContent(originCell.querySelector('.truncate')) || textContent(originCell).split(',')[0];
      originState = textContent(originCell.querySelector('.state')) || originState;
    }

    const rateCell = q('[data-test="load-rate-cell"], .cell-rate');
    const rateOffer = rateCell
      ? textContent(rateCell.querySelector('.offer')) || textContent(rateCell)
      : '';
    const ratePerMileText = rateCell
      ? textContent(rateCell.querySelector('.rate-per-mile')) ||
        Array.from(rateCell.querySelectorAll('span'))
          .map((s) => textContent(s))
          .find((t) => /\/\s*mi|per\s*mi|\$\d/i.test(t) && t !== rateOffer) ||
        ''
      : '';

    const tripText = qAllText('[data-test="load-trip-cell"]');
    const eqText = qAllText('[data-test="load-eq-cell"]');
    const weightText = qAllText('[data-test="load-weight-cell"]');
    const broker =
      qAllText('[data-test="load-company-cell"], .cell-company a, .cell-company') || '';

    let mc = '';
    for (const s of scopes) {
      const t = textContent(s);
      const m = t.match(/MC\s*#?\s*([0-9]{4,8})/i);
      if (m) {
        mc = m[1];
        break;
      }
    }

    const id = row.id || row.getAttribute('id') || '';
    const ref = id.replace(/^table-row-/i, '') || row.getAttribute('data-load-id') || '';

    const mailto = q("a[href^='mailto:'], a[href*='mailto:']");
    let email = '';
    if (mailto) {
      email = decodeURIComponent(
        String(mailto.getAttribute('href') || mailto.href || '')
          .replace(/^mailto:/i, '')
          .split('?')[0]
      ).trim();
    }

    const rateTotal = parseMoney(rateOffer);
    const rpm = parseMoney(ratePerMileText);
    const milesNum = parseIntish(tripText);
    const weightNum = parseIntish(weightText);

    return buildVars({
      originCity,
      originState,
      destCity,
      destState,
      rateTotal,
      ratePerMile: rpm,
      miles: milesNum,
      milesLabel: tripText.includes('mi') ? tripText : milesNum != null ? formatMiles(milesNum) : tripText,
      brokerName: broker,
      equipmentType: eqText,
      weightLbs: weightNum,
      weight: weightText,
      loadRef: ref,
      brokerMcNumber: mc,
      email
    });
  }

  function insertAtCursor(input, text) {
    if (!input) return;
    const start = input.selectionStart ?? input.value.length;
    const end = input.selectionEnd ?? input.value.length;
    const before = input.value.slice(0, start);
    const after = input.value.slice(end);
    input.value = before + text + after;
    const pos = start + text.length;
    input.focus();
    try {
      input.setSelectionRange(pos, pos);
    } catch {
      // ignore
    }
    input.dispatchEvent(new Event('input', { bubbles: true }));
  }

  root.DatEmailTemplates = {
    TEMPLATE_VARIABLES,
    INSERT_VARS,
    SAMPLE_LOAD,
    BUILTIN_TEMPLATES,
    buildVars,
    substituteTemplate,
    extractLoadFromRow,
    insertAtCursor
  };
})(typeof window !== 'undefined' ? window : globalThis);
