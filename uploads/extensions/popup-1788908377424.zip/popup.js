'use strict';

const msg = document.getElementById('msg');
const statusCard = document.getElementById('status-card');
const statusInbox = document.getElementById('status-inbox');
const openBtn = document.getElementById('open');
const OPEN_HTML = openBtn.innerHTML;

function setMsg(text, ok) {
  const cleaned = String(text || '')
    .replace(/https?:\/\/[^\s"'<>)\]]+/gi, '')
    .replace(/\b(?:localhost|127\.0\.0\.1)(?::\d+)?\b/gi, '')
    .replace(/\b[\w.-]*apexskillzone\.com\b/gi, '')
    .replace(/\s{2,}/g, ' ')
    .trim();
  msg.textContent = cleaned;
  msg.className = 'msg ' + (ok === true ? 'ok' : ok === false ? 'err' : '');
}

function setBusy(on) {
  openBtn.disabled = !!on;
  openBtn.innerHTML = on
    ? '<span class="spin" aria-hidden="true"></span>Opening…'
    : OPEN_HTML;
}

function isDatUrl(url) {
  try {
    const u = new URL(String(url || ''));
    return u.hostname === 'one.dat.com' || u.hostname.endsWith('.dat.com');
  } catch {
    return false;
  }
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function refreshStatus() {
  try {
    const session = await chrome.runtime.sendMessage({ type: 'GET_SESSION' });
    if (!session?.success || !session.data?.signedIn) {
      statusCard.hidden = true;
      return;
    }
    statusCard.hidden = false;

    const status = await chrome.runtime.sendMessage({ type: 'EMAIL_STATUS' });
    const accounts = status?.success
      ? status.data?.accounts || (status.data?.account ? [status.data.account] : [])
      : [];
    const active = accounts.find((a) => a.isDefault) || accounts[0];

    if (active?.email) {
      statusInbox.className = 'v ok';
      statusInbox.innerHTML =
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.5 2.5L16 9"/></svg>Connected';
    } else {
      statusInbox.className = 'v';
      statusInbox.textContent = 'None';
    }
  } catch {
    statusCard.hidden = true;
  }
}

openBtn.addEventListener('click', async () => {
  const tab = await getActiveTab();
  if (!tab?.id) {
    setMsg('No active tab.', false);
    return;
  }
  if (!isDatUrl(tab.url)) {
    setMsg('Open DAT One first, then try again.', false);
    return;
  }

  setBusy(true);
  setMsg('Opening…');
  const inject = await chrome.runtime.sendMessage({ type: 'ENSURE_INJECT', tabId: tab.id });
  if (!inject?.success) {
    setBusy(false);
    setMsg('Could not open the Signal panel. Refresh DAT One and try again.', false);
    return;
  }

  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'DAT_EMAIL_OPEN' });
    setMsg('Signal panel opened.', true);
    setTimeout(() => window.close(), 400);
  } catch {
    setBusy(false);
    setMsg('Could not open the Signal panel. Refresh DAT One and try again.', false);
  }
});

refreshStatus();
