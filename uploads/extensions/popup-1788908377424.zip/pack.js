'use strict';

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const root = __dirname;
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
const outName = `signal-${manifest.version}.zip`;
const outPath = path.join(root, outName);

const files = [
  'manifest.json',
  'background.js',
  'templateVars.js',
  'content.js',
  'rowActions.js',
  'popup.html',
  'popup.js',
  'icons/icon16.png',
  'icons/icon32.png',
  'icons/icon48.png',
  'icons/icon128.png',
  'icons/logo_only_icon.png',
  'icons/logo_full_with_signal_text.png'
];

for (const file of files) {
  if (!fs.existsSync(path.join(root, file))) {
    throw new Error(`Missing ${file}`);
  }
}

if (fs.existsSync(outPath)) fs.unlinkSync(outPath);

const list = files.map((f) => `'${f.replace(/'/g, "''")}'`).join(',');
execFileSync(
  'powershell.exe',
  [
    '-NoProfile',
    '-Command',
    `Compress-Archive -Path ${list} -DestinationPath '${outPath.replace(/'/g, "''")}' -Force`
  ],
  { cwd: root, stdio: 'inherit' }
);

console.log('Created', outPath);
