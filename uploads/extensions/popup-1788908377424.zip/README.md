# Signal extension

Standalone Chromium extension that replaces the in-app email sidebar in **Signal**.

## Features

- Floating **Signal** panel on DAT One pages (Shadow DOM — works with DAT CSP)
- Compose / Templates / Account panel
- Gmail connect (app password or OAuth via backend)
- Template CRUD + send through `/email/*`

## Install (admin managed extension)

1. From this folder run:
   ```bash
   node pack.js
   ```
2. Upload `signal-1.1.7.zip` in Admin → Extensions
3. Enable for users → **Open DAT** (desk injects `desk_session.json`)

## Manual load (dev)

1. Extensions → Load unpacked → this folder
2. Open **one.dat.com**
3. Click the extension icon → **Open Signal panel**, or use the envelope on a load row
4. On Account tab: sign in with the same credentials, then connect Gmail

## Desk apps

Open DAT loads this pack via `session.loadExtension()`. The desk apps do **not** inject a second email sidebar or row buttons — those come only from this extension.

## Chrome / managed ZIP

Use this folder / `signal-*.zip` when you want the extension in a normal Chromium browser
or uploaded via Admin → Extensions.
